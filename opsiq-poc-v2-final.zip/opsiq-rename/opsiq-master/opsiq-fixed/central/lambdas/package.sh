#!/usr/bin/env bash
# opsiq-poc/central/lambdas/package.sh
# Packages all central Lambda functions into ZIPs and uploads to S3.
# Works on Git Bash (Windows), macOS, and Linux.
#
# Usage: ./package.sh <lambda-code-bucket>
# Example: ./package.sh opsiq-lambda-pkgs-615299738349

set -euo pipefail

BUCKET="${1:?Usage: ./package.sh <lambda-code-bucket>}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REGION="${REGION:-us-west-2}"

echo "╔══════════════════════════════════════════════════╗"
echo "║  OpsIQ — Packaging Central Lambda Functions     ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║  Source : $SCRIPT_DIR"
echo "║  Bucket : s3://$BUCKET/central/"
echo "╚══════════════════════════════════════════════════╝"
echo ""

# All central Lambda functions
FUNCTIONS=(
  "log_processor"
  "log_volume_monitor"
  "log_pattern_tracker"
  "state_parser"
  "correlator"
  "drift_detector"
  "health_scorer"
  "incident_assembler"
  "incident_summariser"
  "api_handler"
  "chat_handler"
  "ws_handler"
  "ws_broadcaster"
)

# Use Python to create ZIPs — works consistently on all platforms
# Falls back to zip command if Python unavailable
package_and_upload() {
  local fn="$1"
  local src="${SCRIPT_DIR}/${fn}.py"
  local zip_path="${SCRIPT_DIR}/${fn}.zip"

  if [ ! -f "$src" ]; then
    echo "  SKIP (not found): ${fn}.py"
    return
  fi

  # Create ZIP
  if command -v python3 &>/dev/null; then
    python3 -c "
import zipfile, os, sys
fn = sys.argv[1]
src = sys.argv[2]
dst = sys.argv[3]
with zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED) as z:
    z.write(src, os.path.basename(src))
print(f'  Packaged: {fn}.zip ({os.path.getsize(dst)} bytes)')
" "$fn" "$src" "$zip_path"
  else
    (cd "$SCRIPT_DIR" && zip -q "$zip_path" "${fn}.py")
    echo "  Packaged: ${fn}.zip"
  fi

  # Upload to S3
  aws s3 cp "$zip_path" "s3://$BUCKET/central/${fn}.zip" \
    --region "$REGION" --quiet
  echo "  Uploaded: s3://$BUCKET/central/${fn}.zip"
}

for FN in "${FUNCTIONS[@]}"; do
  package_and_upload "$FN"
done

echo ""
echo "✓ Central Lambda packaging complete (${#FUNCTIONS[@]} functions)"
