#!/usr/bin/env bash
# opsiq-poc/simulation/lambdas/package.sh
# Packages all simulation Lambda functions into ZIPs and uploads to S3.
#
# Usage: ./package.sh <lambda-code-bucket>

set -euo pipefail

BUCKET="${1:?Usage: ./package.sh <lambda-code-bucket>}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REGION="${REGION:-us-west-2}"

echo "╔══════════════════════════════════════════════════╗"
echo "║  OpsIQ — Packaging Simulation Lambda Functions  ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║  Source : $SCRIPT_DIR"
echo "║  Bucket : s3://$BUCKET/simulation/"
echo "╚══════════════════════════════════════════════════╝"
echo ""

FUNCTIONS=(
  "seeder"
  "manual_seeder"
  "extended_seeder"
  "log_generator"
  "metric_generator"
  "anomaly_injector"
)

package_and_upload() {
  local fn="$1"
  local src="${SCRIPT_DIR}/${fn}.py"
  local zip_path="${SCRIPT_DIR}/${fn}.zip"

  # extended_seeder needs handler file too
  local extra=""
  if [ "$fn" = "extended_seeder" ] && [ -f "${SCRIPT_DIR}/extended_seeder_handler.py" ]; then
    extra="${SCRIPT_DIR}/extended_seeder_handler.py"
  fi

  if [ ! -f "$src" ]; then
    echo "  SKIP (not found): ${fn}.py"
    return
  fi

  if command -v python3 &>/dev/null; then
    python3 -c "
import zipfile, os, sys
fn = sys.argv[1]
src = sys.argv[2]
dst = sys.argv[3]
extra = sys.argv[4] if len(sys.argv) > 4 else ''
with zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED) as z:
    z.write(src, os.path.basename(src))
    if extra and os.path.exists(extra):
        z.write(extra, os.path.basename(extra))
print(f'  Packaged: {fn}.zip ({os.path.getsize(dst)} bytes)')
" "$fn" "$src" "$zip_path" "$extra"
  else
    files="${fn}.py"
    [ -n "$extra" ] && files="$files extended_seeder_handler.py"
    (cd "$SCRIPT_DIR" && zip -q "$zip_path" $files)
    echo "  Packaged: ${fn}.zip"
  fi

  aws s3 cp "$zip_path" "s3://$BUCKET/simulation/${fn}.zip" \
    --region "$REGION" --quiet
  echo "  Uploaded: s3://$BUCKET/simulation/${fn}.zip"
}

for FN in "${FUNCTIONS[@]}"; do
  package_and_upload "$FN"
done

echo ""
echo "✓ Simulation Lambda packaging complete (${#FUNCTIONS[@]} functions)"
