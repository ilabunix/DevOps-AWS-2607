/**
 * CloudOps Dashboard — API Layer
 * All REST calls go through the central api-handler Lambda via API Gateway.
 * WebSocket connects to the ws-handler Lambda and receives real-time pushes.
 */

const BASE_URL = import.meta.env.VITE_API_URL || '';
const WS_URL   = import.meta.env.VITE_WS_URL  || '';

// ── REST ──────────────────────────────────────────────────────────────────

async function get(path) {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { 'Content-Type': 'application/json' },
  });
  if (!res.ok) throw new Error(`API error ${res.status}: ${path}`);
  return res.json();
}

export const api = {
  // Account health scores for all accounts
  getAccounts:   ()   => get('/accounts'),

  // D3 topology graph for a specific account
  getTopology:   (id) => get(`/accounts/${id}/topology`),

  // Recent anomalies (last 30 min) for an account
  getAnomalies:  (id) => get(`/accounts/${id}/anomalies`),

  // Recent incidents for an account
  getIncidents:  (id) => get(`/accounts/${id}/incidents`),

  // All incidents across all accounts
  getAllIncidents: ()  => get('/incidents'),

  // Single incident with full AI summary
  getIncident:   (id) => get(`/incidents/${id}`),

  // Bedrock architecture narrative for an account
  getExplain:    (id) => get(`/accounts/${id}/explain`),

  // On-demand AI summarisation — single Bedrock call, result cached permanently
  summariseIncident: (incidentId) => fetch(`${BASE_URL}/incidents/${incidentId}/summarise`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
  }).then(r => { if (!r.ok) throw new Error(`Summarise failed: ${r.status}`); return r.json(); }),
};

// ── WEBSOCKET ─────────────────────────────────────────────────────────────

let ws = null;
let reconnectTimer = null;
const listeners = new Set();

export function subscribeToEvents(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

function notifyListeners(event) {
  listeners.forEach(fn => {
    try { fn(event); } catch (e) { console.error('WS listener error', e); }
  });
}

export function connectWebSocket() {
  if (!WS_URL || ws?.readyState === WebSocket.OPEN) return;

  ws = new WebSocket(WS_URL);

  ws.onopen = () => {
    console.log('[CloudOps] WebSocket connected');
    clearTimeout(reconnectTimer);
  };

  ws.onmessage = (msg) => {
    try {
      const event = JSON.parse(msg.data);
      notifyListeners(event);
    } catch {
      // Non-JSON message — ignore
    }
  };

  ws.onclose = () => {
    console.log('[CloudOps] WebSocket closed — reconnecting in 3s');
    reconnectTimer = setTimeout(connectWebSocket, 3000);
  };

  ws.onerror = (err) => {
    console.error('[CloudOps] WebSocket error', err);
    ws.close();
  };
}

export function disconnectWebSocket() {
  clearTimeout(reconnectTimer);
  if (ws) { ws.close(); ws = null; }
}
