import { useEffect, useState } from 'react';
import { useStore } from '../store.js';
const NAV = [
  { label: 'Overview', items: [
    { id: 'Dashboard', icon: 'grid',     label: 'Dashboard' },
    { id: 'Accounts',  icon: 'home',     label: 'Account Health' },
  ]},
  { label: 'Operations', items: [
    { id: 'Incidents',        icon: 'alert',    label: 'Incidents', badge: true },
    { id: 'IncidentTimeline', icon: 'timeline', label: 'Timeline' },
    { id: 'Anomalies',        icon: 'triangle', label: 'Anomalies' },
    { id: 'Signals',          icon: 'activity', label: 'Signal Feed' },
    { id: 'LogSearch',        icon: 'search',   label: 'Log Search' },
    { id: 'Topology',         icon: 'topology', label: 'Topology' },
  ]},
  { label: 'Intelligence', items: [
    { id: 'Chat',      icon: 'chat',     label: 'AI SRE Agent' },
    { id: 'Drift',     icon: 'check',    label: 'Drift Detection' },
    { id: 'Runbooks',  icon: 'book',     label: 'Runbooks' },
  ]},
];
const THEMES = [
  { id: 'dim', label: 'Dim' },
  { id: 'dark', label: 'Dark' },
  { id: 'light', label: 'Light' },
];
const PATHS = {
  grid:     <><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/></>,
  home:     <><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></>,
  alert:    <><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></>,
  triangle: <><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/></>,
  activity: <><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></>,
  search:   <><circle cx="11" cy="11" r="7"/><line x1="16.65" y1="16.65" x2="21" y2="21"/></>,
  topology: <><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></>,
  check:    <><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></>,
  book:     <><path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/></>,
  timeline: <><line x1="17" y1="12" x2="3" y2="12"/><polyline points="3 6 9 12 3 18"/><line x1="21" y1="6" x2="21" y2="18"/></>,
  chat:     <><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></>,
  settings: <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></>,
};
function Icon({ name }) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" style={{width:15,height:15,flexShrink:0}}>{PATHS[name]}</svg>;
}
export default function Sidebar() {
  const currentView = useStore(s => s.currentView);
  const setView     = useStore(s => s.setView);
  const incidents   = useStore(s => s.incidents);
  const openCount   = incidents.filter(i => i.status === 'OPEN').length;
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [theme, setTheme] = useState(() => {
    try {
      const saved = localStorage.getItem('cloudops-theme-v2');
      if (THEMES.some(t => t.id === saved)) return saved;
      return localStorage.getItem('cloudops-theme') === 'light' ? 'light' : 'dim';
    } catch { return 'dim'; }
  });

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    try { localStorage.setItem('cloudops-theme-v2', theme); }
    catch {}
  }, [theme]);

  return (
    <aside className="sidebar">
      {NAV.map(section => (
        <div className="sb-section" key={section.label}>
          <div className="sb-label">{section.label}</div>
          {section.items.map(item => (
            <button key={item.id} className={`sb-item${currentView===item.id?' active':''}`} onClick={() => setView(item.id)}>
              <Icon name={item.icon}/>{item.label}
              {item.badge && openCount > 0 && <span className="sb-badge">{openCount>99?'99+':openCount}</span>}
            </button>
          ))}
          <div className="sb-divider"/>
        </div>
      ))}
      <div className="sb-section settings-section" style={{marginTop:'auto'}}>
        <button
          className={`sb-item${settingsOpen ? ' active' : ''}`}
          onClick={() => setSettingsOpen(o => !o)}
          aria-expanded={settingsOpen}
        >
          <Icon name="settings"/>Settings
        </button>
        {settingsOpen && (
          <div className="settings-popover">
            <div>
              <div className="settings-title">Appearance</div>
              <div className="settings-sub">Choose the dashboard tone.</div>
            </div>
            <div className="settings-segment" role="radiogroup" aria-label="Dashboard theme">
              {THEMES.map(option => (
                <button
                  key={option.id}
                  type="button"
                  role="radio"
                  aria-checked={theme === option.id}
                  className={theme === option.id ? 'active' : ''}
                  onClick={() => setTheme(option.id)}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </aside>
  );
}
