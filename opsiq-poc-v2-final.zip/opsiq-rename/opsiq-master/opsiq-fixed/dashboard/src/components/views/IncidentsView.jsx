import { useState } from 'react';
import { useStore } from '../../store.js';
import { api } from '../../api.js';

function timeAgo(ts) {
  if (!ts) return '—';
  const m = Math.floor((Date.now() - Number(ts)) / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m} min ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

function AISummaryPanel({ incident, onSummaryGenerated }) {
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState(null);

  async function handleSummarise() {
    setLoading(true);
    setError(null);
    try {
      const result = await api.summariseIncident(incident.incidentId);
      // Result contains the summary — update local incident via callback
      if (result.aiSummary) {
        onSummaryGenerated(incident.incidentId, result.aiSummary);
      }
    } catch (e) {
      setError(e.message || 'Failed to generate summary');
    } finally {
      setLoading(false);
    }
  }

  // Already has a summary — show it
  if (incident.aiSummary) {
    return (
      <div style={{
        background: 'var(--purple-dim)', border: '1px solid var(--purple-border)',
        borderRadius: 6, overflow: 'hidden',
      }}>
        {/* Header */}
        <div style={{
          background: 'linear-gradient(135deg, #1A0E2E 0%, #0F1625 100%)',
          padding: '10px 14px', display: 'flex', alignItems: 'center', gap: 8,
          borderBottom: '1px solid var(--purple-border)',
        }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="var(--purple)">
            <path d="M12 2a10 10 0 110 20A10 10 0 0112 2zm0 5a1 1 0 00-1 1v4a1 1 0 002 0V8a1 1 0 00-1-1zm0 8a1 1 0 100 2 1 1 0 000-2z"/>
          </svg>
          <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-1)' }}>
            ✦ AI Incident Analysis
          </span>
          <span style={{ fontSize: 11, color: 'var(--text-3)', marginLeft: 'auto', fontFamily: 'var(--font-mono)' }}>
            Bedrock · Claude Sonnet
          </span>
        </div>

        {/* Body */}
        <div style={{ padding: '12px 14px', fontSize: 12.5 }}>
          {/* Headline */}
          <div style={{
            fontWeight: 600, color: 'var(--text-1)', lineHeight: 1.45,
            marginBottom: 10, paddingBottom: 10, borderBottom: '1px solid var(--border-1)',
          }}>
            {incident.aiSummary.headline}
          </div>

          {/* Probable cause */}
          {incident.aiSummary.probableCauses?.[0] && (
            <div style={{
              background: 'rgba(167,139,250,0.08)', border: '1px solid var(--purple-border)',
              borderRadius: 4, padding: '8px 10px', marginBottom: 10,
            }}>
              <div style={{ fontWeight: 700, color: 'var(--purple)', fontSize: 11, marginBottom: 3 }}>
                PROBABLE CAUSE
              </div>
              <div style={{ color: 'var(--text-2)' }}>{incident.aiSummary.probableCauses[0]}</div>
            </div>
          )}

          {/* Investigation steps */}
          {incident.aiSummary.investigationSteps?.length > 0 && (
            <ol style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 10 }}>
              {incident.aiSummary.investigationSteps.slice(0, 4).map((step, i) => (
                <li key={i} style={{ display: 'flex', gap: 8, color: 'var(--text-2)', lineHeight: 1.4 }}>
                  <span style={{
                    width: 18, height: 18, borderRadius: '50%', flexShrink: 0,
                    background: 'var(--purple-dim)', border: '1px solid var(--purple-border)',
                    color: 'var(--purple)', fontSize: 9, fontWeight: 700,
                    display: 'flex', alignItems: 'center', justifyContent: 'center', marginTop: 1,
                  }}>{i + 1}</span>
                  <span>{step}</span>
                </li>
              ))}
            </ol>
          )}

          {/* Footer */}
          <div style={{
            display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center',
            paddingTop: 8, borderTop: '1px solid var(--border-1)',
            fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-mono)',
          }}>
            <span style={{ color: incident.aiSummary.confidence === 'HIGH' ? 'var(--green)' : 'var(--amber)' }}>
              ● {incident.aiSummary.confidence} confidence
            </span>
            {incident.aiSummary.estimatedResolutionTime && (
              <span>Est. resolution: {incident.aiSummary.estimatedResolutionTime}</span>
            )}
            {incident.aiSummary.runbookReference?.section && (
              <span>Runbook: {incident.aiSummary.runbookReference.section}</span>
            )}
          </div>
        </div>
      </div>
    );
  }

  // No summary yet — show generate button
  return (
    <div style={{
      border: '1px solid var(--border-2)', borderRadius: 6,
      padding: '14px', textAlign: 'center',
    }}>
      {error && (
        <div style={{
          background: 'var(--red-dim)', border: '1px solid var(--red-border)',
          borderRadius: 4, padding: '8px 12px', marginBottom: 12,
          fontSize: 12, color: 'var(--red)',
        }}>
          {error}
        </div>
      )}

      <div style={{ marginBottom: 10 }}>
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" style={{ opacity: 0.3, margin: '0 auto 8px', display: 'block' }}>
          <path d="M12 2a10 10 0 110 20A10 10 0 0112 2zm0 5a1 1 0 00-1 1v4a1 1 0 002 0V8a1 1 0 00-1-1zm0 8a1 1 0 100 2 1 1 0 000-2z" fill="var(--purple)"/>
        </svg>
        <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-2)', marginBottom: 4 }}>
          No AI summary yet
        </div>
        <div style={{ fontSize: 12, color: 'var(--text-3)', lineHeight: 1.5 }}>
          Generate a root cause analysis, investigation steps,<br/>
          and resolution estimate using Amazon Bedrock.
        </div>
      </div>

      <button
        onClick={handleSummarise}
        disabled={loading}
        style={{
          display: 'inline-flex', alignItems: 'center', gap: 7,
          padding: '9px 20px', borderRadius: 6,
          background: loading ? 'var(--surface-3)' : 'linear-gradient(135deg, #6B3FA0, var(--purple))',
          border: '1px solid var(--purple-border)',
          color: 'white', fontSize: 13, fontWeight: 700,
          cursor: loading ? 'not-allowed' : 'pointer',
          fontFamily: 'var(--font)', opacity: loading ? 0.7 : 1,
          transition: 'all 0.2s',
        }}
      >
        {loading ? (
          <>
            <span style={{
              width: 12, height: 12, border: '2px solid rgba(255,255,255,0.3)',
              borderTopColor: 'white', borderRadius: '50%',
              animation: 'spin 0.7s linear infinite', display: 'inline-block',
            }}/>
            Analysing with Bedrock…
          </>
        ) : (
          <>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="white">
              <path d="M12 2a10 10 0 110 20A10 10 0 0112 2zm0 5a1 1 0 00-1 1v4a1 1 0 002 0V8a1 1 0 00-1-1zm0 8a1 1 0 100 2 1 1 0 000-2z"/>
            </svg>
            ✦ Generate Summary
          </>
        )}
      </button>
      <div style={{ fontSize: 11, color: 'var(--text-4)', marginTop: 8 }}>
        Single Bedrock call · Result cached permanently
      </div>
    </div>
  );
}

export default function IncidentsView() {
  const incidents        = useStore(s => s.incidents);
  const setView          = useStore(s => s.setView);
  const [filter, setFilter]   = useState('ALL');
  const [selected, setSelected] = useState(null);
  // Local overrides for summaries generated this session
  const [summaryCache, setSummaryCache] = useState({});

  const filtered = incidents
    .filter(i => filter === 'ALL' || (filter === 'OPEN' && i.status === 'OPEN') || i.severity === filter)
    .sort((a, b) => Number(b.timestamp || 0) - Number(a.timestamp || 0));

  const open = incidents.filter(i => i.status === 'OPEN');

  // Merge store incident with any locally generated summary
  const sel = (() => {
    const base = incidents.find(i => i.incidentId === selected);
    if (!base) return null;
    const cached = summaryCache[selected];
    return cached ? { ...base, aiSummary: cached } : base;
  })();

  function label(inc) {
    const cached = summaryCache[inc.incidentId];
    if (cached?.headline) return cached.headline;
    if (inc.aiSummary?.headline) return inc.aiSummary.headline;
    const t = inc.incidentType || '';
    const m = {
      ecs_high_memory: 'ECS OutOfMemory cascade',
      alb_5xx: 'ALB 5xx error spike',
      rds_connection_exhaustion: 'RDS connection exhaustion',
      lambda_timeout: 'Lambda execution timeout',
      novel_log_pattern: 'Novel error pattern detected',
      log_volume_spike: 'Error log volume spike',
      api_throttling: 'API throttling cascade',
    };
    return (m[t] || t.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())) + ` — ${inc.accountId}`;
  }

  function handleSummaryGenerated(incidentId, summary) {
    setSummaryCache(prev => ({ ...prev, [incidentId]: summary }));
  }

  return (
    <div className="content">
      <div className="breadcrumb">
        <a onClick={() => setView('Dashboard')} style={{ cursor: 'pointer' }}>CloudOps</a>
        <svg viewBox="0 0 6 10" fill="none" stroke="currentColor" strokeWidth="1.5" width="6" height="10" strokeLinecap="round">
          <path d="M1 1l4 4-4 4"/>
        </svg>
        Incidents
      </div>

      <div className="page-hdr">
        <div>
          <h1 className="page-title">Incidents</h1>
          <div className="page-desc">
            {open.length} open · {open.filter(i => i.severity === 'HIGH').length} HIGH · {open.filter(i => i.severity === 'MEDIUM').length} MEDIUM
          </div>
        </div>
      </div>

      {/* Filter tabs */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 16, background: 'var(--surface-2)', padding: 4, borderRadius: 6, width: 'fit-content' }}>
        {['ALL', 'OPEN', 'HIGH', 'MEDIUM'].map(f => (
          <button key={f} onClick={() => setFilter(f)} style={{
            padding: '5px 14px', borderRadius: 4, border: 'none', cursor: 'pointer',
            fontSize: 12.5, fontWeight: 500, fontFamily: 'var(--font)',
            background: filter === f ? 'var(--surface-4)' : 'transparent',
            color: filter === f ? 'var(--text-1)' : 'var(--text-3)',
            boxShadow: filter === f ? '0 1px 3px rgba(0,0,0,0.2)' : 'none',
          }}>{f}</button>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: sel ? '1fr 440px' : '1fr', gap: 16 }}>

        {/* Incident table */}
        <div className="panel">
          <div style={{ overflowX: 'auto' }}>
            <table className="aws-table">
              <thead>
                <tr>
                  <th>Severity</th>
                  <th>Summary</th>
                  <th>Account</th>
                  <th>Signals</th>
                  <th>Status</th>
                  <th>Age</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(inc => (
                  <tr
                    key={inc.incidentId}
                    style={{ cursor: 'pointer' }}
                    className={selected === inc.incidentId ? 'row-selected' : ''}
                    onClick={() => setSelected(selected === inc.incidentId ? null : inc.incidentId)}
                  >
                    <td><span className={`sev sev-${inc.severity?.[0] || 'L'}`}>{inc.severity}</span></td>
                    <td>
                      <div style={{ fontWeight: 500, fontSize: 13 }}>{label(inc)}</div>
                      {(inc.aiSummary || summaryCache[inc.incidentId])
                        ? <div style={{ fontSize: 11, color: 'var(--purple)', marginTop: 2 }}>✦ AI summary available</div>
                        : <div style={{ fontSize: 11, color: 'var(--text-4)', marginTop: 2 }}>Click to generate summary</div>
                      }
                    </td>
                    <td style={{ fontSize: 12.5, color: 'var(--text-2)', fontFamily: 'var(--font-mono)' }}>{inc.accountId}</td>
                    <td style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-1)' }}>{inc.signalCount || 0}</td>
                    <td><span className={`badge ${inc.status === 'OPEN' ? 'badge-red' : 'badge-green'}`}>{inc.status}</span></td>
                    <td style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-3)' }}>{timeAgo(inc.timestamp)}</td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr><td colSpan={6} className="empty-state">No incidents matching filter.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Detail panel */}
        {sel && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>

            {/* Incident metadata */}
            <div className="panel" style={{ height: 'fit-content' }}>
              <div className="panel-hdr">
                <div className="panel-title">Incident Detail</div>
                <button onClick={() => setSelected(null)} style={{
                  background: 'none', border: 'none', cursor: 'pointer',
                  fontSize: 18, color: 'var(--text-3)', lineHeight: 1,
                }}>×</button>
              </div>
              <div className="panel-body" style={{ fontSize: 13 }}>
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 12 }}>
                  <span className={`sev sev-${sel.severity?.[0] || 'L'}`}>{sel.severity}</span>
                  <span className={`badge ${sel.status === 'OPEN' ? 'badge-red' : 'badge-green'}`}>{sel.status}</span>
                </div>
                <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 8, color: 'var(--text-1)' }}>
                  {label(sel)}
                </div>
                <div style={{ color: 'var(--text-3)', fontSize: 11.5, marginBottom: 14, fontFamily: 'var(--font-mono)' }}>
                  {sel.incidentId}
                </div>
                <table style={{ width: '100%', fontSize: 12.5, marginBottom: 12, borderCollapse: 'collapse' }}>
                  <tbody>
                    {[
                      ['Account',  sel.accountId],
                      ['Signals',  sel.signalCount],
                      ['Detected', timeAgo(sel.timestamp)],
                      ['Type',     sel.incidentType],
                    ].map(([k, v]) => (
                      <tr key={k}>
                        <td style={{ color: 'var(--text-3)', paddingBottom: 6, paddingRight: 16, whiteSpace: 'nowrap' }}>{k}</td>
                        <td style={{ fontWeight: 500, color: 'var(--text-1)', fontFamily: k === 'Type' ? 'var(--font-mono)' : 'inherit', fontSize: k === 'Type' ? 11 : 13 }}>{v}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                {/* Blast radius */}
                {sel.blastRadius?.directlyAffected?.length > 0 && (
                  <div style={{
                    background: 'var(--red-dim)', border: '1px solid var(--red-border)',
                    borderRadius: 4, padding: '8px 12px', fontSize: 12,
                  }}>
                    <div style={{ fontWeight: 700, color: 'var(--red)', marginBottom: 4 }}>Blast Radius</div>
                    <div>Direct: {sel.blastRadius.directlyAffected.join(', ')}</div>
                    {sel.blastRadius.potentiallyAffected?.length > 0 && (
                      <div style={{ color: 'var(--text-2)', marginTop: 3 }}>
                        Downstream: {sel.blastRadius.potentiallyAffected.join(', ')}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* AI Summary panel — on demand */}
            <AISummaryPanel
              incident={sel}
              onSummaryGenerated={handleSummaryGenerated}
            />

          </div>
        )}
      </div>
    </div>
  );
}
