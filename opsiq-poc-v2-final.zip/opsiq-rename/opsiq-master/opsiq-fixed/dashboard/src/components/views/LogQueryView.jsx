import { useMemo, useState } from 'react';
import { useStore } from '../../store.js';

const SAVED_QUERIES = [
  { label: 'Recent errors', query: 'level:error OR exception', severity: 'ERROR' },
  { label: 'Timeouts', query: 'timeout OR timed out OR deadline', severity: 'ALL' },
  { label: '5xx responses', query: '5xx OR status:500 OR alb_5xx', severity: 'HIGH' },
  { label: 'Novel patterns', query: 'novel_log_pattern OR signature:unknown', severity: 'ALL' },
];

const QUERY_CHIPS = ['error', 'timeout', '5xx', 'memory', 'deploy', 'novel'];

function timeAgo(ts) {
  if (!ts) return 'unknown';
  const minutes = Math.floor((Date.now() - Number(ts)) / 60000);
  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes}m ago`;
  return `${Math.floor(minutes / 60)}h ago`;
}

function formatTime(ts) {
  if (!ts) return '--';
  return new Date(Number(ts)).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function normalizeSeverity(severity) {
  if (severity === 'HIGH') return 'ERROR';
  if (severity === 'MEDIUM') return 'WARN';
  if (severity === 'LOW') return 'INFO';
  return severity || 'INFO';
}

function messageForSignal(signal) {
  const type = signal.anomalyType || 'signal';
  const detail = signal.description || signal.signature || signal.message || signal.resource || signal.logGroup;
  if (detail) return detail;
  return type.replace(/_/g, ' ');
}

function sourceForSignal(signal) {
  return signal.logGroup || signal.resource || signal.source?.replace('opsiq.', '') || 'opsiq.detector';
}

function buildLogRows(anomalies) {
  return anomalies.map((signal, index) => ({
    id: `${signal.accountId || 'account'}-${signal.timestamp || index}-${index}`,
    timestamp: signal.timestamp,
    age: timeAgo(signal.timestamp),
    level: normalizeSeverity(signal.severity),
    accountId: signal.accountId || 'unknown',
    source: sourceForSignal(signal),
    eventType: signal.anomalyType || 'log_signal',
    message: messageForSignal(signal),
  }));
}

function bucketRows(rows) {
  const buckets = Array.from({ length: 12 }, (_, index) => ({ index, count: 0, error: 0, warn: 0, info: 0 }));
  if (!rows.length) return buckets;
  const timestamps = rows.map(row => Number(row.timestamp || Date.now()));
  const min = Math.min(...timestamps);
  const max = Math.max(...timestamps);
  const span = Math.max(max - min, 1);
  rows.forEach(row => {
    const timestamp = Number(row.timestamp || Date.now());
    const index = Math.min(11, Math.floor(((timestamp - min) / span) * 12));
    buckets[index].count += 1;
    buckets[index][row.level.toLowerCase()] += 1;
  });
  return buckets;
}

function topValues(rows, key) {
  const counts = rows.reduce((acc, row) => {
    acc[row[key]] = (acc[row[key]] || 0) + 1;
    return acc;
  }, {});
  return Object.entries(counts)
    .map(([label, count]) => ({ label, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);
}

function LogVolumeChart({ buckets }) {
  const max = Math.max(...buckets.map(bucket => bucket.count), 1);
  return (
    <div className="log-volume-chart" aria-label="Log event volume">
      {buckets.map(bucket => (
        <div className="log-volume-bar" key={bucket.index}>
          <span
            className="log-volume-fill log-volume-info"
            style={{height: `${(bucket.info / max) * 100}%`}}
          />
          <span
            className="log-volume-fill log-volume-warn"
            style={{height: `${(bucket.warn / max) * 100}%`}}
          />
          <span
            className="log-volume-fill log-volume-error"
            style={{height: `${(bucket.error / max) * 100}%`}}
          />
        </div>
      ))}
    </div>
  );
}

export default function LogQueryView() {
  const anomalies = useStore(s => s.anomalies);
  const accounts = useStore(s => s.accounts);
  const setView = useStore(s => s.setView);
  const [query, setQuery] = useState('level:error OR timeout');
  const [accountId, setAccountId] = useState('ALL');
  const [severity, setSeverity] = useState('ALL');
  const [timeRange, setTimeRange] = useState('30m');
  const [hasRun, setHasRun] = useState(false);

  const rows = useMemo(() => buildLogRows(anomalies), [anomalies]);
  const filteredRows = useMemo(() => {
    const tokens = query
      .toLowerCase()
      .replace(/\bor\b/g, ' ')
      .split(/\s+/)
      .map(t => t.replace(/^(level|service|account|source):/, ''))
      .filter(Boolean);

    return rows.filter(row => {
      if (accountId !== 'ALL' && row.accountId !== accountId) return false;
      if (severity !== 'ALL' && row.level !== severity) return false;
      if (!tokens.length) return true;
      const haystack = `${row.level} ${row.accountId} ${row.source} ${row.eventType} ${row.message}`.toLowerCase();
      return tokens.some(token => haystack.includes(token));
    });
  }, [accountId, query, rows, severity]);

  const errorCount = rows.filter(row => row.level === 'ERROR').length;
  const warnCount = rows.filter(row => row.level === 'WARN').length;
  const resultErrorCount = filteredRows.filter(row => row.level === 'ERROR').length;
  const resultWarnCount = filteredRows.filter(row => row.level === 'WARN').length;
  const resultInfoCount = filteredRows.filter(row => row.level === 'INFO').length;
  const volumeBuckets = useMemo(() => bucketRows(filteredRows), [filteredRows]);
  const topSources = useMemo(() => topValues(filteredRows, 'source'), [filteredRows]);
  const topAccounts = useMemo(() => topValues(filteredRows, 'accountId'), [filteredRows]);
  const maxSourceCount = Math.max(...topSources.map(item => item.count), 1);
  const maxAccountCount = Math.max(...topAccounts.map(item => item.count), 1);

  function applySavedQuery(saved) {
    setQuery(saved.query);
    setSeverity(saved.severity);
    setHasRun(true);
  }

  function addChip(chip) {
    setQuery(value => value.trim() ? `${value.trim()} ${chip}` : chip);
  }

  return (
    <div className="content">
      <div className="breadcrumb">
        <a onClick={() => setView('Dashboard')}>CloudOps</a>
        <svg viewBox="0 0 6 10" fill="none" stroke="currentColor" strokeWidth="1.5" width="6" height="10" strokeLinecap="round"><path d="M1 1l4 4-4 4"/></svg>
        Log Search
      </div>

      <div className="page-hdr">
        <div>
          <h1 className="page-title">Log Search</h1>
          <div className="page-desc">Search collected operational logs and correlated AI SRE signals</div>
        </div>
      </div>

      <div className="log-query-grid">
        <section className="panel log-query-console fade-in">
          <div className="panel-hdr">
            <div>
              <div className="panel-title">Query Console</div>
              <div className="panel-sub">{rows.length} indexed events · {errorCount} errors · {warnCount} warnings</div>
            </div>
            <span className="badge badge-blue">{timeRange}</span>
          </div>

          <div className="panel-body">
            <div className="log-filter-bar">
              <label className="toolbar-select">
                Account
                <select value={accountId} onChange={event => setAccountId(event.target.value)}>
                  <option value="ALL">All accounts</option>
                  {accounts.map(account => (
                    <option key={account.accountId} value={account.accountId}>{account.accountId}</option>
                  ))}
                </select>
              </label>

              <label className="toolbar-select compact">
                Level
                <select value={severity} onChange={event => setSeverity(event.target.value)}>
                  <option value="ALL">All levels</option>
                  <option value="ERROR">Error</option>
                  <option value="WARN">Warn</option>
                  <option value="INFO">Info</option>
                </select>
              </label>

              <label className="toolbar-select compact">
                Time
                <select value={timeRange} onChange={event => setTimeRange(event.target.value)}>
                  <option value="15m">Last 15m</option>
                  <option value="30m">Last 30m</option>
                  <option value="1h">Last 1h</option>
                  <option value="6h">Last 6h</option>
                </select>
              </label>
            </div>

            <div className="log-search-box">
              <textarea
                value={query}
                onChange={event => setQuery(event.target.value)}
                placeholder="error OR timeout service:api account:sim-app-a"
                rows={3}
              />
              <button className="btn btn-primary" type="button" onClick={() => setHasRun(true)}>Run Query</button>
            </div>

            <div className="log-query-chips">
              {QUERY_CHIPS.map(chip => (
                <button key={chip} type="button" onClick={() => addChip(chip)}>{chip}</button>
              ))}
            </div>
          </div>
        </section>

        <aside className="panel log-saved-queries fade-in">
          <div className="panel-hdr">
            <div>
              <div className="panel-title">Saved Queries</div>
              <div className="panel-sub">Common SRE investigations</div>
            </div>
          </div>
          <div className="panel-body">
            {SAVED_QUERIES.map(saved => (
              <button key={saved.label} className="saved-query-row" type="button" onClick={() => applySavedQuery(saved)}>
                <span>{saved.label}</span>
                <code>{saved.query}</code>
              </button>
            ))}
          </div>
        </aside>
      </div>

      <section className="panel log-dashboard-panel fade-in">
        <div className="panel-hdr">
          <div>
            <div className="panel-title">Query Analytics</div>
            <div className="panel-sub">Visual summary generated from the current result set</div>
          </div>
          <span className="log-index-pill">{filteredRows.length} events</span>
        </div>

        <div className="log-dashboard-grid">
          <div className="log-visual-card log-visual-card-wide">
            <div className="log-visual-head">
              <span>Event Volume</span>
              <code>{timeRange}</code>
            </div>
            <LogVolumeChart buckets={volumeBuckets} />
            <div className="log-chart-legend">
              <span><i className="legend-error" />Error</span>
              <span><i className="legend-warn" />Warn</span>
              <span><i className="legend-info" />Info</span>
            </div>
          </div>

          <div className="log-visual-card">
            <div className="log-visual-head">
              <span>Severity Mix</span>
              <code>{filteredRows.length || 0}</code>
            </div>
            <div className={`severity-ring${filteredRows.length ? '' : ' severity-ring-empty'}`} style={{
              '--error': `${filteredRows.length ? (resultErrorCount / filteredRows.length) * 100 : 0}%`,
              '--warn': `${filteredRows.length ? (resultWarnCount / filteredRows.length) * 100 : 0}%`,
            }}>
              <div>
                <strong>{filteredRows.length}</strong>
                <span>events</span>
              </div>
            </div>
            <div className="severity-metrics">
              <span><b>{resultErrorCount}</b> Error</span>
              <span><b>{resultWarnCount}</b> Warn</span>
              <span><b>{resultInfoCount}</b> Info</span>
            </div>
          </div>

          <div className="log-visual-card">
            <div className="log-visual-head">
              <span>Top Sources</span>
              <code>by count</code>
            </div>
            <div className="log-rank-list">
              {(topSources.length ? topSources : [{ label: 'No sources', count: 0 }]).map(item => (
                <div className="log-rank-row" key={item.label}>
                  <div>
                    <span>{item.label}</span>
                    <code>{item.count}</code>
                  </div>
                  <i style={{width: `${(item.count / maxSourceCount) * 100}%`}} />
                </div>
              ))}
            </div>
          </div>

          <div className="log-visual-card">
            <div className="log-visual-head">
              <span>Accounts</span>
              <code>impact</code>
            </div>
            <div className="log-rank-list">
              {(topAccounts.length ? topAccounts : [{ label: 'No accounts', count: 0 }]).map(item => (
                <div className="log-rank-row" key={item.label}>
                  <div>
                    <span>{item.label}</span>
                    <code>{item.count}</code>
                  </div>
                  <i style={{width: `${(item.count / maxAccountCount) * 100}%`}} />
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="panel log-results-panel fade-in">
        <div className="panel-hdr">
          <div>
            <div className="panel-title">Results</div>
            <div className="panel-sub">{filteredRows.length} matching events · {hasRun ? 'query executed' : 'previewing current filter'}</div>
          </div>
          <span className="log-index-pill">opsiq-signals-*</span>
        </div>

        <div style={{overflowX:'auto'}}>
          <table className="aws-table log-results-table">
            <thead>
              <tr>
                <th>Time</th>
                <th>Level</th>
                <th>Account</th>
                <th>Source</th>
                <th>Message</th>
              </tr>
            </thead>
            <tbody>
              {filteredRows.map(row => (
                <tr key={row.id}>
                  <td>
                    <div className="log-time">{formatTime(row.timestamp)}</div>
                    <div className="log-age">{row.age}</div>
                  </td>
                  <td><span className={`log-level log-level-${row.level.toLowerCase()}`}>{row.level}</span></td>
                  <td className="log-account">{row.accountId}</td>
                  <td><code className="log-source">{row.source}</code></td>
                  <td>
                    <div className="log-message">{row.message}</div>
                    <div className="log-event-type">{row.eventType}</div>
                  </td>
                </tr>
              ))}
              {filteredRows.length === 0 && (
                <tr>
                  <td colSpan={5} className="empty-state">
                    {rows.length === 0
                      ? 'No log events available. Connect telemetry or run the demo scenario to populate log search.'
                      : 'No events match the current query.'}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
