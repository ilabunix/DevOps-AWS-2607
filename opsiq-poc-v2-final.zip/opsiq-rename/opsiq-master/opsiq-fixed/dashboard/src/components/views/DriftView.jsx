import { useStore } from '../../store.js';
const DRIFT_DATA={'sim-app-a':[{type:'UNMANAGED',name:'temp-sg-debug',resourceType:'aws_security_group',severity:'MEDIUM',detail:'Created manually during incident — not in Terraform state',detectedAt:'2h ago'},{type:'MISSING',name:'backup-lambda',resourceType:'aws_lambda_function',severity:'LOW',detail:'Present in tfstate but not found in account',detectedAt:'2h ago'}],'sim-app-b':[{type:'UNMANAGED',name:'test-dynamodb-table',resourceType:'aws_dynamodb_table',severity:'LOW',detail:'Created by developer for testing, never added to tfstate',detectedAt:'2h ago'}],'sim-app-c':[{type:'MISSING',name:'redis-replica',resourceType:'aws_elasticache_cluster',severity:'MEDIUM',detail:'Removed from config but not deleted from account',detectedAt:'2h ago'}]};
export default function DriftView() {
  const accounts=useStore(s=>s.accounts);
  const setView=useStore(s=>s.setView);
  const allDrifts=accounts.flatMap(a=>(DRIFT_DATA[a.accountId]||[]).map(d=>({...d,accountId:a.accountId})));
  return (
    <div className="content">
      <div className="breadcrumb"><a onClick={()=>setView('Dashboard')} style={{cursor:'pointer'}}>CloudOps</a><svg viewBox="0 0 6 10" fill="none" stroke="currentColor" strokeWidth="1.5" width="6" height="10" strokeLinecap="round"><path d="M1 1l4 4-4 4"/></svg>Drift Detection</div>
      <div className="page-hdr"><div><h1 className="page-title">Infrastructure Drift Detection</h1><div className="page-desc">{allDrifts.length} drifts detected · Last check: 2h ago</div></div></div>
      <div className="panel"><div style={{overflowX:'auto'}}>
        <table className="aws-table">
          <thead><tr><th>Type</th><th>Resource</th><th>Resource Type</th><th>Account</th><th>Detail</th><th>Severity</th><th>Detected</th></tr></thead>
          <tbody>
            {allDrifts.map((d,i)=>(
              <tr key={i}>
                <td><span className={`drift-tag ${d.type==='UNMANAGED'?'dt-unmanaged':'dt-missing'}`}>{d.type}</span></td>
                <td style={{fontWeight:600}}>{d.name}</td>
                <td><span className="drift-chip">{d.resourceType}</span></td>
                <td style={{fontSize:12.5}}>{d.accountId}</td>
                <td style={{fontSize:12.5,color:'var(--text-2)',maxWidth:260}}>{d.detail}</td>
                <td><span className={`sev sev-${d.severity?.[0]||'L'}`}>{d.severity}</span></td>
                <td style={{fontSize:11.5,color:'var(--text-3)'}}>{d.detectedAt}</td>
              </tr>
            ))}
            {allDrifts.length===0&&<tr><td colSpan={7} className="empty-state">No drift detected.</td></tr>}
          </tbody>
        </table>
      </div></div>
    </div>
  );
}
