/**
 * IncidentTimelineView.jsx — Phase 2
 *
 * ZERO Bedrock calls. Pure frontend — reads existing incident + anomaly
 * data already in the Zustand store. No new API calls.
 *
 * Shows: when the incident started, signal velocity over time,
 * severity escalation, and current status.
 */
import { useState, useMemo } from 'react';
import { useStore } from '../../store.js';

function timeAgo(ts) {
  if (!ts) return '—';
  const m = Math.floor((Date.now() - Number(ts)) / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m}m ago`;
  if (m < 1440) return `${Math.floor(m / 60)}h ago`;
  return `${Math.floor(m / 1440)}d ago`;
}

function fmtTime(ts) {
  if (!ts) return '';
  return new Date(Number(ts)).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
}

function SeverityDot({ sev }) {
  const c = sev === 'HIGH' ? 'var(--red)' : sev === 'MEDIUM' ? 'var(--amber)' : 'var(--green)';
  return <span style={{ display: 'inline-block', width: 8, height: 8, borderRadius: '50%', background: c, flexShrink: 0 }} />;
}

// Mini sparkline using SVG — no library needed
function Sparkline({ points, width = 120, height = 36 }) {
  if (!points || points.length < 2) return (
    <div style={{ width, height, display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontSize: 10, color: 'var(--text-4)' }}>no data</div>
  );
  const max = Math.max(...points, 1);
  const xs = points.map((_, i) => (i / (points.length - 1)) * width);
  const ys = points.map(v => height - (v / max) * (height - 4) - 2);
  const d = xs.map((x, i) => `${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${ys[i].toFixed(1)}`).join(' ');
  const fill = `${d} L${width},${height} L0,${height} Z`;
  return (
    <svg width={width} height={height} style={{ overflow: 'visible' }}>
      <defs>
        <linearGradient id="spk" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="var(--purple)" stopOpacity="0.4"/>
          <stop offset="100%" stopColor="var(--purple)" stopOpacity="0"/>
        </linearGradient>
      </defs>
      <path d={fill} fill="url(#spk)" />
      <path d={d} fill="none" stroke="var(--purple)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      {/* Last point dot */}
      <circle cx={xs[xs.length-1]} cy={ys[ys.length-1]} r="3" fill="var(--purple)"/>
    </svg>
  );
}

function TimelineRow({ incident, isSelected, onClick }) {
  const ts = Number(incident.timestamp || 0);
  const age = Math.floor((Date.now() - ts) / 60000);

  // Simulate signal velocity buckets (5 buckets of ~3 min each from signalCount)
  // We don't have per-minute data but can approximate a ramp pattern
  const count = Number(incident.signalCount || 0);
  const pts = [0, Math.round(count*0.1), Math.round(count*0.35), Math.round(count*0.75), count];

  return (
    <div onClick={onClick} style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '10px 14px', cursor: 'pointer',
      background: isSelected ? 'var(--surface-3)' : 'transparent',
      borderLeft: `3px solid ${isSelected ? 'var(--purple)' : 'transparent'}`,
      transition: 'background 0.15s',
    }}
      onMouseEnter={e => { if (!isSelected) e.currentTarget.style.background = 'var(--surface-2)'; }}
      onMouseLeave={e => { if (!isSelected) e.currentTarget.style.background = 'transparent'; }}
    >
      <SeverityDot sev={incident.severity} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontWeight: 600, fontSize: 12.5, color: 'var(--text-1)',
          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
          {(incident.incidentType || 'unknown').replace(/_/g, ' ')}
        </div>
        <div style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-mono)' }}>
          {incident.accountId}
        </div>
      </div>
      <Sparkline points={pts} width={80} height={28} />
      <div style={{ textAlign: 'right', flexShrink: 0 }}>
        <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-1)',
          fontFamily: 'var(--font-mono)' }}>{incident.signalCount}</div>
        <div style={{ fontSize: 10, color: 'var(--text-4)' }}>signals</div>
      </div>
      <div style={{ fontSize: 10.5, color: 'var(--text-3)', flexShrink: 0, minWidth: 52,
        textAlign: 'right' }}>{timeAgo(incident.timestamp)}</div>
    </div>
  );
}

function TimelineDetail({ incident, anomalies }) {
  const ts = Number(incident.timestamp || 0);
  const accAnomalies = anomalies
    .filter(a => a.accountId === incident.accountId)
    .sort((a, b) => Number(a.timestamp || 0) - Number(b.timestamp || 0));

  // Build timeline events
  const events = [];

  // Incident created
  events.push({ ts, label: 'Incident detected', detail: `${incident.signalCount} signals correlated`, type: 'incident', icon: '⚡' });

  // Anomalies as events (up to 6)
  accAnomalies.slice(0, 6).forEach(a => {
    events.push({
      ts: Number(a.timestamp || 0),
      label: (a.anomalyType || 'anomaly').replace(/_/g, ' '),
      detail: a.description || a.message || a.signature || '',
      type: a.severity?.toLowerCase() || 'medium',
      icon: a.severity === 'HIGH' ? '🔴' : a.severity === 'MEDIUM' ? '🟡' : '🟢',
    });
  });

  // AI summary event if exists
  if (incident.aiSummary) {
    events.push({
      ts: Number(incident.summarisedAt || ts + 60000),
      label: 'AI summary generated',
      detail: incident.aiSummary.headline || '',
      type: 'ai',
      icon: '✦',
    });
  }

  events.sort((a, b) => a.ts - b.ts);

  const blast = incident.blastRadius || {};

  return (
    <div style={{ padding: '16px 20px', height: '100%', overflowY: 'auto' }}>
      {/* Header */}
      <div style={{ marginBottom: 20 }}>
        <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
          <span style={{
            padding: '2px 8px', borderRadius: 3, fontSize: 11, fontWeight: 700,
            background: incident.severity === 'HIGH' ? 'var(--red-dim)' : 'var(--amber-dim)',
            color: incident.severity === 'HIGH' ? 'var(--red)' : 'var(--amber)',
            border: `1px solid ${incident.severity === 'HIGH' ? 'var(--red-border)' : 'var(--amber-border)'}`,
          }}>{incident.severity}</span>
          <span style={{
            padding: '2px 8px', borderRadius: 3, fontSize: 11, fontWeight: 700,
            background: 'var(--surface-3)', color: 'var(--text-2)',
            border: '1px solid var(--border-2)',
          }}>{incident.status}</span>
        </div>
        <div style={{ fontWeight: 700, fontSize: 16, color: 'var(--text-1)', marginBottom: 4 }}>
          {(incident.incidentType || 'unknown').replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}
        </div>
        <div style={{ fontSize: 12, color: 'var(--text-3)', fontFamily: 'var(--font-mono)' }}>
          {incident.accountId} · {incident.signalCount} signals · started {timeAgo(incident.timestamp)}
        </div>
      </div>

      {/* Stats row */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
        {[
          { label: 'Signals', value: incident.signalCount, color: 'var(--text-1)' },
          { label: 'Age', value: `${Math.floor((Date.now() - Number(incident.timestamp || Date.now())) / 60000)}m`, color: 'var(--text-1)' },
          { label: 'Affected', value: blast.resourceCount || 0, color: blast.resourceCount > 0 ? 'var(--amber)' : 'var(--text-2)' },
        ].map(({ label, value, color }) => (
          <div key={label} style={{
            flex: 1, padding: '10px 12px', background: 'var(--surface-2)',
            border: '1px solid var(--border-1)', borderRadius: 6, textAlign: 'center',
          }}>
            <div style={{ fontSize: 20, fontWeight: 800, color, fontFamily: 'var(--font-mono)' }}>{value}</div>
            <div style={{ fontSize: 10, color: 'var(--text-4)', marginTop: 2 }}>{label}</div>
          </div>
        ))}
      </div>

      {/* Timeline */}
      <div style={{ marginBottom: 20 }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-3)',
          textTransform: 'uppercase', letterSpacing: '0.6px', marginBottom: 12 }}>
          Event Timeline
        </div>
        <div style={{ position: 'relative' }}>
          {/* Vertical line */}
          <div style={{
            position: 'absolute', left: 11, top: 12, bottom: 0,
            width: 1, background: 'var(--border-2)',
          }}/>
          {events.map((ev, i) => (
            <div key={i} style={{ display: 'flex', gap: 12, marginBottom: 16, position: 'relative' }}>
              <div style={{
                width: 24, height: 24, borderRadius: '50%', flexShrink: 0,
                background: ev.type === 'incident' ? 'var(--surface-4)' : 'var(--surface-3)',
                border: `1px solid ${ev.type === 'incident' ? 'var(--purple-border)' : 'var(--border-2)'}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 10, zIndex: 1,
              }}>{ev.icon}</div>
              <div style={{ flex: 1, paddingTop: 2 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                  <span style={{ fontWeight: 600, fontSize: 12.5, color: 'var(--text-1)' }}>{ev.label}</span>
                  <span style={{ fontSize: 10, color: 'var(--text-4)', fontFamily: 'var(--font-mono)',
                    flexShrink: 0, marginLeft: 8 }}>{fmtTime(ev.ts)}</span>
                </div>
                {ev.detail && (
                  <div style={{ fontSize: 11.5, color: 'var(--text-3)', marginTop: 2, lineHeight: 1.4 }}>
                    {ev.detail.slice(0, 120)}{ev.detail.length > 120 ? '…' : ''}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Blast radius */}
      {(blast.directlyAffected?.length > 0) && (
        <div style={{
          padding: '10px 12px', background: 'var(--red-dim)',
          border: '1px solid var(--red-border)', borderRadius: 6, marginBottom: 12,
        }}>
          <div style={{ fontWeight: 700, fontSize: 11, color: 'var(--red)', marginBottom: 4 }}>Blast Radius</div>
          <div style={{ fontSize: 12, color: 'var(--text-2)' }}>
            {blast.directlyAffected.join(', ')}
          </div>
          {blast.potentiallyAffected?.length > 0 && (
            <div style={{ fontSize: 11.5, color: 'var(--text-3)', marginTop: 3 }}>
              Downstream: {blast.potentiallyAffected.join(', ')}
            </div>
          )}
        </div>
      )}

      {/* AI summary if available */}
      {incident.aiSummary && (
        <div style={{
          padding: '10px 12px', background: 'var(--purple-dim)',
          border: '1px solid var(--purple-border)', borderRadius: 6,
        }}>
          <div style={{ fontWeight: 700, fontSize: 11, color: 'var(--purple)', marginBottom: 6 }}>
            ✦ AI Root Cause
          </div>
          <div style={{ fontSize: 12.5, color: 'var(--text-1)', marginBottom: 6, fontWeight: 500 }}>
            {incident.aiSummary.headline}
          </div>
          {incident.aiSummary.probableCauses?.[0] && (
            <div style={{ fontSize: 12, color: 'var(--text-2)' }}>
              {incident.aiSummary.probableCauses[0]}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function IncidentTimelineView() {
  const incidents = useStore(s => s.incidents);
  const anomalies = useStore(s => s.anomalies);
  const setView   = useStore(s => s.setView);
  const [selId, setSelId]       = useState(null);
  const [filter, setFilter]     = useState('ALL');
  const [search, setSearch]     = useState('');

  const sorted = useMemo(() => {
    return [...incidents]
      .filter(i => filter === 'ALL' || i.severity === filter || (filter === 'OPEN' && i.status === 'OPEN'))
      .filter(i => !search || i.accountId?.includes(search) || i.incidentType?.includes(search))
      .sort((a, b) => Number(b.timestamp || 0) - Number(a.timestamp || 0));
  }, [incidents, filter, search]);

  const selected = sorted.find(i => i.incidentId === selId);

  return (
    <div className="content" style={{ padding: 0, height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <div style={{
        padding: '14px 20px', borderBottom: '1px solid var(--border-1)',
        background: 'var(--surface-1)', flexShrink: 0,
        display: 'flex', alignItems: 'center', gap: 12,
      }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 2 }}>
            <a onClick={() => setView('Dashboard')} style={{ fontSize: 11, color: 'var(--text-3)', cursor: 'pointer' }}>CloudOps</a>
            <span style={{ fontSize: 11, color: 'var(--text-4)' }}>›</span>
            <span style={{ fontSize: 11, color: 'var(--text-2)' }}>Incident Timeline</span>
          </div>
          <div style={{ fontWeight: 700, fontSize: 15, color: 'var(--text-1)' }}>Incident Timeline</div>
          <div style={{ fontSize: 11, color: 'var(--text-3)' }}>
            {sorted.length} incidents · {sorted.filter(i => i.status === 'OPEN').length} open · zero Bedrock calls
          </div>
        </div>
        <div style={{ marginLeft: 'auto', display: 'flex', gap: 8 }}>
          <input
            placeholder="Search account or type…"
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{
              padding: '6px 12px', borderRadius: 6, border: '1px solid var(--border-2)',
              background: 'var(--surface-2)', color: 'var(--text-1)',
              fontSize: 12, fontFamily: 'var(--font)', outline: 'none', width: 200,
            }}
          />
          {['ALL', 'OPEN', 'HIGH', 'MEDIUM'].map(f => (
            <button key={f} onClick={() => setFilter(f)} style={{
              padding: '5px 12px', borderRadius: 5, border: 'none', cursor: 'pointer',
              fontSize: 11.5, fontWeight: 500, fontFamily: 'var(--font)',
              background: filter === f ? 'var(--surface-4)' : 'var(--surface-2)',
              color: filter === f ? 'var(--text-1)' : 'var(--text-3)',
              border: `1px solid ${filter === f ? 'var(--border-3)' : 'var(--border-1)'}`,
            }}>{f}</button>
          ))}
        </div>
      </div>

      {/* Body */}
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        {/* List */}
        <div style={{
          width: selected ? 380 : '100%', borderRight: selected ? '1px solid var(--border-1)' : 'none',
          overflowY: 'auto', flexShrink: 0,
        }}>
          {sorted.length === 0 ? (
            <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-3)', fontSize: 13 }}>
              No incidents matching filter.<br/>
              <span style={{ fontSize: 11, color: 'var(--text-4)' }}>Run demo-on.sh to generate incidents.</span>
            </div>
          ) : sorted.map(inc => (
            <TimelineRow
              key={inc.incidentId}
              incident={inc}
              isSelected={inc.incidentId === selId}
              onClick={() => setSelId(selId === inc.incidentId ? null : inc.incidentId)}
            />
          ))}
        </div>

        {/* Detail */}
        {selected && (
          <div style={{ flex: 1, overflowY: 'auto' }}>
            <div style={{ display: 'flex', justifyContent: 'flex-end', padding: '8px 16px 0',
              position: 'sticky', top: 0, background: 'var(--canvas)', zIndex: 1 }}>
              <button onClick={() => setSelId(null)} style={{
                background: 'none', border: '1px solid var(--border-2)', borderRadius: 5,
                padding: '4px 10px', cursor: 'pointer', fontSize: 11,
                color: 'var(--text-3)', fontFamily: 'var(--font)',
              }}>✕ Close</button>
            </div>
            <TimelineDetail incident={selected} anomalies={anomalies} />
          </div>
        )}
      </div>
    </div>
  );
}
