import { useStore } from '../../store.js';
import TopologyGraph from '../TopologyGraph.jsx';
export default function TopologyView() {
  const accounts=useStore(s=>s.accounts);
  const selectedAccountId=useStore(s=>s.selectedAccountId);
  const setSelectedAccount=useStore(s=>s.setSelectedAccount);
  const setView=useStore(s=>s.setView);
  return (
    <div className="content">
      <div className="breadcrumb"><a onClick={()=>setView('Dashboard')} style={{cursor:'pointer'}}>CloudOps</a><svg viewBox="0 0 6 10" fill="none" stroke="currentColor" strokeWidth="1.5" width="6" height="10" strokeLinecap="round"><path d="M1 1l4 4-4 4"/></svg>Topology</div>
      <div className="page-hdr"><div><h1 className="page-title">Infrastructure Topology</h1><div className="page-desc">Select an account · Scroll to zoom · Drag to pan</div></div></div>
      <div style={{display:'flex',gap:8,marginBottom:16}}>
        {accounts.map(acc=>(
          <button key={acc.accountId} onClick={()=>setSelectedAccount(acc.accountId)} style={{padding:'6px 14px',borderRadius:6,border:'1px solid',cursor:'pointer',fontSize:12.5,fontWeight:selectedAccountId===acc.accountId?700:400,background:selectedAccountId===acc.accountId?'var(--blue-bg)':'white',borderColor:selectedAccountId===acc.accountId?'var(--blue)':'var(--border)',color:selectedAccountId===acc.accountId?'var(--blue)':'var(--text-2)'}}>
            {acc.accountId}
          </button>
        ))}
      </div>
      <div className="panel">
        <div className="panel-hdr"><div><div className="panel-title">Topology — {selectedAccountId||'Select an account'}</div><div className="panel-sub">Terraform state · Dependency graph · Color = resource tier</div></div></div>
        <div style={{padding:16,background:'#FAFAFA'}}><TopologyGraph compact={false}/></div>
        <div style={{display:'flex',gap:16,padding:'8px 16px 12px',flexWrap:'wrap'}}>
          {[['ingress','#0972D3'],['compute','#D13212'],['data','#946600'],['storage','#067940'],['other','#8A8A8A']].map(([tier,color])=>(
            <div key={tier} style={{display:'flex',alignItems:'center',gap:5,fontSize:11.5,color:'var(--text-2)'}}>
              <div style={{width:10,height:3,background:color,borderRadius:2}}/>{tier}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
