import { useStore } from '../../store.js';
export default function AccountsView() {
  const accounts=useStore(s=>s.accounts);
  const incidents=useStore(s=>s.incidents);
  const anomalies=useStore(s=>s.anomalies);
  const setView=useStore(s=>s.setView);
  const setSelectedAccount=useStore(s=>s.setSelectedAccount);
  return (
    <div className="content">
      <div className="breadcrumb"><a onClick={()=>setView('Dashboard')} style={{cursor:'pointer'}}>CloudOps</a><svg viewBox="0 0 6 10" fill="none" stroke="currentColor" strokeWidth="1.5" width="6" height="10" strokeLinecap="round"><path d="M1 1l4 4-4 4"/></svg>Accounts</div>
      <div className="page-hdr"><div><h1 className="page-title">Account Health</h1><div className="page-desc">{accounts.length} accounts monitored</div></div></div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(280px,1fr))',gap:16}}>
        {accounts.map(acc=>{
          const score=Number(acc.score||0);
          const color=score>=80?'var(--green)':score>=60?'var(--amber)':'var(--red)';
          const incs=incidents.filter(i=>i.accountId===acc.accountId&&i.status==='OPEN').length;
          const anoms=anomalies.filter(a=>a.accountId===acc.accountId).length;
          return (
            <div key={acc.accountId} className="panel" style={{cursor:'pointer',borderTop:`3px solid ${color}`}} onClick={()=>{setSelectedAccount(acc.accountId);setView('Dashboard');}}>
              <div className="panel-body">
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:12}}>
                  <div style={{fontWeight:700,fontSize:15}}>{acc.accountId}</div>
                  <span className={`badge ${score>=80?'badge-green':score>=60?'badge-amber':'badge-red'}`}>{score>=80?'Healthy':score>=60?'Warning':'Critical'}</span>
                </div>
                <div style={{fontSize:36,fontWeight:800,color,letterSpacing:-1,lineHeight:1,marginBottom:8}}>{score}</div>
                <div style={{height:4,background:'var(--border-light)',borderRadius:2,marginBottom:12,overflow:'hidden'}}><div style={{width:`${score}%`,height:'100%',background:color,borderRadius:2}}/></div>
                <div style={{display:'flex',gap:16,fontSize:12,color:'var(--text-2)'}}>
                  <span><strong style={{color:incs>0?'var(--red)':'var(--text)'}}>{incs}</strong> incidents</span>
                  <span><strong style={{color:anoms>3?'var(--amber)':'var(--text)'}}>{anoms}</strong> anomalies</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
