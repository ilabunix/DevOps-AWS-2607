import { useStore } from '../../store.js';
const RUNBOOKS=[
  {title:'ECS High Memory / OutOfMemoryError',path:'runbooks/ecs/high-memory.md',tags:['ECS','OOM','Memory'],severity:'HIGH',description:'Java heap exhaustion, task restart loops, RDS connection leaks from OOM restarts.'},
  {title:'ECS High CPU Utilization',path:'runbooks/ecs/high-cpu.md',tags:['ECS','CPU'],severity:'MEDIUM',description:'Sustained CPU throttling, traffic spikes, runaway processes.'},
  {title:'ALB 5xx Error Spike',path:'runbooks/alb/5xx-spike.md',tags:['ALB','5xx','HTTP'],severity:'HIGH',description:'Upstream target failures, ELB capacity issues, unhealthy target groups.'},
  {title:'RDS Connection Exhaustion',path:'runbooks/rds/connection-exhaustion.md',tags:['RDS','Aurora','Database'],severity:'HIGH',description:'Connection pool overflow, leaked connections, max_connections limits.'},
  {title:'CloudTrail Unusual API Activity',path:'runbooks/cloudtrail/unusual-api-activity.md',tags:['Security','IAM','CloudTrail'],severity:'HIGH',description:'Unexpected API calls, access key misuse, privilege escalation indicators.'},
];
const SEV={HIGH:'badge-red',MEDIUM:'badge-amber',LOW:'badge-blue'};
export default function RunbooksView() {
  const setView=useStore(s=>s.setView);
  return (
    <div className="content">
      <div className="breadcrumb"><a onClick={()=>setView('Dashboard')} style={{cursor:'pointer'}}>CloudOps</a><svg viewBox="0 0 6 10" fill="none" stroke="currentColor" strokeWidth="1.5" width="6" height="10" strokeLinecap="round"><path d="M1 1l4 4-4 4"/></svg>Runbooks</div>
      <div className="page-hdr"><div><h1 className="page-title">Operational Runbooks</h1><div className="page-desc">{RUNBOOKS.length} runbooks · Stored in S3 · Auto-selected by AI per incident type</div></div></div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
        {RUNBOOKS.map((rb,i)=>(
          <div key={i} className="panel">
            <div className="panel-body">
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:8}}>
                <div style={{fontWeight:700,fontSize:13.5,lineHeight:1.35}}>{rb.title}</div>
                <span className={`badge ${SEV[rb.severity]}`} style={{flexShrink:0,marginLeft:8}}>{rb.severity}</span>
              </div>
              <div style={{fontSize:12.5,color:'var(--text-2)',marginBottom:10,lineHeight:1.4}}>{rb.description}</div>
              <div style={{display:'flex',gap:6,flexWrap:'wrap',marginBottom:10}}>
                {rb.tags.map(t=><span key={t} style={{fontSize:11,padding:'2px 7px',background:'var(--blue-bg)',color:'var(--blue)',borderRadius:3,border:'1px solid var(--blue-border)'}}>{t}</span>)}
              </div>
              <div style={{fontFamily:'monospace',fontSize:10.5,color:'var(--text-3)',background:'var(--bg)',padding:'3px 7px',borderRadius:3,display:'inline-block'}}>{rb.path}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
