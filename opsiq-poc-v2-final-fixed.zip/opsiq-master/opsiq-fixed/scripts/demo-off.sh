#!/bin/bash
# Disable all OpsIQ services after a demo
# Run this IMMEDIATELY after the demo ends to stop Bedrock charges

REGION=us-west-2

echo "═══════════════════════════════════════"
echo "  OpsIQ — DEMO MODE OFF"
echo "  Stopping all signal processing..."
echo "═══════════════════════════════════════"

# Disable SQS triggers FIRST (stop new signals being processed)
for FUNC in opsiq-log-processor opsiq-correlator; do
  UUID=$(aws lambda list-event-source-mappings \
    --function-name $FUNC --region $REGION \
    --query 'EventSourceMappings[0].UUID' --output text 2>/dev/null)
  if [ -n "$UUID" ] && [ "$UUID" != "None" ]; then
    aws lambda update-event-source-mapping \
      --uuid $UUID --enabled false --region $REGION \
      --query 'State' --output text
    echo "  ✓ Disabled SQS trigger: $FUNC"
  fi
done

# Disable signal generation schedules
for RULE in opsiq-log-volume-schedule opsiq-pattern-schedule \
            opsiq-summariser-schedule; do
  aws events disable-rule --name $RULE --region $REGION 2>/dev/null && \
    echo "  ✓ Disabled: $RULE" || echo "  - Not found: $RULE"
done

# Keep health + seeder schedules running (no Bedrock cost)
echo "  ✓ Keeping health-schedule and extended-seeder-schedule active"

# Purge SQS queues to clear any backlog (prevents delayed Bedrock calls)
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
for QUEUE in opsiq-anomaly-queue opsiq-correlator-queue; do
  URL="https://sqs.${REGION}.amazonaws.com/${ACCOUNT_ID}/${QUEUE}"
  aws sqs purge-queue --queue-url $URL --region $REGION 2>/dev/null && \
    echo "  ✓ Purged queue: $QUEUE" || echo "  - Queue not found: $QUEUE"
done

echo ""
echo "  ✓ Demo mode OFF. Bedrock charges stopped."
echo "  Dashboard stays live with current data."
echo "═══════════════════════════════════════"
