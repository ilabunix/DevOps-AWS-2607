#!/usr/bin/env bash
# opsiq-poc/scripts/bootstrap.sh
# One-time setup: creates the Lambda code S3 bucket and validates prerequisites.
# Run this before any deploy script.
#
# Usage:
#   export AWS_PROFILE=your-govcloud-profile
#   ./scripts/bootstrap.sh
set -euo pipefail

REGION="${REGION:-us-gov-east-1}"
PROJECT="${PROJECT:-opsiq}"

echo "╔══════════════════════════════════════════════════╗"
echo "║  OpsIQ POC — Bootstrap                          ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""

# ── CHECK PREREQUISITES ────────────────────────────────────────────────────
echo "Checking prerequisites..."

command -v aws  &>/dev/null || { echo "ERROR: aws CLI not found"; exit 1; }
command -v zip  &>/dev/null || { echo "ERROR: zip not found. Install with: apt install zip"; exit 1; }
echo "  ✓ aws CLI found"
echo "  ✓ zip found"

# Verify AWS credentials work
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text 2>/dev/null) \
  || { echo "ERROR: AWS credentials not configured"; exit 1; }
echo "  ✓ AWS credentials valid | Account: $ACCOUNT_ID"

# Verify region is GovCloud
if [[ "$REGION" != us-gov-* ]]; then
  echo "  WARNING: Region $REGION does not look like GovCloud (expected us-gov-east-1 or us-gov-west-1)"
fi
echo "  ✓ Region: $REGION"

# Check Bedrock model access
echo ""
echo "Checking Bedrock model access..."
aws bedrock list-foundation-models \
  --region "$REGION" \
  --query "modelSummaries[?modelId=='us.anthropic.claude-haiku-4-5'].modelId" \
  --output text 2>/dev/null | grep -q "anthropic" \
  && echo "  ✓ Claude Sonnet model accessible" \
  || echo "  WARNING: Claude Sonnet model not found. Enable it in Bedrock console → Model Access."

# ── CREATE LAMBDA CODE BUCKET ──────────────────────────────────────────────
echo ""
LAMBDA_BUCKET="${PROJECT}-lambda-pkgs-${ACCOUNT_ID}"
echo "Creating Lambda code bucket: $LAMBDA_BUCKET"

if aws s3 ls "s3://$LAMBDA_BUCKET" --region "$REGION" &>/dev/null; then
  echo "  ✓ Bucket already exists"
else
  aws s3 mb "s3://$LAMBDA_BUCKET" --region "$REGION"
  # Block all public access
  aws s3api put-public-access-block \
    --bucket "$LAMBDA_BUCKET" \
    --public-access-block-configuration \
      "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"
  echo "  ✓ Bucket created and public access blocked"
fi

# ── DONE ───────────────────────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║  Bootstrap Complete                              ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║  Account ID    : $ACCOUNT_ID"
echo "║  Lambda bucket : $LAMBDA_BUCKET"
echo "╚══════════════════════════════════════════════════╝"
echo ""
echo "Set this for all deploy scripts:"
echo "  export LAMBDA_CODE_BUCKET=$LAMBDA_BUCKET"
echo "  export AWS_PROFILE=<your-profile>"
echo "  export REGION=$REGION"
echo ""
echo "Then run:"
echo "  ./scripts/deploy-all.sh"
