#!/usr/bin/env bash
# opsiq-poc/scripts/deploy-all.sh
# Full POC deployment: central (9 stacks) + simulation (3 stacks) + dashboard.
# Prerequisites: AWS CLI configured, Bedrock model access enabled.
#
# Usage:
#   export REGION=us-west-2        # optional — defaults to us-west-2
#   export PROJECT=opsiq           # optional — defaults to opsiq
#   ./scripts/deploy-all.sh

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

export PROJECT="${PROJECT:-opsiq}"
export REGION="${REGION:-us-west-2}"

START_TIME=$(date +%s)

echo "╔══════════════════════════════════════════════════╗"
echo "║  OpsIQ POC — Full Deployment                    ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║  Project : $PROJECT"
echo "║  Region  : $REGION"
echo "║  Stacks  : 9 central + 3 simulation = 12 total  ║"
echo "║  Est time: 15-20 minutes                        ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""

# Step 1: Central stacks 1-9
echo "═══════ PHASE 1: CENTRAL (9 stacks) ═══════"
bash "$ROOT_DIR/central/scripts/deploy-central.sh"

echo ""
echo "═══════ PHASE 2: DASHBOARD ═══════"
echo "Building and uploading dashboard..."
cd "$ROOT_DIR/dashboard"
npm install --silent 2>/dev/null || true
./rebuild.sh
cd "$ROOT_DIR"

echo ""
echo "═══════ PHASE 3: SIMULATION (3 stacks) ═══════"
bash "$ROOT_DIR/simulation/scripts/deploy-simulation.sh"

END_TIME=$(date +%s)
ELAPSED=$(( END_TIME - START_TIME ))
MINUTES=$(( ELAPSED / 60 ))
SECONDS=$(( ELAPSED % 60 ))

# Final outputs
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
CF_URL=$(aws cloudformation describe-stacks \
  --stack-name "${PROJECT}-central-storage" --region "$REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='DashboardURL'].OutputValue" \
  --output text 2>/dev/null || echo "Check CloudFormation outputs")

echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║  Full POC Deployment Complete ✓                 ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║  Time      : ${MINUTES}m ${SECONDS}s"
echo "║  Dashboard : $CF_URL"
echo "║  Account   : $ACCOUNT_ID"
echo "╠══════════════════════════════════════════════════╣"
echo "║  IMPORTANT: Bedrock calls are ON-DEMAND only.   ║"
echo "║  Signal schedules are DISABLED by default.      ║"
echo "║  Run ./scripts/demo-on.sh before a demo.        ║"
echo "║  Run ./scripts/demo-off.sh after a demo.        ║"
echo "╚══════════════════════════════════════════════════╝"
