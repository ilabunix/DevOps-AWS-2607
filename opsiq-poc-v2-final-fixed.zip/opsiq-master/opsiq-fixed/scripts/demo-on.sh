#!/bin/bash
# Enable all OpsIQ services for a live demo
# Run 10 minutes before the demo starts
# Remember to run demo-off.sh immediately after!

REGION=us-west-2
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)

echo "═══════════════════════════════════════"
echo "  OpsIQ — DEMO MODE ON"
echo "  Remember: run demo-off.sh after demo!"
echo "═══════════════════════════════════════"

# Enable EventBridge schedules
for RULE in opsiq-health-schedule opsiq-extended-seeder-schedule \
            opsiq-log-volume-schedule opsiq-pattern-schedule; do
  aws events enable-rule --name $RULE --region $REGION 2>/dev/null && \
    echo "  ✓ Enabled: $RULE" || echo "  - Not found: $RULE"
done

# Enable SQS triggers (log processor + correlator)
for FUNC in opsiq-log-processor opsiq-correlator; do
  UUID=$(aws lambda list-event-source-mappings \
    --function-name $FUNC --region $REGION \
    --query 'EventSourceMappings[0].UUID' --output text 2>/dev/null)
  if [ -n "$UUID" ] && [ "$UUID" != "None" ]; then
    aws lambda update-event-source-mapping \
      --uuid $UUID --enabled true --region $REGION \
      --query 'State' --output text
    echo "  ✓ Enabled SQS trigger: $FUNC"
  fi
done

# Seed fresh scores
aws lambda invoke --function-name opsiq-extended-seeder \
  --region $REGION /tmp/seed.json > /dev/null 2>&1 && echo "  ✓ Accounts seeded"
aws lambda invoke --function-name opsiq-manual-seeder \
  --region $REGION /tmp/seed2.json > /dev/null 2>&1 && echo "  ✓ Sim accounts seeded"

echo ""
echo "  Demo mode is ON. Signals will flow in ~2 minutes."
echo "  ⚠  Run ./demo-off.sh immediately after the demo!"
echo "═══════════════════════════════════════"
