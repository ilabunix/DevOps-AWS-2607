#!/usr/bin/env bash
# opsiq-poc/scripts/teardown-all.sh
# Full POC teardown: simulation first, then central.
# WARNING: Destroys ALL data permanently.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

export PROJECT="${PROJECT:-opsiq}"
export REGION="${REGION:-us-west-2}"

echo "╔══════════════════════════════════════════════════╗"
echo "║  OpsIQ POC — FULL TEARDOWN                      ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║  This removes ALL stacks and ALL data:           ║"
echo "║    Stack 08: opsiq-central-fixes                 ║"
echo "║    Stack 07: opsiq-central-log-anomaly           ║"
echo "║    Stack 06: opsiq-central-dashboard             ║"
echo "║    Stack 05: opsiq-central-api                   ║"
echo "║    Stack 04: opsiq-central-lambdas               ║"
echo "║    Stack 03: opsiq-central-iam                   ║"
echo "║    Stack 02: opsiq-central-ingestion             ║"
echo "║    Stack 01: opsiq-central-storage               ║"
echo "║    Sim  02: opsiq-sim-generators                 ║"
echo "║    Sim  01: opsiq-sim-data                       ║"
echo "║  Region: $REGION"
echo "╚══════════════════════════════════════════════════╝"
echo ""
echo "WARNING: This cannot be undone."
read -r -p "Type 'delete-everything' to confirm: " CONFIRM
if [[ "$CONFIRM" != "delete-everything" ]]; then
  echo "Aborted."
  exit 0
fi

echo ""
echo "Step 1/2 — Tearing down simulation..."
echo ""
# Pass confirmation automatically since we already confirmed above
echo "delete-simulation" | PROJECT=$PROJECT REGION=$REGION \
  bash "$ROOT_DIR/simulation/scripts/teardown-simulation.sh" || true

echo ""
echo "Step 2/2 — Tearing down central..."
echo ""
echo "delete-central" | PROJECT=$PROJECT REGION=$REGION \
  bash "$ROOT_DIR/central/scripts/teardown-central.sh"

echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║  Full teardown complete.                         ║"
echo "║  All OpsIQ stacks, tables, and buckets removed. ║"
echo "╚══════════════════════════════════════════════════╝"
