"""
OpsIQ Central — log_pattern_tracker.py

Detects LOG PATTERN RATE ANOMALIES — when a known log pattern suddenly
appears at a much higher rate than its established baseline.

Difference from Bloom filter (log_processor):
  - Bloom filter catches NOVEL patterns (never seen before) → fires once
  - Pattern tracker catches RATE SHIFTS on KNOWN patterns → fires when
    a familiar error suddenly spikes in frequency

Example:
  'Connection timeout' appears 2x per hour normally.
  Suddenly appears 180x in 5 minutes → rate anomaly → HIGH severity

Algorithm:
  - Bloom filter stores every seen pattern hash (existing)
  - Pattern tracker stores COUNT per pattern hash per time window
  - Compares current window count to rolling hourly baseline
  - Detects: error storms, retry loops, cascading failures

Also handles the log_processor publishing volume metrics to CloudWatch
which the log_volume_monitor reads.

Triggered: Kinesis (same stream as log_processor, separate Lambda)
"""
import base64
import hashlib
import json
import math
import os
import re
import time
import uuid
from decimal import Decimal

import boto3
from botocore.exceptions import ClientError

PATTERN_TABLE  = os.environ['PATTERN_TABLE']   # DynamoDB: LogPatternCounts
ANOMALY_TABLE  = os.environ['ANOMALY_TABLE']
SIGNAL_BUS     = os.environ['SIGNAL_BUS_NAME']
PROJECT        = os.environ['PROJECT_NAME']

ddb = boto3.resource('dynamodb')
eb  = boto3.client('events')
cw  = boto3.client('cloudwatch')

p_tbl = ddb.Table(PATTERN_TABLE)
a_tbl = ddb.Table(ANOMALY_TABLE)

# Patterns to strip when normalizing log signatures (same as log_processor)
_STRIP = [
    (re.compile(r'\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?'), '<TS>'),
    (re.compile(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}', re.I), '<UUID>'),
    (re.compile(r'\b\d+\.\d+\.\d+\.\d+\b'), '<IP>'),
    (re.compile(r'\b[0-9a-fA-F]{32,}\b'), '<HASH>'),
    (re.compile(r'RequestId:[^\s]+'), 'RequestId:<ID>'),
    (re.compile(r'\b\d+\b'), '<N>'),
    (re.compile(r'\s+'), ' '),
]

# Only track these levels for rate anomalies (not INFO — too noisy)
TRACKED_LEVELS = {'ERROR', 'WARN', 'CRITICAL', 'FATAL'}

# Rate spike threshold: current window count vs baseline
RATE_SPIKE_MULTIPLIER = 5.0   # 5x above baseline mean = anomaly
MIN_BASELINE_SAMPLES  = 12    # Need 1 hour of data before alerting
MIN_SPIKE_COUNT       = 8     # Must see at least 8 occurrences to care
Z_THRESHOLD           = 3.5   # Z-score fallback threshold


def _normalize(message: str) -> str:
    """Normalize a log message to a stable pattern signature."""
    s = message.upper()
    for pattern, repl in _STRIP:
        s = pattern.sub(repl, s)
    return s.strip()[:200]   # Cap at 200 chars


def _hash_pattern(account_id: str, sig: str) -> str:
    return hashlib.sha256(f'{account_id}:{sig}'.encode()).hexdigest()[:16]


def _get_pattern_baseline(account_id: str, pattern_hash: str) -> dict:
    """
    Get rolling 24-hour baseline for this pattern.
    Each sample = count in a 5-min window.
    """
    try:
        resp = p_tbl.get_item(
            Key={'pk': f'{account_id}#{pattern_hash}', 'sk': 'baseline'}
        )
        item = resp.get('Item')
        if not item:
            return {'samples': [], 'signature': ''}

        samples = [float(s) for s in item.get('samples', [])]
        sig     = item.get('signature', '')

        if len(samples) < MIN_BASELINE_SAMPLES:
            return {'samples': samples, 'signature': sig, 'mean': None}

        mean     = sum(samples) / len(samples)
        variance = sum((s - mean) ** 2 for s in samples) / len(samples)
        stddev   = math.sqrt(variance)

        return {
            'samples':   samples,
            'signature': sig,
            'mean':      mean,
            'stddev':    stddev,
        }
    except ClientError:
        return {'samples': [], 'signature': ''}


def _update_pattern_baseline(account_id: str, pattern_hash: str,
                              signature: str, count: int) -> None:
    """Append current window count to rolling baseline. Keep 288 samples (24h)."""
    try:
        resp = p_tbl.get_item(
            Key={'pk': f'{account_id}#{pattern_hash}', 'sk': 'baseline'}
        )
        item    = resp.get('Item', {})
        samples = list(item.get('samples', []))
        samples.append(Decimal(str(count)))
        samples = samples[-288:]  # 24h at 5-min intervals

        p_tbl.put_item(Item={
            'pk':          f'{account_id}#{pattern_hash}',
            'sk':          'baseline',
            'signature':   signature,
            'samples':     samples,
            'lastUpdated': int(time.time()),
            'totalSeen':   int(item.get('totalSeen', 0)) + count,
            'ttl':         int(time.time()) + 25 * 86400,
        })
    except ClientError as e:
        print(f'Pattern baseline update failed: {e}')


def _is_rate_anomaly(count: int, baseline: dict) -> tuple:
    """
    Returns (is_anomaly, severity, description).
    Uses both multiplier and z-score approaches.
    """
    if baseline.get('mean') is None or count < MIN_SPIKE_COUNT:
        return False, 'LOW', ''

    mean   = baseline['mean']
    stddev = baseline.get('stddev', 0)

    if mean < 0.1:
        # Pattern was essentially absent — any count is anomalous
        if count >= MIN_SPIKE_COUNT:
            return True, 'HIGH', f'Dormant pattern reactivated: {count} occurrences (was ~0/window)'
        return False, 'LOW', ''

    ratio   = count / mean
    z_score = (count - mean) / max(stddev, 0.1)

    if ratio >= RATE_SPIKE_MULTIPLIER or z_score >= Z_THRESHOLD:
        severity = 'HIGH' if ratio >= RATE_SPIKE_MULTIPLIER * 2 else 'MEDIUM'
        desc = (f'Pattern rate spike: {count}x in 5min '
                f'(baseline {mean:.1f}±{stddev:.1f}, ratio {ratio:.1f}x, z={z_score:.1f})')
        return True, severity, desc

    return False, 'LOW', ''


def _publish_volume_metric(account_id: str, log_group: str,
                            level: str, count: int) -> None:
    """
    Publish log volume to CloudWatch OpsIQ/LogVolume namespace.
    This is what log_volume_monitor reads for its baseline comparison.
    """
    try:
        cw.put_metric_data(
            Namespace='OpsIQ/LogVolume',
            MetricData=[{
                'MetricName': 'LogEventCount',
                'Dimensions': [
                    {'Name': 'AccountId', 'Value': account_id},
                    {'Name': 'LogGroup',  'Value': log_group},
                    {'Name': 'Level',     'Value': level},
                ],
                'Value': count,
                'Unit':  'Count',
            }]
        )
    except ClientError:
        pass


def _emit_rate_anomaly(account_id: str, log_group: str, signature: str,
                        count: int, baseline: dict, severity: str,
                        description: str) -> None:
    anomaly_id = str(uuid.uuid4())
    ts         = int(time.time() * 1000)

    detail = {
        'accountId':    account_id,
        'anomalyId':    anomaly_id,
        'anomalyType':  'log_pattern_spike',
        'severity':     severity,
        'logGroup':     log_group,
        'signature':    signature[:150],
        'currentCount': count,
        'baselineMean': round(baseline.get('mean') or 0, 2),
        'description':  description,
        'timestamp':    ts,
        'source':       'opsiq.log_pattern_tracker',
    }

    a_tbl.put_item(Item={
        'accountId':   account_id,
        'sortKey':     f'{ts}#{anomaly_id}',
        'anomalyId':   anomaly_id,
        'anomalyType': 'log_pattern_spike',
        'severity':    severity,
        'details':     json.dumps(detail),
        'timestamp':   str(ts),
        'ttl':         int(time.time()) + 30 * 86400,
    })

    eb.put_events(Entries=[{
        'Source':       'opsiq.logs',
        'DetailType':   'LogPatternSpike',
        'EventBusName': SIGNAL_BUS,
        'Detail':       json.dumps(detail),
    }])

    print(f'RATE ANOMALY | account={account_id} | group={log_group} | '
          f'count={count} | sev={severity} | sig={signature[:60]}')


def handler(event, _context):
    """
    Kinesis consumer — processes same log stream as log_processor
    but tracks pattern frequencies rather than novelty.
    """
    records = event.get('Records', [])

    # Accumulate counts per account/log_group/level/pattern in this batch
    # Structure: {account_id: {log_group: {level: {pattern_hash: (count, sig)}}}}
    batch_counts: dict = {}
    level_totals: dict = {}  # For volume metric publishing

    for record in records:
        raw = base64.b64decode(record['kinesis']['data']).decode('utf-8')
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            continue

        account_id = payload.get('accountId', 'unknown')
        log_group  = payload.get('logGroup', 'unknown')
        log_events = payload.get('logEvents', [])

        for evt in log_events:
            level   = evt.get('level', 'INFO').upper()
            message = evt.get('message', '')

            if not message:
                continue

            # Track volume totals for CloudWatch metric
            key = f'{account_id}|{log_group}|{level}'
            level_totals[key] = level_totals.get(key, 0) + 1

            # Only track ERROR/WARN for pattern rate analysis
            if level not in TRACKED_LEVELS:
                continue

            sig  = _normalize(message)
            phash = _hash_pattern(account_id, sig)

            if account_id not in batch_counts:
                batch_counts[account_id] = {}
            if log_group not in batch_counts[account_id]:
                batch_counts[account_id][log_group] = {}
            if level not in batch_counts[account_id][log_group]:
                batch_counts[account_id][log_group][level] = {}

            existing_count, _ = batch_counts[account_id][log_group][level].get(phash, (0, ''))
            batch_counts[account_id][log_group][level][phash] = (existing_count + 1, sig)

    # Publish volume metrics to CloudWatch
    metric_data = []
    for key, count in level_totals.items():
        account_id, log_group, level = key.split('|')
        metric_data.append({
            'MetricName': 'LogEventCount',
            'Dimensions': [
                {'Name': 'AccountId', 'Value': account_id},
                {'Name': 'LogGroup',  'Value': log_group},
                {'Name': 'Level',     'Value': level},
            ],
            'Value': float(count),
            'Unit':  'Count',
        })
    if metric_data:
        for i in range(0, len(metric_data), 20):
            try:
                cw.put_metric_data(
                    Namespace='OpsIQ/LogVolume',
                    MetricData=metric_data[i:i+20]
                )
            except ClientError:
                pass

    # Check rate anomalies for each tracked pattern
    anomaly_count = 0
    for account_id, groups in batch_counts.items():
        for log_group, levels in groups.items():
            for level, patterns in levels.items():
                for phash, (count, sig) in patterns.items():
                    baseline = _get_pattern_baseline(account_id, phash)
                    is_anom, severity, desc = _is_rate_anomaly(count, baseline)

                    if is_anom:
                        _emit_rate_anomaly(account_id, log_group, sig,
                                          count, baseline, severity, desc)
                        anomaly_count += 1

                    # Always update baseline
                    _update_pattern_baseline(account_id, phash, sig, count)

    print(f'log_pattern_tracker | records={len(records)} | anomalies={anomaly_count}')
    return {'batchItemFailures': []}
