"""
OpsIQ Central — incident_summariser.py

SCHEDULED (every 30 min via EventBridge) — NOT in the signal hot path.

Finds HIGH incidents without AI summaries, picks top candidates,
calls Bedrock ONCE per incident with a compressed prompt.

Production cost controls:
  - Max 3 Bedrock calls per run (configurable)
  - Daily token budget per account (tracked in DynamoDB)
  - Compressed prompts — top 5 signals only, not full payload
  - Uses cheapest model that produces good summaries
  - Skips accounts that exhausted their daily budget
"""
import json
import os
import time

import boto3
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError

INCIDENT_TABLE   = os.environ['INCIDENT_TABLE']
HEALTH_TABLE     = os.environ['HEALTH_TABLE']
BEDROCK_MODEL_ID = os.environ.get('BEDROCK_MODEL_ID', 'us.anthropic.claude-haiku-4-5')
PROJECT          = os.environ.get('PROJECT_NAME', 'opsiq')
REGION           = os.environ.get('REGION', 'us-west-2')

# ── Cost controls ─────────────────────────────────────────────────────────────
MAX_CALLS_PER_RUN      = int(os.environ.get('MAX_BEDROCK_CALLS_PER_RUN', '3'))
DAILY_TOKEN_BUDGET     = int(os.environ.get('DAILY_TOKEN_BUDGET', '100000'))  # per account
LOOKBACK_HOURS         = int(os.environ.get('LOOKBACK_HOURS', '6'))           # only summarise recent incidents
MAX_SIGNALS_IN_PROMPT  = 5   # compress — never send more than 5 signals to Bedrock
MAX_PROMPT_TOKENS_EST  = 800  # estimated — keep prompts small

ddb     = boto3.resource('dynamodb', region_name=REGION)
bedrock = boto3.client('bedrock-runtime', region_name=REGION)
i_tbl   = ddb.Table(INCIDENT_TABLE)
h_tbl   = ddb.Table(HEALTH_TABLE)


def _get_daily_token_key(account_id: str) -> str:
    """DynamoDB key for today's token usage tracking."""
    today = time.strftime('%Y-%m-%d', time.gmtime())
    return f'token_budget#{account_id}#{today}'


def _get_token_usage(account_id: str) -> int:
    """Get tokens used today for this account."""
    try:
        resp = h_tbl.get_item(Key={'accountId': _get_daily_token_key(account_id)})
        return int(resp.get('Item', {}).get('tokensUsed', 0))
    except Exception:
        return 0


def _record_token_usage(account_id: str, tokens_used: int) -> None:
    """Record tokens consumed today."""
    key = _get_daily_token_key(account_id)
    today_end = int(time.mktime(time.strptime(
        time.strftime('%Y-%m-%d', time.gmtime()) + ' 23:59:59', '%Y-%m-%d %H:%M:%S'
    )))
    try:
        h_tbl.update_item(
            Key={'accountId': key},
            UpdateExpression='ADD tokensUsed :t SET #ttl = :e',
            ExpressionAttributeNames={'#ttl': 'ttl'},
            ExpressionAttributeValues={':t': tokens_used, ':e': today_end},
        )
    except Exception as e:
        print(f'Token usage recording failed: {e}')


def _find_unsummarised_incidents() -> list:
    """
    Scan for HIGH incidents without AI summaries created in the last LOOKBACK_HOURS.
    Returns sorted by signal count descending (most impactful first).
    """
    cutoff = str(int((time.time() - LOOKBACK_HOURS * 3600) * 1000))
    candidates = []

    try:
        # Scan is acceptable here since this runs every 30 min, not in hot path
        resp = i_tbl.scan(
            FilterExpression=(
                Attr('severity').eq('HIGH') &
                Attr('aiSummary').not_exists() &
                Attr('timestamp').gte(cutoff) &
                Attr('status').eq('OPEN')
            )
        )
        candidates = resp.get('Items', [])

        # Handle pagination
        while 'LastEvaluatedKey' in resp:
            resp = i_tbl.scan(
                FilterExpression=(
                    Attr('severity').eq('HIGH') &
                    Attr('aiSummary').not_exists() &
                    Attr('timestamp').gte(cutoff) &
                    Attr('status').eq('OPEN')
                ),
                ExclusiveStartKey=resp['LastEvaluatedKey']
            )
            candidates.extend(resp.get('Items', []))

    except Exception as e:
        print(f'Scan failed: {e}')
        return []

    # Sort by signal count — summarise highest-impact incidents first
    candidates.sort(key=lambda x: int(x.get('signalCount', 0)), reverse=True)
    print(f'Found {len(candidates)} unsummarised HIGH incidents')
    return candidates


def _build_compressed_prompt(incident: dict) -> str:
    """
    Build a tight, cost-efficient prompt.
    Never sends more than MAX_SIGNALS_IN_PROMPT signals.
    Target: < 800 tokens input.
    """
    account_id    = incident.get('accountId', 'unknown')
    incident_type = incident.get('incidentType', 'unknown')
    signal_count  = incident.get('signalCount', 0)
    blast         = incident.get('blastRadius', {})

    # Take only top 5 signals — compress the rest to a count
    signals = incident.get('signals', [])[:MAX_SIGNALS_IN_PROMPT]
    signal_summary = []
    for s in signals:
        sig_type = s.get('anomalyType', s.get('type', 'unknown'))
        desc     = s.get('description', s.get('message', s.get('signature', '')))[:120]
        sev      = s.get('severity', 'UNKNOWN')
        signal_summary.append(f'  [{sev}] {sig_type}: {desc}')

    directly_affected = blast.get('directlyAffected', [])[:3]
    blast_str = ', '.join(directly_affected) if directly_affected else 'unknown'

    prompt = f"""AWS incident detected. Provide a concise operational analysis.

Account: {account_id}
Type: {incident_type}
Total signals: {signal_count} (showing top {len(signal_summary)})
Blast radius: {blast_str}

Top signals:
{chr(10).join(signal_summary)}

Respond with ONLY this JSON (no markdown, no explanation):
{{
  "headline": "one sentence describing the incident",
  "probableCauses": ["primary cause in one sentence"],
  "investigationSteps": ["step 1", "step 2", "step 3"],
  "confidence": "HIGH|MEDIUM|LOW",
  "estimatedResolutionTime": "X-Y minutes",
  "runbookReference": {{"section": "relevant-runbook-section"}}
}}"""

    return prompt


def _call_bedrock(prompt: str) -> tuple[dict, int]:
    """
    Call Bedrock with the compressed prompt.
    Returns (summary_dict, tokens_used).
    """
    body = json.dumps({
        'anthropic_version': 'bedrock-2023-05-31',
        'max_tokens': 400,   # Keep output small too
        'messages': [{'role': 'user', 'content': prompt}],
    })

    resp   = bedrock.invoke_model(
        modelId=BEDROCK_MODEL_ID,
        contentType='application/json',
        accept='application/json',
        body=body,
    )
    result = json.loads(resp['body'].read())

    # Extract token usage from response
    usage       = result.get('usage', {})
    input_tok   = usage.get('input_tokens', MAX_PROMPT_TOKENS_EST)
    output_tok  = usage.get('output_tokens', 200)
    total_tok   = input_tok + output_tok

    raw = result['content'][0]['text'].strip()
    if raw.startswith('```'):
        raw = raw.split('\n', 1)[1].rsplit('```', 1)[0].strip()

    summary = json.loads(raw)
    return summary, total_tok


def _write_summary(incident: dict, summary: dict) -> None:
    """Write the AI summary back to the incident record."""
    try:
        i_tbl.update_item(
            Key={
                'incidentId': incident['incidentId'],
                'timestamp':  incident['timestamp'],
            },
            UpdateExpression='SET aiSummary = :s, summarisedAt = :t',
            ExpressionAttributeValues={
                ':s': summary,
                ':t': int(time.time() * 1000),
            },
        )
    except Exception as e:
        print(f'Failed to write summary: {e}')


def handler(event=None, context=None):
    print(f'Incident summariser starting — max {MAX_CALLS_PER_RUN} Bedrock calls this run')

    candidates   = _find_unsummarised_incidents()
    calls_made   = 0
    calls_skipped = 0
    total_tokens = 0

    for incident in candidates:
        if calls_made >= MAX_CALLS_PER_RUN:
            print(f'Max calls per run ({MAX_CALLS_PER_RUN}) reached — stopping')
            break

        account_id = incident.get('accountId', 'unknown')

        # Check daily token budget
        used_today = _get_token_usage(account_id)
        if used_today >= DAILY_TOKEN_BUDGET:
            print(f'Daily token budget exhausted for {account_id} ({used_today}/{DAILY_TOKEN_BUDGET}) — skipping')
            calls_skipped += 1
            continue

        # Build compressed prompt and call Bedrock
        try:
            prompt  = _build_compressed_prompt(incident)
            summary, tokens = _call_bedrock(prompt)

            _write_summary(incident, summary)
            _record_token_usage(account_id, tokens)

            total_tokens += tokens
            calls_made   += 1

            print(f'Summarised | account={account_id} | incident={incident["incidentId"]} | tokens={tokens}')

        except json.JSONDecodeError as e:
            print(f'JSON parse failed for {incident["incidentId"]}: {e}')
        except ClientError as e:
            print(f'Bedrock error for {incident["incidentId"]}: {e}')
        except Exception as e:
            print(f'Unexpected error for {incident["incidentId"]}: {e}')

    print(f'Run complete | calls={calls_made} | skipped={calls_skipped} | total_tokens={total_tokens}')
    return {
        'statusCode':    200,
        'callsMade':     calls_made,
        'callsSkipped':  calls_skipped,
        'totalTokens':   total_tokens,
        'candidatesFound': len(candidates),
    }


if __name__ == '__main__':
    handler()
