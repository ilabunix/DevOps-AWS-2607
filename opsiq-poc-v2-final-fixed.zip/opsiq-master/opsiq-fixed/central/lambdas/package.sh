#!/usr/bin/env bash
# opsiq-poc/central/lambdas/package.sh
# Packages all central Lambda functions into ZIPs and uploads to S3.
# Works on Git Bash (Windows), macOS, and Linux.
#
# Usage: ./package.sh <lambda-code-bucket>
# Example: ./package.sh opsiq-lambda-pkgs-615299738349

set -euo pipefail

BUCKET="${1:?Usage: ./package.sh <lambda-code-bucket>}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REGION="${REGION:-us-west-2}"
BUILD_DIR="$SCRIPT_DIR/_build"

mkdir -p "$BUILD_DIR"

echo "╔══════════════════════════════════════════════════╗"
echo "║  OpsIQ — Packaging Central Lambda Functions     ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║  Source : $SCRIPT_DIR"
echo "║  Bucket : s3://$BUCKET/central/"
echo "╚══════════════════════════════════════════════════╝"
echo ""

# All central Lambda functions
FUNCTIONS=(
  "log_processor"
  "log_volume_monitor"
  "log_pattern_tracker"
  "state_parser"
  "correlator"
  "drift_detector"
  "health_scorer"
  "incident_assembler"
  "incident_summariser"
  "api_handler"
  "chat_handler"
  "ws_handler"
  "ws_broadcaster"
)

# Use Python to create ZIPs — writes a pack.py script to avoid
# heredoc/quoting issues on MINGW64 (Windows Git Bash)
for FN in "${FUNCTIONS[@]}"; do
  echo "  Packaging: $FN"

  PYSCRIPT="$BUILD_DIR/pack.py"
  cat > "$PYSCRIPT" << PYEOF
import zipfile, sys
src  = sys.argv[1]
dst  = sys.argv[2]
name = sys.argv[3]
with zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED) as z:
    z.write(src, name)
PYEOF

  python "$PYSCRIPT" \
    "$SCRIPT_DIR/${FN}.py" \
    "$BUILD_DIR/${FN}.zip" \
    "${FN}.py"

  aws s3 cp "$BUILD_DIR/${FN}.zip" "s3://$BUCKET/central/${FN}.zip" --quiet
  echo "  Uploaded: s3://$BUCKET/central/${FN}.zip"
done

rm -rf "$BUILD_DIR"

echo ""
echo "==> Central Lambda packaging complete (${#FUNCTIONS[@]} functions)"
