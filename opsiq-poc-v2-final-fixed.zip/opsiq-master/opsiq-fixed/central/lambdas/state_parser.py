"""
OpsIQ Central — state_parser.py
SQS consumer (batch=1). Receives Terraform state payload, extracts resources,
builds topology graph, writes to DynamoDB TopologyCache and S3.
"""
import json
import os
import time

import boto3

TOPOLOGY_TABLE  = os.environ['TOPOLOGY_TABLE']
TOPOLOGY_BUCKET = os.environ['TOPOLOGY_BUCKET']
PROJECT         = os.environ['PROJECT_NAME']

ddb = boto3.resource('dynamodb')
s3  = boto3.client('s3')
table = ddb.Table(TOPOLOGY_TABLE)

# Maps Terraform resource types to display tiers in the topology graph
TIER_MAP = {
    'aws_cloudfront_distribution':  'edge',
    'aws_api_gateway_rest_api':     'ingress',
    'aws_apigatewayv2_api':         'ingress',
    'aws_lb':                       'ingress',
    'aws_alb':                      'ingress',
    'aws_ecs_cluster':              'compute',
    'aws_ecs_service':              'compute',
    'aws_lambda_function':          'compute',
    'aws_instance':                 'compute',
    'aws_rds_instance':             'data',
    'aws_rds_cluster':              'data',
    'aws_dynamodb_table':           'data',
    'aws_elasticache_cluster':      'data',
    'aws_elasticache_replication_group': 'data',
    's3_bucket':                    'storage',
    'aws_s3_bucket':                'storage',
}

SAFE_ATTRS = {
    'aws_alb':                  ['arn', 'dns_name', 'name', 'vpc_id'],
    'aws_lb':                   ['arn', 'dns_name', 'name', 'vpc_id'],
    'aws_ecs_service':          ['id', 'name', 'cluster', 'desired_count', 'launch_type'],
    'aws_ecs_cluster':          ['id', 'name', 'arn'],
    'aws_rds_instance':         ['arn', 'id', 'engine', 'engine_version', 'instance_class'],
    'aws_rds_cluster':          ['arn', 'id', 'engine', 'engine_version'],
    'aws_lambda_function':      ['arn', 'function_name', 'runtime', 'memory_size', 'timeout'],
    'aws_dynamodb_table':       ['arn', 'id', 'name', 'billing_mode'],
    'aws_s3_bucket':            ['id', 'bucket'],
    'aws_elasticache_cluster':  ['id', 'engine', 'node_type', 'num_cache_nodes'],
    'aws_apigatewayv2_api':     ['id', 'name', 'protocol_type'],
    'aws_api_gateway_rest_api': ['id', 'name'],
}


def _extract_resources(state: dict) -> list:
    resources = []
    for res in state.get('resources', []):
        if res.get('mode') != 'managed':
            continue
        r_type = res.get('type', '')
        r_name = res.get('name', '')
        for inst in res.get('instances', []):
            attrs    = inst.get('attributes', {})
            allowed  = SAFE_ATTRS.get(r_type, ['id', 'arn', 'name'])
            arn      = attrs.get('arn', attrs.get('id', f'{r_type}.{r_name}'))
            resources.append({
                'type':         r_type,
                'name':         r_name,
                'arn':          arn,
                'tier':         TIER_MAP.get(r_type, 'other'),
                'tags':         attrs.get('tags', {}),
                'dependencies': inst.get('dependencies', []),
                'safeAttrs':    {k: v for k, v in attrs.items() if k in allowed},
            })
    return resources


def _build_graph(account_id: str, resources: list) -> dict:
    """Build a nodes-and-edges topology graph for D3 visualisation."""
    nodes = []
    edges = []
    arn_to_idx = {}

    for i, r in enumerate(resources):
        arn_to_idx[r['arn']] = i
        nodes.append({
            'id':    r['arn'],
            'label': r.get('safeAttrs', {}).get('name', r['name']),
            'type':  r['type'],
            'tier':  r['tier'],
            'tags':  r['tags'],
        })

    for r in resources:
        src_idx = arn_to_idx.get(r['arn'])
        for dep in r.get('dependencies', []):
            # deps look like "aws_alb.main" — try to resolve to ARN
            for cand_arn, idx in arn_to_idx.items():
                if dep in cand_arn or cand_arn.endswith(dep.split('.')[-1]):
                    if src_idx != idx:
                        edges.append({'source': r['arn'], 'target': cand_arn})
                    break

    return {
        'accountId': account_id,
        'updatedAt': int(time.time()),
        'nodeCount': len(nodes),
        'edgeCount': len(edges),
        'nodes':     nodes,
        'edges':     edges,
    }


def _write_to_dynamo(account_id: str, resources: list) -> None:
    ttl = int(time.time()) + 13 * 3600  # 13-hour TTL
    with table.batch_writer() as batch:
        for r in resources:
            batch.put_item(Item={
                'accountId':   account_id,
                'resourceArn': r['arn'],
                'resourceType': r['type'],
                'resourceName': r['name'],
                'tier':        r['tier'],
                'tags':        r['tags'],
                'safeAttrs':   r['safeAttrs'],
                'ttl':         ttl,
            })


def _write_graph_to_s3(account_id: str, graph: dict) -> None:
    s3.put_object(
        Bucket=TOPOLOGY_BUCKET,
        Key=f'{account_id}/current.json',
        Body=json.dumps(graph),
        ContentType='application/json',
    )


def handler(event, _context):
    for record in event.get('Records', []):
        try:
            payload    = json.loads(record['body'])
            account_id = payload.get('accountId', 'unknown')

            # Accept either a raw state blob or a pre-extracted resources list
            if 'resources' in payload and isinstance(payload['resources'], list):
                if payload['resources'] and 'type' in payload['resources'][0]:
                    # Already pre-extracted by simulation seeder
                    resources = payload['resources']
                else:
                    # Raw Terraform state
                    resources = _extract_resources(payload)
            else:
                resources = _extract_resources(payload)

            graph = _build_graph(account_id, resources)
            _write_to_dynamo(account_id, resources)
            _write_graph_to_s3(account_id, graph)

            print(f'Topology built | account={account_id} | nodes={graph["nodeCount"]} | edges={graph["edgeCount"]}')
        except Exception as e:
            print(f'Error processing state record: {e}')
            raise  # Re-raise so SQS retries this message

    return {'statusCode': 200}
