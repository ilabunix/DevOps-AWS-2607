"""
OpsIQ Central — chat_handler.py

AI SRE Engineer chat interface. Every answer is grounded in real OpsIQ
data — incidents, anomalies, health scores, topology, runbooks.
Never answers from general knowledge alone.

Route: POST /chat
Body: { "message": "what's wrong with sim-app-a?", "accountId": "sim-app-a" (optional) }
Response: { "answer": "...", "sources": [...], "confidence": "HIGH|MEDIUM|LOW" }
"""
import json
import os
import re
import time

import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

INCIDENT_TABLE   = os.environ['INCIDENT_TABLE']
ANOMALY_TABLE    = os.environ['ANOMALY_TABLE']
HEALTH_TABLE     = os.environ['HEALTH_TABLE']
TOPOLOGY_BUCKET  = os.environ['TOPOLOGY_BUCKET']
RUNBOOKS_BUCKET  = os.environ['RUNBOOKS_BUCKET']
RUNBOOK_INDEX_TABLE = os.environ['RUNBOOK_INDEX_TABLE']
BEDROCK_MODEL_ID = os.environ['BEDROCK_MODEL_ID']
REGION           = os.environ['REGION']
PROJECT          = os.environ['PROJECT_NAME']

ddb     = boto3.resource('dynamodb')
s3      = boto3.client('s3')
bedrock = boto3.client('bedrock-runtime', region_name=REGION)

i_tbl  = ddb.Table(INCIDENT_TABLE)
a_tbl  = ddb.Table(ANOMALY_TABLE)
h_tbl  = ddb.Table(HEALTH_TABLE)
rb_tbl = ddb.Table(RUNBOOK_INDEX_TABLE)

CORS_HEADERS = {
    'Access-Control-Allow-Origin':  '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST,OPTIONS',
    'Content-Type': 'application/json',
}

# ── CONTEXT BUILDERS ─────────────────────────────────────────────────────────

def _get_all_health_scores() -> list:
    resp = h_tbl.scan()
    return resp.get('Items', [])


def _get_open_incidents(account_id: str = None) -> list:
    if account_id:
        resp = i_tbl.query(
            IndexName='accountId-timestamp-index',
            KeyConditionExpression=Key('accountId').eq(account_id),
            FilterExpression='#s = :open',
            ExpressionAttributeNames={'#s': 'status'},
            ExpressionAttributeValues={':open': 'OPEN'},
            ScanIndexForward=False,
            Limit=10,
        )
    else:
        resp = i_tbl.scan(
            FilterExpression='#s = :open',
            ExpressionAttributeNames={'#s': 'status'},
            ExpressionAttributeValues={':open': 'OPEN'},
            Limit=20,
        )
    return resp.get('Items', [])


def _get_recent_anomalies(account_id: str, window_minutes: int = 30) -> list:
    cutoff = str(int((time.time() - window_minutes * 60) * 1000))
    resp   = a_tbl.query(
        KeyConditionExpression=Key('accountId').eq(account_id) & Key('sortKey').gte(cutoff),
        ScanIndexForward=False,
        Limit=20,
    )
    return resp.get('Items', [])


def _get_topology(account_id: str) -> dict:
    try:
        obj = s3.get_object(Bucket=TOPOLOGY_BUCKET, Key=f'{account_id}/current.json')
        return json.loads(obj['Body'].read())
    except ClientError:
        return {}


def _get_runbook(incident_type: str) -> str:
    try:
        resp = rb_tbl.get_item(Key={'anomalyType': incident_type})
        item = resp.get('Item') or rb_tbl.get_item(Key={'anomalyType': 'default'}).get('Item', {})
        s3_key = item.get('s3Key', '')
        if s3_key:
            obj = s3.get_object(Bucket=RUNBOOKS_BUCKET, Key=s3_key)
            return obj['Body'].read().decode('utf-8')[:2000]
    except ClientError:
        pass
    return ''


def _incident_summary(inc: dict) -> str:
    ai = inc.get('aiSummary') or {}
    ts = inc.get('timestamp', '')
    age_min = int((time.time() * 1000 - int(ts)) / 60000) if ts else 0
    headline = ai.get('headline') or inc.get('incidentType', 'unknown').replace('_', ' ')
    return (
        f"- [{inc.get('severity')}] {headline} "
        f"(account: {inc.get('accountId')}, signals: {inc.get('signalCount', 0)}, "
        f"age: {age_min}min, status: {inc.get('status')})"
    )


def _anomaly_summary(a: dict) -> str:
    details = json.loads(a.get('details', '{}')) if isinstance(a.get('details'), str) else {}
    desc    = details.get('description') or a.get('anomalyType', '').replace('_', ' ')
    ts      = a.get('timestamp', '')
    age_min = int((time.time() * 1000 - int(ts)) / 60000) if ts else 0
    return f"- [{a.get('severity')}] {desc} ({age_min}min ago)"


# ── INTENT DETECTION ─────────────────────────────────────────────────────────

def _extract_account_id(message: str, known_accounts: list) -> str | None:
    """Try to find an account ID mentioned in the message."""
    msg_lower = message.lower()
    for acc_id in known_accounts:
        if acc_id.lower() in msg_lower:
            return acc_id
    return None


def _classify_intent(message: str) -> str:
    """Rough intent classification to optimise context loading."""
    msg = message.lower()
    if any(w in msg for w in ['worst', 'critical', 'unhealthy', 'all accounts', 'fleet', 'overview']):
        return 'fleet_overview'
    if any(w in msg for w in ['incident', 'what happened', 'what broke', 'outage', 'down']):
        return 'incident_focus'
    if any(w in msg for w in ['anomal', 'error', 'warn', 'log', 'pattern', 'spike']):
        return 'anomaly_focus'
    if any(w in msg for w in ['topology', 'architecture', 'infrastructure', 'what is running', 'what services']):
        return 'topology_focus'
    if any(w in msg for w in ['runbook', 'how to fix', 'remediat', 'resolve', 'what should i do', 'next step']):
        return 'runbook_focus'
    if any(w in msg for w in ['drift', 'terraform', 'unmanaged', 'missing resource']):
        return 'drift_focus'
    if any(w in msg for w in ['score', 'health', 'status', 'healthy', 'how is']):
        return 'health_focus'
    return 'general'


# ── CONTEXT ASSEMBLY ─────────────────────────────────────────────────────────

def _build_context(message: str, explicit_account_id: str = None) -> tuple:
    """
    Assemble the minimal context needed to answer this question.
    Returns (context_text, sources_used, account_id_detected).
    """
    health_scores   = _get_all_health_scores()
    known_accounts  = [h['accountId'] for h in health_scores]
    intent          = _classify_intent(message)
    sources         = []

    # Determine which account to focus on
    account_id = explicit_account_id or _extract_account_id(message, known_accounts)

    sections = []

    # Always include fleet health overview
    if health_scores:
        health_lines = []
        for h in sorted(health_scores, key=lambda x: int(x.get('score', 0))):
            score  = int(h.get('score', 0))
            status = 'CRITICAL' if score < 60 else 'WARNING' if score < 80 else 'HEALTHY'
            health_lines.append(f"  {h['accountId']}: score={score}/100 status={status}")
        sections.append('## Account Health Scores\n' + '\n'.join(health_lines))
        sources.append('health_scores')

    # Incidents — focused on account if specified, else all open
    open_incidents = _get_open_incidents(account_id)
    if not open_incidents and not account_id:
        open_incidents = _get_open_incidents()

    if open_incidents:
        inc_lines = [_incident_summary(i) for i in open_incidents[:8]]
        label     = f'## Open Incidents — {account_id}' if account_id else '## All Open Incidents'
        sections.append(label + '\n' + '\n'.join(inc_lines))
        sources.append('incidents')

        # Include AI summaries for HIGH incidents
        for inc in open_incidents:
            if inc.get('severity') == 'HIGH' and inc.get('aiSummary'):
                ai = inc['aiSummary']
                sections.append(
                    f"## AI Analysis — {inc.get('accountId')}\n"
                    f"Headline: {ai.get('headline', '')}\n"
                    f"Probable cause: {(ai.get('probableCauses') or ['unknown'])[0]}\n"
                    f"Top action: {(ai.get('investigationSteps') or ['—'])[0]}\n"
                    f"Confidence: {ai.get('confidence', 'MEDIUM')}"
                )
                sources.append('ai_summary')
                break

    # Anomalies — only if account is known
    if account_id and intent in ('anomaly_focus', 'incident_focus', 'general'):
        anomalies = _get_recent_anomalies(account_id)
        if anomalies:
            anom_lines = [_anomaly_summary(a) for a in anomalies[:8]]
            sections.append(f'## Recent Anomalies — {account_id}\n' + '\n'.join(anom_lines))
            sources.append('anomalies')

    # Topology — only if asked about architecture
    if account_id and intent in ('topology_focus', 'general', 'incident_focus'):
        topo = _get_topology(account_id)
        if topo.get('nodes'):
            node_lines = []
            for n in topo['nodes'][:12]:
                node_lines.append(f"  {n.get('label', n.get('id', ''))} ({n.get('type', '')} — {n.get('tier', '')} tier)")
            sections.append(
                f"## Infrastructure Topology — {account_id}\n"
                f"Resources ({topo.get('nodeCount', 0)} total, {topo.get('edgeCount', 0)} edges):\n"
                + '\n'.join(node_lines)
            )
            sources.append('topology')

    # Runbook — if asking about remediation
    if intent == 'runbook_focus' and open_incidents:
        inc_type = open_incidents[0].get('incidentType', 'default')
        runbook  = _get_runbook(inc_type)
        if runbook:
            sections.append(f'## Relevant Runbook\n{runbook[:1500]}')
            sources.append('runbook')

    context = '\n\n'.join(sections)
    return context, sources, account_id


# ── PROMPT BUILDER ───────────────────────────────────────────────────────────

def _build_prompt(message: str, context: str, account_id: str = None) -> str:
    account_clause = f" You are currently focused on account '{account_id}'." if account_id else ''

    return f"""You are OpsIQ — an AI SRE Engineer assistant embedded in an AWS operational intelligence platform.{account_clause}

You have access to real-time data from the monitored AWS accounts shown below. Your answers must be grounded in this data. Do not answer from general AWS knowledge unless the data is insufficient, and if so, say so clearly.

Be concise and actionable. Format your response as:
- A direct answer to the question (2-4 sentences)
- If relevant: specific actions the engineer should take (numbered list, max 4 items)
- If relevant: what to watch for next

Do not repeat the question. Do not use generic filler phrases like "Great question" or "As an AI". Be direct, like a senior SRE.

---
{context}
---

Engineer's question: {message}

Answer:"""


# ── BEDROCK INVOCATION ───────────────────────────────────────────────────────

def _ask_bedrock(prompt: str) -> str:
    body = json.dumps({
        'anthropic_version': 'bedrock-2023-05-31',
        'max_tokens': 600,
        'messages': [{'role': 'user', 'content': prompt}],
        'temperature': 0.1,   # Low temperature — factual, not creative
    })
    resp   = bedrock.invoke_model(
        modelId=BEDROCK_MODEL_ID,
        contentType='application/json',
        accept='application/json',
        body=body,
    )
    result = json.loads(resp['body'].read())
    return result['content'][0]['text'].strip()


# ── HANDLER ──────────────────────────────────────────────────────────────────

def handler(event, _context):
    method = event.get('httpMethod', 'POST')

    if method == 'OPTIONS':
        return {'statusCode': 200, 'headers': CORS_HEADERS, 'body': ''}

    if method != 'POST':
        return {
            'statusCode': 405,
            'headers': CORS_HEADERS,
            'body': json.dumps({'error': 'Method not allowed'}),
        }

    try:
        body       = json.loads(event.get('body') or '{}')
        message    = (body.get('message') or '').strip()
        account_id = body.get('accountId')

        if not message:
            return {
                'statusCode': 400,
                'headers': CORS_HEADERS,
                'body': json.dumps({'error': 'message is required'}),
            }

        if len(message) > 500:
            message = message[:500]

        # Build context from real OpsIQ data
        context, sources, detected_account = _build_context(message, account_id)

        if not context:
            return {
                'statusCode': 200,
                'headers': CORS_HEADERS,
                'body': json.dumps({
                    'answer': 'No data available yet. Wait for the simulation generators to produce signals, then try again.',
                    'sources': [],
                    'confidence': 'LOW',
                }),
            }

        # Build grounded prompt and ask Bedrock
        prompt = _build_prompt(message, context, detected_account or account_id)
        answer = _ask_bedrock(prompt)

        return {
            'statusCode': 200,
            'headers': CORS_HEADERS,
            'body': json.dumps({
                'answer':           answer,
                'sources':          list(set(sources)),
                'detectedAccount':  detected_account,
                'confidence':       'HIGH' if sources else 'LOW',
            }, default=str),
        }

    except Exception as e:
        print(f'chat_handler error: {e}')
        return {
            'statusCode': 500,
            'headers': CORS_HEADERS,
            'body': json.dumps({'error': 'AI SRE is temporarily unavailable. Try again in a moment.'}),
        }
