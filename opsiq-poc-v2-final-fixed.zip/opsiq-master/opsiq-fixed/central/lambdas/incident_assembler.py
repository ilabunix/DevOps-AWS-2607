"""
OpsIQ Central — incident_assembler.py
Invoked async by correlator. Loads topology + runbook from S3, builds structured
Bedrock prompt, generates AI incident summary, writes back to IncidentRegistry,
broadcasts completed incident card to dashboard.
"""
import json
import os
import time

import boto3
from botocore.exceptions import ClientError
from boto3.dynamodb.conditions import Key, Attr

INCIDENT_TABLE   = os.environ['INCIDENT_TABLE']
TOPOLOGY_BUCKET  = os.environ['TOPOLOGY_BUCKET']
RUNBOOKS_BUCKET  = os.environ['RUNBOOKS_BUCKET']
RUNBOOK_INDEX_TABLE = os.environ['RUNBOOK_INDEX_TABLE']
BROADCASTER_NAME = os.environ['WS_BROADCASTER_NAME']
BEDROCK_MODEL_ID = os.environ['BEDROCK_MODEL_ID']
REGION           = os.environ['REGION']
PROJECT          = os.environ['PROJECT_NAME']

ddb     = boto3.resource('dynamodb')
s3      = boto3.client('s3')
bedrock = boto3.client('bedrock-runtime', region_name=REGION)
lmb     = boto3.client('lambda')

i_tbl   = ddb.Table(INCIDENT_TABLE)
rb_tbl  = ddb.Table(RUNBOOK_INDEX_TABLE)


def _get_topology(account_id: str) -> dict:
    try:
        obj = s3.get_object(Bucket=TOPOLOGY_BUCKET, Key=f'{account_id}/current.json')
        return json.loads(obj['Body'].read())
    except ClientError:
        return {'nodes': [], 'edges': []}


def _get_runbook(incident_type: str) -> str:
    # Look up runbook S3 key from index
    try:
        resp = rb_tbl.get_item(Key={'anomalyType': incident_type})
        item = resp.get('Item') or rb_tbl.get_item(Key={'anomalyType': 'default'}).get('Item', {})
        s3_key = item.get('s3Key', 'runbooks/ecs/high-memory.md')
        obj = s3.get_object(Bucket=RUNBOOKS_BUCKET, Key=s3_key)
        return obj['Body'].read().decode('utf-8')
    except ClientError:
        return '# Runbook not found\nInvestigate the affected resources manually.'


def _build_prompt(incident: dict, topology: dict, runbook: str) -> str:
    signals_summary = json.dumps(incident.get('signals', []), indent=2)
    blast_summary   = json.dumps(incident.get('blastRadius', {}), indent=2)

    # Trim topology nodes to relevant tier for prompt efficiency
    relevant_nodes = [n for n in topology.get('nodes', [])
                      if n.get('tier') in ('compute', 'ingress', 'data')][:20]
    topology_summary = json.dumps(relevant_nodes, indent=2)

    return f"""You are an expert AWS Site Reliability Engineer analyzing a production incident.

## Incident Context
- Account ID: {incident['accountId']}
- Incident ID: {incident['incidentId']}
- Severity: {incident['severity']}
- Incident Type: {incident.get('incidentType', 'unknown')}
- Signal Count: {incident['signalCount']}
- Detected At: {incident['timestamp']}

## Correlated Signals
{signals_summary}

## Blast Radius
{blast_summary}

## Relevant Infrastructure Topology
{topology_summary}

## Applicable Runbook
{runbook}

---

Analyze this incident and respond ONLY with a valid JSON object in exactly this structure:

{{
  "headline": "One-sentence summary of what is happening and which system is affected",
  "whatChanged": [
    "Specific observable change 1",
    "Specific observable change 2"
  ],
  "whatIsImpacted": {{
    "users": "Description of user-facing impact",
    "services": ["service1", "service2"],
    "data": "Data layer impact if any"
  }},
  "probableCauses": [
    "Most likely root cause with evidence from signals",
    "Secondary possible cause"
  ],
  "investigationSteps": [
    "Step 1: Exact CLI command or console action",
    "Step 2: What to look for",
    "Step 3: Next diagnostic action"
  ],
  "runbookReference": {{
    "section": "Most relevant runbook section title",
    "keyAction": "The single most important action from the runbook to take right now"
  }},
  "estimatedResolutionTime": "e.g. 15-30 minutes",
  "confidence": "HIGH|MEDIUM|LOW"
}}

Respond ONLY with the JSON object. No preamble, no markdown fences, no explanation."""


def _invoke_bedrock(prompt: str) -> dict:
    body = json.dumps({
        'anthropic_version': 'bedrock-2023-05-31',
        'max_tokens': 1200,
        'messages': [{'role': 'user', 'content': prompt}],
    })
    resp = bedrock.invoke_model(
        modelId=BEDROCK_MODEL_ID,
        contentType='application/json',
        accept='application/json',
        body=body,
    )
    result = json.loads(resp['body'].read())
    raw    = result['content'][0]['text'].strip()

    # Strip markdown fences if model added them despite instructions
    if raw.startswith('```'):
        raw = raw.split('\n', 1)[1].rsplit('```', 1)[0].strip()

    return json.loads(raw)


def _update_incident(incident_id: str, timestamp: str, summary: dict) -> None:
    i_tbl.update_item(
        Key={'incidentId': incident_id, 'timestamp': timestamp},
        UpdateExpression='SET aiSummary = :s, #st = :open, resolvedAt = :null',
        ExpressionAttributeValues={
            ':s':    summary,
            ':open': 'OPEN',
            ':null': None,
        },
        ExpressionAttributeNames={'#st': 'status'},
    )


def _broadcast(incident_id: str, account_id: str, summary: dict) -> None:
    try:
        lmb.invoke(
            FunctionName=BROADCASTER_NAME,
            InvocationType='Event',
            Payload=json.dumps({
                'type': 'incident_summary_ready',
                'data': {
                    'incidentId': incident_id,
                    'accountId':  account_id,
                    'headline':   summary.get('headline', ''),
                    'confidence': summary.get('confidence', 'MEDIUM'),
                },
            }),
        )
    except ClientError as e:
        print(f'Broadcast failed: {e}')


# Hard rate limit — max 1 Bedrock call per account per hour
# This is a second layer of protection on top of the correlator cooldown
BEDROCK_RATE_LIMIT_SECONDS = 3600

def _rate_limit_ok(account_id: str) -> bool:
    """Check DynamoDB for recent AI summaries for this account."""
    cutoff = str(int((time.time() - BEDROCK_RATE_LIMIT_SECONDS) * 1000))
    try:
        resp = i_tbl.query(
            IndexName='AccountIdIndex',
            KeyConditionExpression=Key('accountId').eq(account_id) & Key('timestamp').gte(cutoff),
            FilterExpression=Attr('aiSummary').exists(),
        )
        recent_summaries = [i for i in resp.get('Items', []) if i.get('aiSummary') is not None]
        if recent_summaries:
            print(f'Rate limit hit: {account_id} already has {len(recent_summaries)} AI summaries in last hour — skipping Bedrock')
            return False
    except Exception as e:
        print(f'Rate limit check failed (allowing): {e}')
    return True


def handler(event, _context):
    incident = event.get('incident', {})
    if not incident:
        print('No incident payload received')
        return

    account_id   = incident.get('accountId', 'unknown')
    incident_id  = incident.get('incidentId', 'unknown')
    incident_type = incident.get('incidentType', 'unknown')

    print(f'Assembling incident | id={incident_id} | account={account_id}')

    # Hard rate limit check — abort if account already has a recent AI summary
    if not _rate_limit_ok(account_id):
        return {'skipped': True, 'reason': 'rate_limit', 'account': account_id}

    topology = _get_topology(account_id)
    runbook  = _get_runbook(incident_type)
    prompt   = _build_prompt(incident, topology, runbook)

    try:
        summary = _invoke_bedrock(prompt)
        print(f'Bedrock summary generated | confidence={summary.get("confidence")}')
    except Exception as e:
        print(f'Bedrock error: {e}')
        summary = {
            'headline':    f'Incident detected in {account_id} — AI summary unavailable',
            'whatChanged': [str(e)],
            'confidence':  'LOW',
        }

    _update_incident(incident_id, incident.get('timestamp', ''), summary)
    _broadcast(incident_id, account_id, summary)

    return {'incidentId': incident_id, 'summaryGenerated': True}
