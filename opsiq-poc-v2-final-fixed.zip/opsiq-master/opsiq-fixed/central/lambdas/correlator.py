"""
OpsIQ Central — correlator.py
SQS consumer (batch=10). Stores anomalies, queries last 15-min window,
groups correlated signals into incident clusters, triggers incident-assembler.

RATE LIMITING:
- One active incident per account per incident_type (deduplication)
- Bedrock called only ONCE per incident (aiSummary=None check)
- Bedrock called only if no HIGH incident exists in last 1 hour for account
"""
import json
import os
import time
import uuid

import boto3
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError

ANOMALY_TABLE   = os.environ['ANOMALY_TABLE']
INCIDENT_TABLE  = os.environ['INCIDENT_TABLE']
TOPOLOGY_TABLE  = os.environ['TOPOLOGY_TABLE']
HEALTH_TABLE    = os.environ['HEALTH_TABLE']
BROADCASTER_NAME = os.environ['WS_BROADCASTER_NAME']
WINDOW_MINUTES  = int(os.environ.get('CORRELATION_WINDOW_MINUTES', '15'))
PROJECT         = os.environ['PROJECT_NAME']

# ── Rate limiting constants ───────────────────────────────────────────────────
# Only invoke Bedrock if no AI summary was generated for this account in
# the last BEDROCK_COOLDOWN_SECONDS. Prevents runaway costs.
INCIDENT_DEDUP_WINDOW    = 60 * 60  # 1 hour — reuse existing open incidents

ddb    = boto3.resource('dynamodb')
lmb    = boto3.client('lambda')
a_tbl  = ddb.Table(ANOMALY_TABLE)
i_tbl  = ddb.Table(INCIDENT_TABLE)
t_tbl  = ddb.Table(TOPOLOGY_TABLE)
h_tbl  = ddb.Table(HEALTH_TABLE)

SEVERITY_RANK = {'HIGH': 3, 'MEDIUM': 2, 'LOW': 1}


def _store_anomaly(account_id: str, anomaly: dict) -> None:
    ts = str(int(time.time() * 1000))
    a_tbl.put_item(Item={
        'accountId':   account_id,
        'sortKey':     f'{ts}#{anomaly.get("anomalyId", str(uuid.uuid4()))}',
        'anomalyId':   anomaly.get('anomalyId', str(uuid.uuid4())),
        'anomalyType': anomaly.get('anomalyType', 'unknown'),
        'severity':    anomaly.get('severity', 'MEDIUM'),
        'details':     json.dumps(anomaly),
        'timestamp':   ts,
        'ttl':         int(time.time()) + 3 * 86400,   # 3-day TTL on anomalies
    })


def _query_recent_anomalies(account_id: str) -> list:
    cutoff = str(int((time.time() - WINDOW_MINUTES * 60) * 1000))
    resp = a_tbl.query(
        KeyConditionExpression=Key('accountId').eq(account_id) & Key('sortKey').gte(cutoff),
    )
    return resp.get('Items', [])


def _get_topology(account_id: str) -> list:
    resp = t_tbl.query(KeyConditionExpression=Key('accountId').eq(account_id))
    return resp.get('Items', [])


def _blast_radius(anomalies: list, topology: list) -> dict:
    affected_types = set()
    for a in anomalies:
        details = json.loads(a.get('details', '{}'))
        atype = details.get('anomalyType', '')
        if 'ecs' in atype or 'memory' in atype or 'cpu' in atype:
            affected_types.update(['aws_ecs_service', 'aws_ecs_cluster'])
        if 'alb' in atype or '5xx' in atype:
            affected_types.update(['aws_alb', 'aws_lb'])
        if 'rds' in atype or 'database' in atype:
            affected_types.update(['aws_rds_instance', 'aws_rds_cluster'])
        if 'lambda' in atype:
            affected_types.add('aws_lambda_function')

    directly  = [r for r in topology if r.get('resourceType') in affected_types]
    downstream = [r for r in topology
                  if r.get('tier') in ('data', 'storage') and r not in directly]

    return {
        'directlyAffected':    [r.get('resourceName', r.get('resourceArn', '')) for r in directly],
        'potentiallyAffected': [r.get('resourceName', r.get('resourceArn', '')) for r in downstream[:5]],
        'resourceCount':       len(directly),
    }


def _determine_incident_type(anomalies: list) -> str:
    types = [json.loads(a.get('details', '{}')).get('anomalyType', '') for a in anomalies]
    if any('memory' in t or 'oom' in t for t in types): return 'ecs_high_memory'
    if any('cpu' in t for t in types):                  return 'ecs_high_cpu'
    if any('5xx' in t or 'alb' in t for t in types):   return 'alb_5xx'
    if any('rds' in t or 'database' in t for t in types): return 'rds_connection_exhaustion'
    if any('novel' in t for t in types):                return 'novel_log_pattern'
    if any('volume' in t for t in types):               return 'log_volume_spike'
    if any('throttl' in t for t in types):              return 'api_throttling'
    return 'unknown'


def _find_existing_open_incident(account_id: str, incident_type: str) -> dict | None:
    """
    Look for an open incident of the same type created in the last hour.
    Returns the incident if found so we UPDATE it rather than create a new one.
    This is the primary deduplication mechanism.
    """
    cutoff = str(int((time.time() - INCIDENT_DEDUP_WINDOW) * 1000))
    try:
        resp = i_tbl.query(
            IndexName='AccountIdIndex',
            KeyConditionExpression=Key('accountId').eq(account_id) & Key('timestamp').gte(cutoff),
            FilterExpression=Attr('status').eq('OPEN') & Attr('incidentType').eq(incident_type),
        )
        items = resp.get('Items', [])
        if items:
            # Return the most recent one
            return max(items, key=lambda x: x.get('timestamp', '0'))
    except ClientError as e:
        # GSI might not exist — fall through to create new incident
        print(f'GSI query failed (expected on first deploy): {e}')
    return None


def _create_or_update_incident(account_id: str, anomalies: list, blast: dict) -> tuple[dict, bool]:
    """
    Returns (incident, is_new).
    If an open incident of the same type exists within the hour, update signal count.
    Otherwise create a new incident.
    """
    incident_type = _determine_incident_type(anomalies)
    existing = _find_existing_open_incident(account_id, incident_type)

    if existing:
        # Update signal count on existing incident — do NOT re-invoke Bedrock
        new_count = max(existing.get('signalCount', 0), len(anomalies))
        i_tbl.update_item(
            Key={'incidentId': existing['incidentId'], 'timestamp': existing['timestamp']},
            UpdateExpression='SET signalCount = :c, lastUpdated = :t',
            ExpressionAttributeValues={
                ':c': new_count,
                ':t': int(time.time() * 1000),
            },
        )
        existing['signalCount'] = new_count
        print(f'Incident updated (deduped) | id={existing["incidentId"]} | signals={new_count}')
        return existing, False

    # New incident
    max_severity  = max(anomalies, key=lambda a: SEVERITY_RANK.get(a.get('severity', 'LOW'), 0))
    ts            = str(int(time.time() * 1000))
    incident_id   = str(uuid.uuid4())

    item = {
        'incidentId':   incident_id,
        'accountId':    account_id,
        'timestamp':    ts,
        'status':       'OPEN',
        'severity':     max_severity.get('severity', 'MEDIUM'),
        'incidentType': incident_type,
        'signalCount':  len(anomalies),
        # Store only top 5 signals, minimal fields only — prevents GB-scale growth
        'signals':      [{'anomalyType': a.get('anomalyType',''), 'severity': a.get('severity',''),
                          'description': str(a.get('description', a.get('message','')))[:200]}
                         for a in [json.loads(x.get('details','{}')) for x in anomalies[:5]]],
        'blastRadius':  blast,
        'aiSummary':    None,
        'ttl':          int(time.time()) + 7 * 86400,  # 7-day TTL — auto-purged from DynamoDB
    }

    i_tbl.put_item(Item=item)
    print(f'Incident created | id={incident_id} | account={account_id} | signals={len(anomalies)}')
    return item, True


def _broadcast(event_type: str, payload: dict) -> None:
    try:
        lmb.invoke(
            FunctionName=BROADCASTER_NAME,
            InvocationType='Event',
            Payload=json.dumps({'type': event_type, 'data': payload}),
        )
    except ClientError as e:
        print(f'Broadcast failed: {e}')


def _update_health_score(account_id: str, anomalies: list) -> int:
    """Calculate and store health score. Respects baseScore floor."""
    score = 100
    for a in anomalies:
        sev = a.get('severity', 'LOW')
        score -= {'HIGH': 25, 'MEDIUM': 12, 'LOW': 5}.get(sev, 5)
    score = max(0, score)

    # Respect baseScore floor set by seeder for managed accounts
    try:
        existing = h_tbl.get_item(Key={'accountId': account_id}).get('Item', {})
        base_score = int(existing.get('baseScore', 0))
        score = max(score, base_score)
    except Exception:
        pass

    h_tbl.put_item(Item={
        'accountId':    account_id,
        'score':        score,
        'calculatedAt': int(time.time()),
        'ttl':          int(time.time()) + 6 * 60,
    })
    return score


def handler(event, _context):
    for record in event.get('Records', []):
        try:
            body       = json.loads(record['body'])
            anomaly    = body.get('detail', body)
            account_id = anomaly.get('accountId', 'unknown')

            _store_anomaly(account_id, anomaly)

            recent = _query_recent_anomalies(account_id)
            score  = _update_health_score(account_id, recent)

            _broadcast('health_score_updated', {'accountId': account_id, 'score': score})
            _broadcast('anomaly_detected', {**anomaly, 'accountId': account_id})

            # Need at least 2 anomalies to form an incident
            if len(recent) < 2:
                print(f'Anomaly stored | account={account_id} | window={len(recent)} signals')
                continue

            topology = _get_topology(account_id)
            blast    = _blast_radius(recent, topology)
            incident, is_new = _create_or_update_incident(account_id, recent, blast)

            if is_new:
                _broadcast('incident_created', {
                    'incidentId':  incident['incidentId'],
                    'accountId':   account_id,
                    'severity':    incident['severity'],
                    'signalCount': incident['signalCount'],
                    'status':      'OPEN',
                })

            # Bedrock summarisation is handled by incident_summariser Lambda
            # on a 30-minute schedule — NEVER called from the hot path here
            if is_new and incident['severity'] == 'HIGH':
                print(f'HIGH incident queued for summarisation | account={account_id} | id={incident["incidentId"]}')

        except Exception as e:
            print(f'Correlator error: {e}')
            raise

    return {'batchItemFailures': []}
