"""
OpsIQ Central — ws_broadcaster.py
Scans DynamoDB WSConnections, posts event payload to every active
WebSocket connection via API Gateway Management API. Removes stale connections.
"""
import json
import os

import boto3
from botocore.exceptions import ClientError

WS_TABLE    = os.environ['WS_TABLE']
WS_ENDPOINT = os.environ.get('WS_ENDPOINT', '')   # Injected by 06-dashboard.yaml custom resource
PROJECT     = os.environ['PROJECT_NAME']

ddb   = boto3.resource('dynamodb')
table = ddb.Table(WS_TABLE)


def handler(event, _context):
    if not WS_ENDPOINT:
        print('WS_ENDPOINT not set — skipping broadcast')
        return {'sent': 0}

    # Build the management API client using the WebSocket execute-api endpoint
    apigw = boto3.client(
        'apigatewaymanagementapi',
        endpoint_url=WS_ENDPOINT,
    )

    # Get all active connections
    resp        = table.scan(ProjectionExpression='connectionId')
    connections = [item['connectionId'] for item in resp.get('Items', [])]

    if not connections:
        return {'sent': 0}

    message = json.dumps(event).encode('utf-8')
    sent    = 0
    stale   = []

    for conn_id in connections:
        try:
            apigw.post_to_connection(
                ConnectionId=conn_id,
                Data=message,
            )
            sent += 1
        except ClientError as e:
            error_code = e.response['Error']['Code']
            if error_code in ('GoneException', '410'):
                stale.append(conn_id)
            else:
                print(f'WebSocket send error for {conn_id}: {e}')

    # Clean up stale connections
    for conn_id in stale:
        try:
            table.delete_item(Key={'connectionId': conn_id})
        except ClientError:
            pass

    print(f'Broadcast | sent={sent} | stale_removed={len(stale)} | '
          f'event_type={event.get("type", "unknown")}')
    return {'sent': sent, 'staleRemoved': len(stale)}
