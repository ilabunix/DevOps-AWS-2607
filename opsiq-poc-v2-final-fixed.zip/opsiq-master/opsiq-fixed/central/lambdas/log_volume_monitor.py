"""
OpsIQ Central — log_volume_monitor.py

Detects LOG VOLUME ANOMALIES — when the rate of ERROR/WARN logs
spikes significantly above the rolling baseline for that account and log group.

This replaces CloudWatch Log Anomaly Detection (volume) which is not
available in GovCloud.

Algorithm:
  - Maintains a rolling 7-day hourly baseline per account per log group per level
  - Stored in DynamoDB LogBaselines table (TTL 8 days)
  - On each invocation: compare last 5-minute count against expected hourly rate
  - Z-score threshold: if current rate > baseline_mean + 3*baseline_stddev → anomaly
  - Also detects SILENCE: if expected log rate drops to zero unexpectedly

Triggered: EventBridge schedule every 5 minutes
"""
import json
import math
import os
import time
import uuid
from decimal import Decimal
from collections import defaultdict

import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

BASELINE_TABLE  = os.environ['BASELINE_TABLE']    # DynamoDB: LogBaselines
ANOMALY_TABLE   = os.environ['ANOMALY_TABLE']
SIGNAL_BUS      = os.environ['SIGNAL_BUS_NAME']
LOG_STREAM_NAME = os.environ['LOG_STREAM_NAME']
PROJECT         = os.environ['PROJECT_NAME']

ddb   = boto3.resource('dynamodb')
cw    = boto3.client('cloudwatch')
eb    = boto3.client('events')
kinesis = boto3.client('kinesis')

b_tbl = ddb.Table(BASELINE_TABLE)
a_tbl = ddb.Table(ANOMALY_TABLE)

# Accounts and log groups to monitor
# In production this would be discovered from topology/Config
MONITORED = {
    'sim-app-a': [
        '/aws/ecs/sim-app-a-api',
        '/aws/lambda/sim-app-a-payment-processor',
        '/aws/rds/sim-app-a-postgres',
    ],
    'sim-app-b': [
        '/aws/lambda/sim-app-b-handler',
        '/aws/apigateway/sim-app-b',
    ],
    'sim-app-c': [
        '/aws/ecs/sim-app-c-web',
    ],
}

# Z-score threshold — how many standard deviations above mean = anomaly
Z_THRESHOLD     = 3.0
# Minimum baseline samples before anomaly detection kicks in
MIN_SAMPLES     = 6
# Minimum absolute spike to care about (ignores tiny counts)
MIN_SPIKE_COUNT = 5
# Window for current measurement (seconds)
MEASURE_WINDOW  = 300   # 5 minutes
# Silence detection: if we expected > N logs and got 0
SILENCE_THRESHOLD = 3


def _get_log_counts_from_kinesis_metrics(account_id: str, log_group: str) -> dict:
    """
    Get ERROR/WARN/INFO counts from CloudWatch custom metrics that the
    log_processor publishes as a side effect of processing.
    Falls back to reading from the OpsIQ/LogVolume namespace.
    Returns: {'ERROR': int, 'WARN': int, 'INFO': int}
    """
    end_time   = time.time()
    start_time = end_time - MEASURE_WINDOW

    counts = {'ERROR': 0, 'WARN': 0, 'INFO': 0}

    try:
        # Read from OpsIQ/LogVolume custom namespace published by log_processor
        for level in ['ERROR', 'WARN', 'INFO']:
            resp = cw.get_metric_statistics(
                Namespace='OpsIQ/LogVolume',
                MetricName='LogEventCount',
                Dimensions=[
                    {'Name': 'AccountId',  'Value': account_id},
                    {'Name': 'LogGroup',   'Value': log_group},
                    {'Name': 'Level',      'Value': level},
                ],
                StartTime=start_time,
                EndTime=end_time,
                Period=MEASURE_WINDOW,
                Statistics=['Sum'],
            )
            datapoints = resp.get('Datapoints', [])
            if datapoints:
                counts[level] = int(sum(d['Sum'] for d in datapoints))
    except ClientError:
        pass

    return counts


def _get_baseline(account_id: str, log_group: str, level: str) -> dict:
    """
    Fetch the rolling baseline for this account/log_group/level.
    Returns {'samples': [...], 'mean': float, 'stddev': float} or None.
    """
    pk = f'{account_id}#{log_group}'
    sk = f'baseline#{level}'
    try:
        resp = b_tbl.get_item(Key={'pk': pk, 'sk': sk})
        item = resp.get('Item')
        if not item:
            return None
        samples = [float(s) for s in item.get('samples', [])]
        if len(samples) < MIN_SAMPLES:
            return {'samples': samples, 'mean': None, 'stddev': None}
        mean    = sum(samples) / len(samples)
        variance = sum((s - mean) ** 2 for s in samples) / len(samples)
        stddev  = math.sqrt(variance)
        return {'samples': samples, 'mean': mean, 'stddev': stddev}
    except ClientError:
        return None


def _update_baseline(account_id: str, log_group: str, level: str, count: int) -> None:
    """
    Append the current 5-min count to the rolling baseline.
    Keep last 2016 samples = 7 days of 5-min intervals.
    """
    pk = f'{account_id}#{log_group}'
    sk = f'baseline#{level}'
    try:
        resp = b_tbl.get_item(Key={'pk': pk, 'sk': sk})
        item = resp.get('Item', {})
        samples = list(item.get('samples', []))
        samples.append(Decimal(str(count)))
        # Keep last 7 days = 2016 samples
        samples = samples[-2016:]

        b_tbl.put_item(Item={
            'pk':      pk,
            'sk':      sk,
            'samples': samples,
            'lastUpdated': int(time.time()),
            'ttl':     int(time.time()) + 8 * 86400,  # 8-day TTL
        })
    except ClientError as e:
        print(f'Baseline update failed {account_id}/{log_group}/{level}: {e}')


def _is_anomalous(count: int, baseline: dict) -> tuple:
    """
    Returns (is_anomaly: bool, z_score: float, severity: str)
    """
    if baseline is None or baseline['mean'] is None:
        return False, 0.0, 'LOW'

    mean   = baseline['mean']
    stddev = baseline['stddev']

    # If stddev is near zero (very stable baseline), use 20% of mean as floor
    if stddev < 0.5:
        stddev = max(0.5, mean * 0.2)

    z_score = (count - mean) / stddev if stddev > 0 else 0

    if z_score >= Z_THRESHOLD and count >= MIN_SPIKE_COUNT:
        severity = 'HIGH' if z_score >= Z_THRESHOLD * 2 else 'MEDIUM'
        return True, round(z_score, 2), severity

    return False, round(z_score, 2), 'LOW'


def _is_silence(count: int, baseline: dict) -> bool:
    """
    Detect if a normally-active log group has gone completely silent.
    """
    if baseline is None or baseline['mean'] is None:
        return False
    return count == 0 and baseline['mean'] >= SILENCE_THRESHOLD


def _emit_anomaly(account_id: str, log_group: str, level: str,
                  count: int, baseline: dict, z_score: float,
                  severity: str, anomaly_type: str) -> None:
    """Emit anomaly event to EventBridge and store in DynamoDB."""
    anomaly_id = str(uuid.uuid4())
    ts         = int(time.time() * 1000)

    detail = {
        'accountId':    account_id,
        'anomalyId':    anomaly_id,
        'anomalyType':  anomaly_type,
        'severity':     severity,
        'logGroup':     log_group,
        'level':        level,
        'currentCount': count,
        'baselineMean': round(baseline.get('mean') or 0, 2),
        'baselineStddev': round(baseline.get('stddev') or 0, 2),
        'zScore':       z_score,
        'windowSeconds': MEASURE_WINDOW,
        'timestamp':    ts,
        'source':       'opsiq.log_volume_monitor',
        'description':  (
            f'Log silence detected in {log_group} — expected {baseline.get("mean", 0):.1f} {level} logs/5min, got 0'
            if anomaly_type == 'log_silence'
            else f'{level} log volume spike in {log_group}: {count} events in 5min '
                 f'(baseline {baseline.get("mean", 0):.1f}±{baseline.get("stddev", 0):.1f}, z-score {z_score})'
        ),
    }

    # Store in anomaly history
    a_tbl.put_item(Item={
        'accountId':   account_id,
        'sortKey':     f'{ts}#{anomaly_id}',
        'anomalyId':   anomaly_id,
        'anomalyType': anomaly_type,
        'severity':    severity,
        'details':     json.dumps(detail),
        'timestamp':   str(ts),
        'ttl':         int(time.time()) + 30 * 86400,
    })

    # Emit to EventBridge for correlator
    eb.put_events(Entries=[{
        'Source':       'opsiq.logs',
        'DetailType':   'LogVolumeAnomaly',
        'EventBusName': SIGNAL_BUS,
        'Detail':       json.dumps(detail),
    }])

    print(f'ANOMALY {anomaly_type} | account={account_id} | '
          f'group={log_group} | level={level} | count={count} | '
          f'z={z_score} | sev={severity}')


def handler(event, _context):
    total_anomalies = 0
    total_checked   = 0

    for account_id, log_groups in MONITORED.items():
        for log_group in log_groups:
            counts = _get_log_counts_from_kinesis_metrics(account_id, log_group)

            for level in ['ERROR', 'WARN']:
                count    = counts.get(level, 0)
                baseline = _get_baseline(account_id, log_group, level)

                # Check for volume spike
                is_anom, z_score, severity = _is_anomalous(count, baseline)
                if is_anom:
                    _emit_anomaly(account_id, log_group, level,
                                  count, baseline, z_score, severity,
                                  'log_volume_spike')
                    total_anomalies += 1

                # Check for silence (only ERROR level — silence in WARN is normal)
                if level == 'ERROR' and _is_silence(count, baseline):
                    _emit_anomaly(account_id, log_group, level,
                                  count, baseline, 0.0, 'MEDIUM',
                                  'log_silence')
                    total_anomalies += 1

                # Always update baseline with current count
                _update_baseline(account_id, log_group, level, count)
                total_checked += 1

    print(f'log_volume_monitor | checked={total_checked} | anomalies={total_anomalies}')
    return {'checked': total_checked, 'anomalies': total_anomalies}
