#!/usr/bin/env bash
# opsiq-poc/central/scripts/deploy-central.sh
# Deploys all 9 central OpsIQ CloudFormation stacks in order.
#
# Prerequisites:
#   - AWS CLI configured (us-west-2 commercial)
#   - Amazon Bedrock → Model Access → Claude Sonnet 4.6 enabled
#   - zip installed locally
#
# Usage:
#   export REGION=us-west-2
#   ./deploy-central.sh

set -euo pipefail

PROJECT="${PROJECT:-opsiq}"
REGION="${REGION:-us-west-2}"
CFN_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../cloudformation" && pwd)"
LAMBDA_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../lambdas" && pwd)"
BEDROCK_MODEL="${BEDROCK_MODEL:-us.anthropic.claude-haiku-4-5}"

DEPLOY_FLAGS="--region $REGION --no-fail-on-empty-changeset"

echo "╔══════════════════════════════════════════════════╗"
echo "║  OpsIQ Central — Deploy (9 stacks)              ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║  Project : $PROJECT"
echo "║  Region  : $REGION"
echo "║  Model   : $BEDROCK_MODEL"
echo "╚══════════════════════════════════════════════════╝"
echo ""

# Derive account ID and bucket name
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
LAMBDA_CODE_BUCKET="${LAMBDA_CODE_BUCKET:-${PROJECT}-lambda-pkgs-${ACCOUNT_ID}}"
echo "  Lambda bucket: $LAMBDA_CODE_BUCKET"
echo ""

# ── STACK 1 — STORAGE + CLOUDFRONT ────────────────────────────────────────
echo "Step 1/9 — Storage (S3 + DynamoDB + CloudFront)"
aws cloudformation deploy \
  --template-file "$CFN_DIR/01-storage.yaml" \
  --stack-name "${PROJECT}-central-storage" \
  --parameter-overrides ProjectName="$PROJECT" \
  $DEPLOY_FLAGS
echo "  ✓ Storage stack deployed"
echo ""

# Use the bucket created by stack 1 if not overridden
LAMBDA_CODE_BUCKET=$(aws cloudformation describe-stacks \
  --stack-name "${PROJECT}-central-storage" --region "$REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='LambdaCodeBucketName'].OutputValue" \
  --output text 2>/dev/null || echo "$LAMBDA_CODE_BUCKET")

# ── PACKAGE AND UPLOAD LAMBDAS ─────────────────────────────────────────────
echo "Step 1b — Package and upload Lambda functions"
bash "$LAMBDA_DIR/package.sh" "$LAMBDA_CODE_BUCKET"
echo ""

# ── STACK 2 — INGESTION ────────────────────────────────────────────────────
echo "Step 2/9 — Ingestion (Kinesis + SQS + EventBridge)"
aws cloudformation deploy \
  --template-file "$CFN_DIR/02-ingestion.yaml" \
  --stack-name "${PROJECT}-central-ingestion" \
  --parameter-overrides ProjectName="$PROJECT" \
  $DEPLOY_FLAGS
echo "  ✓ Ingestion stack deployed"
echo ""

# ── STACK 3 — IAM ─────────────────────────────────────────────────────────
echo "Step 3/9 — IAM Roles + Bedrock permissions"
aws cloudformation deploy \
  --template-file "$CFN_DIR/03-iam.yaml" \
  --stack-name "${PROJECT}-central-iam" \
  --parameter-overrides ProjectName="$PROJECT" \
  --capabilities CAPABILITY_NAMED_IAM \
  $DEPLOY_FLAGS
echo "  ✓ IAM stack deployed"
echo ""

# ── STACK 4 — LAMBDAS ─────────────────────────────────────────────────────
echo "Step 4/9 — Lambda Functions (12 functions)"
aws cloudformation deploy \
  --template-file "$CFN_DIR/04-lambdas-central.yaml" \
  --stack-name "${PROJECT}-central-lambdas" \
  --parameter-overrides \
    ProjectName="$PROJECT" \
    LambdaCodeBucket="$LAMBDA_CODE_BUCKET" \
    BedrockModelId="$BEDROCK_MODEL" \
  --capabilities CAPABILITY_NAMED_IAM \
  $DEPLOY_FLAGS
echo "  ✓ Lambda stack deployed"
echo ""

# ── STACK 5 — API GATEWAY ─────────────────────────────────────────────────
echo "Step 5/9 — API Gateway (REST + WebSocket)"
aws cloudformation deploy \
  --template-file "$CFN_DIR/05-api.yaml" \
  --stack-name "${PROJECT}-central-api" \
  --parameter-overrides ProjectName="$PROJECT" \
  $DEPLOY_FLAGS
echo "  ✓ API stack deployed"
echo ""

# ── STACK 6 — DASHBOARD CONFIG ────────────────────────────────────────────
echo "Step 6/9 — Dashboard config + schedule activation"
aws cloudformation deploy \
  --template-file "$CFN_DIR/06-dashboard.yaml" \
  --stack-name "${PROJECT}-central-dashboard" \
  --parameter-overrides ProjectName="$PROJECT" \
  --capabilities CAPABILITY_NAMED_IAM \
  $DEPLOY_FLAGS
echo "  ✓ Dashboard stack deployed"
echo ""

# ── STACK 7 — LOG ANOMALY DETECTION ───────────────────────────────────────
echo "Step 7/9 — Log anomaly detection (volume + pattern monitors)"
aws cloudformation deploy \
  --template-file "$CFN_DIR/07-log-anomaly.yaml" \
  --stack-name "${PROJECT}-central-log-anomaly" \
  --parameter-overrides \
    ProjectName="$PROJECT" \
    LambdaCodeBucket="$LAMBDA_CODE_BUCKET" \
  --capabilities CAPABILITY_NAMED_IAM \
  $DEPLOY_FLAGS
echo "  ✓ Log anomaly stack deployed"
echo ""

# ── STACK 8 — FIXES (chat handler + manual seeder) ────────────────────────
echo "Step 8/9 — Chat handler + manual seeder"
aws cloudformation deploy \
  --template-file "$CFN_DIR/08-fixes.yaml" \
  --stack-name "${PROJECT}-central-fixes" \
  --parameter-overrides \
    ProjectName="$PROJECT" \
    LambdaCodeBucket="$LAMBDA_CODE_BUCKET" \
    BedrockModelId="$BEDROCK_MODEL" \
  --capabilities CAPABILITY_NAMED_IAM \
  $DEPLOY_FLAGS
echo "  ✓ Fixes stack deployed"
echo ""

# ── STACK 9 — INCIDENT SUMMARISER ─────────────────────────────────────────
echo "Step 9/9 — On-demand incident summariser (Bedrock cost-controlled)"
aws cloudformation deploy \
  --template-file "$CFN_DIR/09-summariser.yaml" \
  --stack-name "${PROJECT}-central-summariser" \
  --parameter-overrides \
    ProjectName="$PROJECT" \
    LambdaCodeBucket="$LAMBDA_CODE_BUCKET" \
    BedrockModelId="$BEDROCK_MODEL" \
  --capabilities CAPABILITY_NAMED_IAM \
  $DEPLOY_FLAGS
echo "  ✓ Summariser stack deployed (schedule starts DISABLED)"
echo ""

# ── ADD /chat ROUTE TO API GATEWAY ────────────────────────────────────────
echo "Wiring /chat route to API Gateway..."
bash "$(dirname "${BASH_SOURCE[0]}")/add-chat-route.sh"
echo ""

# ── UPLOAD RUNBOOKS ────────────────────────────────────────────────────────
echo "Uploading runbooks to S3..."
RUNBOOKS_BUCKET="${PROJECT}-runbooks-${ACCOUNT_ID}"
RUNBOOKS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../runbooks" && pwd)"
aws s3 sync "$RUNBOOKS_DIR" "s3://$RUNBOOKS_BUCKET/runbooks/" \
  --include "*.md" --quiet --region "$REGION"
echo "  ✓ Runbooks uploaded"
echo ""

# ── PRINT OUTPUTS ─────────────────────────────────────────────────────────
REST_URL=$(aws cloudformation describe-stacks \
  --stack-name "${PROJECT}-central-api" --region "$REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='RestAPIEndpoint'].OutputValue" \
  --output text)

WS_URL=$(aws cloudformation describe-stacks \
  --stack-name "${PROJECT}-central-api" --region "$REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='WebSocketEndpoint'].OutputValue" \
  --output text)

CF_URL=$(aws cloudformation describe-stacks \
  --stack-name "${PROJECT}-central-storage" --region "$REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='DashboardURL'].OutputValue" \
  --output text)

CF_ID=$(aws cloudformation describe-stacks \
  --stack-name "${PROJECT}-central-storage" --region "$REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='DashboardDistributionId'].OutputValue" \
  --output text)

echo "╔══════════════════════════════════════════════════╗"
echo "║  Central Deployment Complete                     ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║  REST API    : $REST_URL"
echo "║  WebSocket   : $WS_URL"
echo "║  Dashboard   : $CF_URL"
echo "║  CloudFront  : $CF_ID"
echo "╚══════════════════════════════════════════════════╝"
echo ""
echo "Next: build and upload the dashboard"
echo "  cd ../../dashboard && ./rebuild.sh"
echo ""
echo "Then deploy simulation:"
echo "  cd ../../simulation/scripts && ./deploy-simulation.sh"
