#!/bin/bash
# fix-chat-handler.sh
# Diagnoses and fixes chat handler issues on Git Bash / Windows WorkSpace
# No python3 dependency - pure bash + AWS CLI

REGION=us-west-2
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)

echo "=== Current chat-handler env vars ==="
aws lambda get-function-configuration \
  --function-name opsiq-chat-handler \
  --region $REGION \
  --query 'Environment.Variables' \
  --output table

echo ""
echo "=== Testing Bedrock connectivity ==="
# Write payload to temp file to avoid base64/quoting issues on Windows
cat > /tmp/bedrock-payload.json << 'PAYLOAD'
{"anthropic_version":"bedrock-2023-05-31","max_tokens":50,"messages":[{"role":"user","content":"say hi"}]}
PAYLOAD

aws bedrock-runtime invoke-model \
  --model-id us.anthropic.claude-haiku-4-5 \
  --region $REGION \
  --content-type application/json \
  --accept application/json \
  --body fileb:///tmp/bedrock-payload.json \
  /tmp/bedrock-test.json 2>&1

if [ -f /tmp/bedrock-test.json ]; then
  echo "Bedrock RESPONSE:"
  cat /tmp/bedrock-test.json
else
  echo "Bedrock FAILED - model access not enabled or wrong model ID"
  echo ""
  echo "Fix: Go to AWS Console → Amazon Bedrock → Model Access"
  echo "     Request access to Claude Sonnet 4.6"
  echo "     Model ID to use: us.anthropic.claude-haiku-4-5"
fi

echo ""
echo "=== Invoking chat Lambda directly ==="
# Write the test event to a file to avoid quoting issues
cat > /tmp/chat-event.json << 'EVENT'
{"httpMethod":"POST","path":"/chat","headers":{"Content-Type":"application/json"},"body":"{\"message\":\"what accounts are monitored?\"}"}
EVENT

aws lambda invoke \
  --function-name opsiq-chat-handler \
  --region $REGION \
  --payload fileb:///tmp/chat-event.json \
  --log-type Tail \
  --cli-binary-format raw-in-base64-out \
  /tmp/chat-response.json 2>/tmp/chat-invoke-meta.json

echo "Lambda response:"
cat /tmp/chat-response.json

echo ""
echo "=== Lambda execution logs ==="
# Extract and decode the log from the invoke response
LOG_RESULT=$(aws lambda invoke \
  --function-name opsiq-chat-handler \
  --region $REGION \
  --payload fileb:///tmp/chat-event.json \
  --log-type Tail \
  --cli-binary-format raw-in-base64-out \
  /tmp/chat-response2.json \
  --query 'LogResult' \
  --output text 2>/dev/null)

if [ -n "$LOG_RESULT" ] && [ "$LOG_RESULT" != "None" ]; then
  echo "$LOG_RESULT" | base64 -d 2>/dev/null || echo "(could not decode logs)"
else
  echo "(no log result - check CloudWatch Logs)"
  echo ""
  echo "View logs manually:"
  echo "  aws logs tail /aws/lambda/opsiq-chat-handler --region $REGION --since 10m"
fi

echo ""
echo "=== CloudWatch recent errors ==="
aws logs filter-log-events \
  --log-group-name /aws/lambda/opsiq-chat-handler \
  --region $REGION \
  --start-time $(( $(date +%s) * 1000 - 3600000 )) \
  --filter-pattern "ERROR" \
  --query 'events[*].message' \
  --output text 2>/dev/null | tail -20 || echo "(no error logs found or log group not yet created)"
