#!/bin/bash
# Adds POST /chat route to the existing REST API Gateway
# Run AFTER stack 8 (opsiq-central-fixes) is deployed

set -e

REGION=us-west-2
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)

# Get REST API ID from CFN
REST_API_ID=$(aws cloudformation describe-stacks \
  --stack-name opsiq-central-api --region $REGION \
  --query "Stacks[0].Outputs[?OutputKey=='RestAPIEndpoint'].OutputValue" \
  --output text | grep -oP '[a-z0-9]+(?=\.execute-api)')

echo "REST API ID: $REST_API_ID"

# Get root resource ID
ROOT_ID=$(aws apigateway get-resources \
  --rest-api-id $REST_API_ID --region $REGION \
  --query "items[?path=='/'].id" --output text)

# Check if /chat already exists
EXISTING=$(aws apigateway get-resources \
  --rest-api-id $REST_API_ID --region $REGION \
  --query "items[?path=='/chat'].id" --output text)

if [ -n "$EXISTING" ]; then
  echo "/chat resource already exists: $EXISTING"
  CHAT_ID=$EXISTING
else
  echo "Creating /chat resource..."
  CHAT_ID=$(aws apigateway create-resource \
    --rest-api-id $REST_API_ID \
    --parent-id $ROOT_ID \
    --path-part chat \
    --region $REGION \
    --query "id" --output text)
  echo "Created: $CHAT_ID"
fi

# ── POST method + Lambda integration ─────────────────────────────────────────

echo "Adding POST method..."
aws apigateway put-method \
  --rest-api-id $REST_API_ID \
  --resource-id $CHAT_ID \
  --http-method POST \
  --authorization-type NONE \
  --region $REGION 2>/dev/null || echo "POST method already exists"

# Get chat handler ARN
LAMBDA_ARN=$(aws lambda get-function \
  --function-name opsiq-chat-handler \
  --region $REGION \
  --query "Configuration.FunctionArn" \
  --output text)

echo "Lambda ARN: $LAMBDA_ARN"

echo "Wiring POST → Lambda integration..."
aws apigateway put-integration \
  --rest-api-id $REST_API_ID \
  --resource-id $CHAT_ID \
  --http-method POST \
  --type AWS_PROXY \
  --integration-http-method POST \
  --uri "arn:aws:apigateway:${REGION}:lambda:path/2015-03-31/functions/${LAMBDA_ARN}/invocations" \
  --region $REGION 2>/dev/null || echo "POST integration already exists"

# Grant API Gateway permission to invoke Lambda
echo "Granting API Gateway permission..."
aws lambda add-permission \
  --function-name opsiq-chat-handler \
  --statement-id "apigateway-chat-$(date +%s)" \
  --action lambda:InvokeFunction \
  --principal apigateway.amazonaws.com \
  --source-arn "arn:aws:execute-api:${REGION}:${ACCOUNT_ID}:${REST_API_ID}/*/*" \
  --region $REGION 2>/dev/null || echo "Permission may already exist"

# ── OPTIONS method + MOCK integration (CORS) ─────────────────────────────────

echo "Adding OPTIONS method (CORS)..."
aws apigateway put-method \
  --rest-api-id $REST_API_ID \
  --resource-id $CHAT_ID \
  --http-method OPTIONS \
  --authorization-type NONE \
  --region $REGION 2>/dev/null || echo "OPTIONS method already exists"

echo "Wiring OPTIONS → MOCK integration..."
aws apigateway put-integration \
  --rest-api-id $REST_API_ID \
  --resource-id $CHAT_ID \
  --http-method OPTIONS \
  --type MOCK \
  --request-templates '{"application/json": "{\"statusCode\": 200}"}' \
  --region $REGION 2>/dev/null || echo "OPTIONS integration already exists"

echo "Adding OPTIONS method response..."
aws apigateway put-method-response \
  --rest-api-id $REST_API_ID \
  --resource-id $CHAT_ID \
  --http-method OPTIONS \
  --status-code 200 \
  --response-parameters '{
    "method.response.header.Access-Control-Allow-Headers": false,
    "method.response.header.Access-Control-Allow-Methods": false,
    "method.response.header.Access-Control-Allow-Origin": false
  }' \
  --region $REGION 2>/dev/null || echo "OPTIONS method response already exists"

echo "Adding OPTIONS integration response..."
aws apigateway put-integration-response \
  --rest-api-id $REST_API_ID \
  --resource-id $CHAT_ID \
  --http-method OPTIONS \
  --status-code 200 \
  --response-parameters '{
    "method.response.header.Access-Control-Allow-Headers": "'"'"'Content-Type,X-Amz-Date,Authorization'"'"'",
    "method.response.header.Access-Control-Allow-Methods": "'"'"'POST,OPTIONS'"'"'",
    "method.response.header.Access-Control-Allow-Origin": "'"'"'*'"'"'"
  }' \
  --region $REGION 2>/dev/null || echo "OPTIONS integration response already exists"

# ── Deploy ────────────────────────────────────────────────────────────────────

echo "Redeploying API..."
aws apigateway create-deployment \
  --rest-api-id $REST_API_ID \
  --stage-name poc \
  --region $REGION

echo ""
echo "✓ Done! /chat route is live."
echo ""
echo "Test with:"
echo "  curl -X POST https://${REST_API_ID}.execute-api.${REGION}.amazonaws.com/poc/chat \\"
echo "    -H 'Content-Type: application/json' \\"
echo "    -d '{\"message\": \"what accounts are monitored?\"}'"
