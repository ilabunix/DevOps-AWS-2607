#!/usr/bin/env bash
# dashboard/build.sh
# Builds the OpsIQ React dashboard and uploads to the S3 website bucket.
# Run after deploy-central.sh so the API and WebSocket endpoints are available.
#
# Usage:
#   export AWS_PROFILE=your-govcloud-profile
#   export REGION=us-gov-east-1
#   export PROJECT=opsiq
#   ./build.sh
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT="${PROJECT:-opsiq}"
REGION="${REGION:-us-gov-east-1}"

echo "╔══════════════════════════════════════════════════╗"
echo "║  OpsIQ Dashboard — Build & Deploy               ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""

# ── FETCH ENDPOINTS FROM CFN ───────────────────────────────────────────────
echo "Fetching API endpoints from CloudFormation..."

REST_URL=$(aws cloudformation describe-stacks \
  --stack-name "${PROJECT}-central-api" --region "$REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='RestAPIEndpoint'].OutputValue" \
  --output text 2>/dev/null) || REST_URL=""

WS_URL=$(aws cloudformation describe-stacks \
  --stack-name "${PROJECT}-central-api" --region "$REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='WebSocketEndpoint'].OutputValue" \
  --output text 2>/dev/null) || WS_URL=""

ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
DASHBOARD_BUCKET="${PROJECT}-dashboard-${ACCOUNT_ID}"

if [[ -z "$REST_URL" ]]; then
  echo "  ERROR: Could not fetch RestAPIEndpoint from ${PROJECT}-central-api stack."
  echo "  Make sure deploy-central.sh has completed successfully."
  exit 1
fi

echo "  REST API  : $REST_URL"
echo "  WebSocket : $WS_URL"
echo "  S3 Bucket : $DASHBOARD_BUCKET"
echo ""

# ── INSTALL DEPENDENCIES ───────────────────────────────────────────────────
echo "Installing npm dependencies..."
cd "$SCRIPT_DIR"
npm install --silent
echo "  ✓ Dependencies installed"
echo ""

# ── BUILD ──────────────────────────────────────────────────────────────────
echo "Building React app..."
VITE_API_URL="$REST_URL" \
VITE_WS_URL="$WS_URL" \
npm run build
echo "  ✓ Build complete → dist/"
echo ""

# ── UPLOAD TO S3 ──────────────────────────────────────────────────────────
echo "Uploading to S3..."

# Upload all assets with long cache (hashed filenames)
aws s3 sync dist/ "s3://$DASHBOARD_BUCKET/" \
  --region "$REGION" \
  --delete \
  --exclude "index.html" \
  --cache-control "public, max-age=31536000, immutable" \
  --quiet

# Upload index.html with no-cache (always re-fetched)
aws s3 cp dist/index.html "s3://$DASHBOARD_BUCKET/index.html" \
  --region "$REGION" \
  --cache-control "no-cache, no-store, must-revalidate" \
  --content-type "text/html" \
  --quiet

echo "  ✓ Uploaded to s3://$DASHBOARD_BUCKET/"
echo ""

# ── DONE ───────────────────────────────────────────────────────────────────
WEBSITE_URL=$(aws cloudformation describe-stacks \
  --stack-name "${PROJECT}-central-storage" --region "$REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='DashboardURL'].OutputValue" \
  --output text 2>/dev/null) || WEBSITE_URL="http://${DASHBOARD_BUCKET}.s3-website.${REGION}.amazonaws.com"

echo "╔══════════════════════════════════════════════════╗"
echo "║  Dashboard deployed                              ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║  URL: $WEBSITE_URL"
echo "╚══════════════════════════════════════════════════╝"
