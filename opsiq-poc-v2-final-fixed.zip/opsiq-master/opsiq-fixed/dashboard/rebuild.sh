#!/bin/bash
# rebuild.sh — builds and deploys the OpsIQ dashboard
# Usage: ./rebuild.sh [REST_API_ID] [WEBSOCKET_API_ID]
# With no args: auto-reads API IDs from CloudFormation

set -e

REGION=us-west-2
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)

# ── Get API IDs ───────────────────────────────────────────────────────────────
if [ -n "$1" ] && [ -n "$2" ]; then
  REST_API_ID=$1
  WS_API_ID=$2
else
  echo "Getting API IDs from CloudFormation..."
  REST_API_ID=$(aws cloudformation describe-stacks \
    --stack-name opsiq-central-api --region $REGION \
    --query "Stacks[0].Outputs[?OutputKey=='RestAPIEndpoint'].OutputValue" \
    --output text | grep -oP '[a-z0-9]+(?=\.execute-api)')
  WS_API_ID=$(aws cloudformation describe-stacks \
    --stack-name opsiq-central-api --region $REGION \
    --query "Stacks[0].Outputs[?OutputKey=='WebSocketAPIId'].OutputValue" \
    --output text)
fi

echo "REST API ID : $REST_API_ID"
echo "WebSocket ID: $WS_API_ID"

# ── npm install if node_modules missing ───────────────────────────────────────
if [ ! -d "node_modules" ]; then
  echo ""
  echo "node_modules not found — running npm install..."
  npm install
fi

# ── Find vite binary ──────────────────────────────────────────────────────────
# Works on Git Bash/Windows, Mac, and Linux
if [ -f "./node_modules/.bin/vite" ]; then
  VITE="./node_modules/.bin/vite"
elif [ -f "./node_modules/.bin/vite.cmd" ]; then
  VITE="./node_modules/.bin/vite.cmd"
elif command -v vite &>/dev/null; then
  VITE="vite"
else
  echo "ERROR: vite not found. Run 'npm install' first."
  exit 1
fi

echo ""
echo "Building with vite..."
VITE_API_URL="https://${REST_API_ID}.execute-api.${REGION}.amazonaws.com/poc" \
VITE_WS_URL="wss://${WS_API_ID}.execute-api.${REGION}.amazonaws.com/poc" \
"$VITE" build

# ── Verify API IDs are baked in ───────────────────────────────────────────────
echo ""
echo "Verifying build..."
if grep -q "$REST_API_ID" dist/assets/*.js 2>/dev/null; then
  echo "✓ REST API ID confirmed in build: $REST_API_ID"
else
  echo "WARNING: REST API ID not found in build — something may be wrong"
fi

# ── Upload to S3 ──────────────────────────────────────────────────────────────
echo ""
echo "Uploading to S3..."
aws s3 sync dist/ s3://opsiq-dashboard-${ACCOUNT_ID}/ \
  --region $REGION \
  --delete \
  --exclude "index.html" \
  --cache-control "public, max-age=31536000, immutable"

aws s3 cp dist/index.html s3://opsiq-dashboard-${ACCOUNT_ID}/index.html \
  --region $REGION \
  --cache-control "no-cache, no-store, must-revalidate" \
  --content-type "text/html"

echo ""
echo "✓ Done! Last step: invalidate CloudFront /* and hard refresh (Ctrl+Shift+R)."
