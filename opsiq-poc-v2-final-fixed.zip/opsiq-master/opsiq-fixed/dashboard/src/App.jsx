import { useEffect } from 'react';
import { useStore } from './store.js';
import TopNav       from './components/TopNav.jsx';
import Sidebar      from './components/Sidebar.jsx';
import Dashboard    from './components/Dashboard.jsx';
import ChatPanel    from './components/ChatPanel.jsx';
import ChatView              from './components/views/ChatView.jsx';
import IncidentsView         from './components/views/IncidentsView.jsx';
import IncidentTimelineView  from './components/views/IncidentTimelineView.jsx';
import AnomaliesView         from './components/views/AnomaliesView.jsx';
import SignalsView            from './components/views/SignalsView.jsx';
import LogQueryView          from './components/views/LogQueryView.jsx';
import TopologyView          from './components/views/TopologyView.jsx';
import DriftView             from './components/views/DriftView.jsx';
import RunbooksView          from './components/views/RunbooksView.jsx';
import AccountsView          from './components/views/AccountsView.jsx';

function ViewRouter() {
  const view = useStore(s => s.currentView);
  switch (view) {
    case 'Chat':             return <ChatView />;
    case 'Incidents':        return <IncidentsView />;
    case 'IncidentTimeline': return <IncidentTimelineView />;
    case 'Anomalies':        return <AnomaliesView />;
    case 'Signals':          return <SignalsView />;
    case 'LogSearch':        return <LogQueryView />;
    case 'Topology':         return <TopologyView />;
    case 'Drift':            return <DriftView />;
    case 'Runbooks':         return <RunbooksView />;
    case 'Accounts':         return <AccountsView />;
    default:                 return <Dashboard />;
  }
}

export default function App() {
  const init = useStore(s => s.init);
  useEffect(() => { const cleanup = init(); return cleanup; }, []);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
      <TopNav />
      <div className="shell">
        <Sidebar />
        <main className="main-area"><ViewRouter /></main>
      </div>
      <ChatPanel /> {/* Floating panel — unchanged */}
    </div>
  );
}
