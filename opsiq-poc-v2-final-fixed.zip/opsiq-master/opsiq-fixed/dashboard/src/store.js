import { create } from 'zustand';
import { api, connectWebSocket, subscribeToEvents } from './api.js';

export const useStore = create((set, get) => ({
  currentView: 'Dashboard',
  setView: (view) => set({ currentView: view }),
  accounts: [], incidents: [], anomalies: [], topology: {},
  scoreHistory: {},   // { accountId: [score, score, ...] } — last 12 readings for trend
  selectedAccountId: null, demoStatus: null,
  loading: { accounts: false, incidents: false, anomalies: false },
  lastRefreshed: null,

  setSelectedAccount: (id) => {
    set({ selectedAccountId: id });
    get().fetchTopology(id);
  },

  fetchAll: async () => {
    set({ loading: { accounts: true, incidents: true, anomalies: true } });
    try {
      const [accountsRes, incidentsRes] = await Promise.all([
        api.getAccounts(), api.getAllIncidents(),
      ]);
      const accounts  = (accountsRes.accounts  || []).map(a => ({ ...a, score: Number(a.score || 0) }));
      const incidents = incidentsRes.incidents || [];
      const anomalyResults = await Promise.all(
        accounts.map(a => api.getAnomalies(a.accountId).catch(() => ({ anomalies: [] })))
      );
      const anomalies = anomalyResults
        .flatMap(r => r.anomalies || [])
        .sort((a, b) => Number(b.timestamp || 0) - Number(a.timestamp || 0))
        .slice(0, 50);
      // Update score history for trend calculation (keep last 12 readings = ~1hr)
      set(state => {
        const hist = { ...state.scoreHistory };
        accounts.forEach(a => {
          const prev = hist[a.accountId] || [];
          hist[a.accountId] = [...prev, a.score].slice(-12);
        });
        return { accounts, incidents, anomalies, scoreHistory: hist,
          loading: { accounts: false, incidents: false, anomalies: false },
          lastRefreshed: new Date() };
      });
    } catch (e) {
      console.error('fetchAll failed', e);
      set({ loading: { accounts: false, incidents: false, anomalies: false } });
    }
  },

  fetchTopology: async (accountId) => {
    if (!accountId) return;
    try {
      const data = await api.getTopology(accountId);
      set(state => ({ topology: { ...state.topology, [accountId]: data } }));
    } catch (e) { console.error(`fetchTopology(${accountId}) failed`, e); }
  },

  triggerDemo: async (scenario = 'ecs-oom', accountId = 'sim-app-a') => {
    set({ demoStatus: 'injecting' });
    try {
      await fetch(`${import.meta.env.VITE_API_URL || ''}/demo/inject`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scenario, accountId }),
      });
    } catch (e) {}
    set({ demoStatus: 'injected' });
    setTimeout(() => set({ demoStatus: null }), 5000);
  },

  mergeEvent: (event) => {
    const { type, data } = event;
    if (type === 'health_score_updated') {
      set(state => {
        const score = Number(data.score || 0);
        const prev  = state.scoreHistory[data.accountId] || [];
        return {
          accounts: state.accounts.map(a =>
            a.accountId === data.accountId ? { ...a, score } : a),
          scoreHistory: { ...state.scoreHistory,
            [data.accountId]: [...prev, score].slice(-12) },
        };
      });
    }
    if (type === 'health_scores_bulk') {
      const updated = data.scores || [];
      set(state => ({ accounts: state.accounts.map(a => {
        const u = updated.find(s => s.accountId === a.accountId);
        return u ? { ...a, score: Number(u.score || 0) } : a;
      })}));
    }
    if (type === 'anomaly_detected') {
      set(state => ({ anomalies: [data, ...state.anomalies].slice(0, 50) }));
    }
    if (type === 'incident_created' || type === 'incident_summary_ready') {
      api.getAllIncidents().then(r => set({ incidents: r.incidents || [] })).catch(() => {});
    }
  },

  init: () => {
    get().fetchAll();
    const interval = setInterval(() => get().fetchAll(), 30_000);
    connectWebSocket();
    const unsub = subscribeToEvents(event => get().mergeEvent(event));
    return () => { clearInterval(interval); unsub(); };
  },
}));
