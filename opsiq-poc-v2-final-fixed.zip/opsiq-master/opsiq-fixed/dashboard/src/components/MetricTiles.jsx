import { useStore } from '../store.js';
function Sparkline({ points, color }) {
  const w=80,h=24,max=Math.max(...points,1),min=Math.min(...points,0),range=max-min||1;
  const coords=points.map((v,i)=>(`${(i/(points.length-1))*w},${h-((v-min)/range)*(h-4)-2}`)).join(' ');
  const uid=`sg${color.replace('#','')}`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} width={w} height={h} style={{marginTop:8}}>
      <defs><linearGradient id={uid} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor={color} stopOpacity=".3"/>
        <stop offset="100%" stopColor={color} stopOpacity="0"/>
      </linearGradient></defs>
      <polygon points={`0,${h} ${coords} ${w},${h}`} fill={`url(#${uid})`}/>
      <polyline points={coords} fill="none" stroke={color} strokeWidth="1.8"/>
    </svg>
  );
}
export default function MetricTiles() {
  const accounts  = useStore(s => s.accounts);
  const incidents = useStore(s => s.incidents);
  const anomalies = useStore(s => s.anomalies);
  const openInc   = incidents.filter(i => i.status==='OPEN').length;
  const avgScore  = accounts.length ? Math.round(accounts.reduce((s,a)=>s+Number(a.score||0),0)/accounts.length) : 0;
  const region    = import.meta.env.VITE_API_URL?.match(/execute-api\.([\w-]+)\.amazonaws/)?.[1]||'us-west-2';
  const tiles = [
    {label:'Accounts Monitored', value:accounts.length, sub:`AWS ${region}`, color:'var(--blue)', spark:[accounts.length,accounts.length,accounts.length,accounts.length,accounts.length,accounts.length,accounts.length], sc:'#0972D3'},
    {label:'Active Incidents', value:openInc, sub:openInc>0?`${openInc} open`:'All clear', color:openInc>0?'var(--red)':'var(--green)', spark:[0,0,1,1,2,Math.max(openInc-2,0),openInc], sc:openInc>0?'#D13212':'#067940'},
    {label:'Anomalies (30 min)', value:anomalies.length, sub:anomalies.length>5?`↑ ${anomalies.length-3} above baseline`:'Within normal range', color:anomalies.length>5?'var(--amber)':'var(--text)', spark:[2,3,4,5,8,12,anomalies.length], sc:'#946600'},
    {label:'Avg Health Score', value:avgScore, sub:avgScore<60?'Critical — action needed':avgScore<80?'Degraded':'All systems nominal', color:avgScore>=80?'var(--green)':avgScore>=60?'var(--amber)':'var(--red)', spark:[100,95,88,80,72,65,avgScore], sc:avgScore>=80?'#067940':avgScore>=60?'#946600':'#D13212'},
  ];
  return (
    <div className="metric-grid">
      {tiles.map(t=>(
        <div className="metric-tile" key={t.label}>
          <div className="mt-label">{t.label}</div>
          <div className="mt-value" style={{color:t.color}}>{t.value}</div>
          <div className="mt-sub">{t.sub}</div>
          <Sparkline points={t.spark} color={t.sc}/>
        </div>
      ))}
    </div>
  );
}
