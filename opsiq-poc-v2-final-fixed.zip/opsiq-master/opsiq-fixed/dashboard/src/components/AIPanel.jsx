import { useStore } from '../store.js';
function CodeChip({children}){return <code style={{fontFamily:'monospace',fontSize:11,background:'rgba(107,63,160,0.1)',padding:'1px 5px',borderRadius:3,color:'var(--purple)',border:'1px solid rgba(107,63,160,0.2)'}}>{children}</code>;}
function renderStep(step){return step.split(/(`[^`]+`)/).map((p,j)=>p.startsWith('`')&&p.endsWith('`')?<CodeChip key={j}>{p.slice(1,-1)}</CodeChip>:p);}
export default function AIPanel() {
  const incidents=useStore(s=>s.incidents);
  const selectedAccountId=useStore(s=>s.selectedAccountId);
  const accInc=incidents.filter(i=>i.accountId===selectedAccountId&&i.status==='OPEN');
  const incident=accInc.find(i=>i.aiSummary&&i.severity==='HIGH')||accInc.find(i=>i.aiSummary)||accInc[0];
  const summary=incident?.aiSummary;
  if(!incident) return (
    <div className="panel fade-in"><div className="panel-hdr"><div className="panel-title">Incident Analysis</div></div>
    <div className="panel-body empty-state">No open incidents for the selected account.</div></div>
  );
  if(!summary) return (
    <div className="ai-panel fade-in" style={{marginBottom:16}}>
      <div className="ai-panel-hdr">
        <svg className="ai-panel-hdr-icon" viewBox="0 0 24 24"><path d="M12 2a10 10 0 110 20A10 10 0 0112 2zm0 5a1 1 0 00-1 1v4a1 1 0 002 0V8a1 1 0 00-1-1zm0 8a1 1 0 100 2 1 1 0 000-2z"/></svg>
        <span className="ai-panel-title">Incident Analysis</span>
        <span className="ai-panel-sub">Claude Sonnet · {incident.signalCount} signals</span>
      </div>
      <div className="ai-panel-body">
        <div style={{background:'rgba(148,102,0,0.08)',border:'1px solid rgba(148,102,0,0.25)',borderRadius:6,padding:'12px 14px',marginBottom:12,fontSize:13}}>
          <div style={{fontWeight:700,color:'var(--amber)',marginBottom:4}}>⚠ Bedrock model access not yet enabled</div>
          <div style={{color:'var(--text-2)',fontSize:12.5}}>Enable Claude Sonnet in AWS Console → Amazon Bedrock → Model Access, then re-trigger the incident to generate an AI summary.</div>
        </div>
        <div className="ai-headline" style={{color:'var(--text-2)',fontWeight:500}}>{incident.incidentType?.replace(/_/g,' ').replace(/\b\w/g,c=>c.toUpperCase())} detected in {incident.accountId}</div>
        <div style={{fontSize:12,color:'var(--text-3)',marginTop:8}}>{incident.signalCount} correlated signal{incident.signalCount!==1?'s':''} · Severity: <strong style={{color:'var(--red)'}}>{incident.severity}</strong></div>
        <div className="ai-footer" style={{marginTop:12,color:'var(--text-3)'}}>AI analysis will appear here once Bedrock is enabled</div>
      </div>
    </div>
  );
  return (
    <div className="ai-panel fade-in" style={{marginBottom:16}}>
      <div className="ai-panel-hdr">
        <svg className="ai-panel-hdr-icon" viewBox="0 0 24 24"><path d="M12 2a10 10 0 110 20A10 10 0 0112 2zm0 5a1 1 0 00-1 1v4a1 1 0 002 0V8a1 1 0 00-1-1zm0 8a1 1 0 100 2 1 1 0 000-2z"/></svg>
        <span className="ai-panel-title">Incident Analysis</span>
        <span className="ai-panel-sub">Claude Sonnet · {incident.signalCount} signals</span>
      </div>
      <div className="ai-panel-body">
        <div className="ai-headline">{summary.headline}</div>
        {summary.investigationSteps?.length>0&&(
          <ol className="ai-steps">{summary.investigationSteps.slice(0,4).map((s,i)=>(
            <li key={i}><span className="ai-step-num">{i+1}</span><span>{renderStep(s)}</span></li>
          ))}</ol>
        )}
        {summary.probableCauses?.length>0&&(
          <div style={{marginTop:10,padding:'8px 12px',background:'rgba(107,63,160,0.06)',borderRadius:4,fontSize:12.5}}>
            <div style={{fontWeight:600,color:'var(--purple)',marginBottom:4}}>Probable Cause</div>
            <div style={{color:'var(--text-2)'}}>{summary.probableCauses[0]}</div>
          </div>
        )}
        <div className="ai-footer">
          <span style={{color:summary.confidence==='HIGH'?'var(--green)':'var(--amber)'}}>● {summary.confidence} confidence</span>
          {summary.runbookReference?.section&&<span> · Runbook: {summary.runbookReference.section}</span>}
          {summary.estimatedResolutionTime&&<span> · Est. resolution: {summary.estimatedResolutionTime}</span>}
        </div>
      </div>
    </div>
  );
}
