import { useState, useEffect } from 'react';
import { useStore } from '../store.js';
function clock() {
  return new Date().toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit',second:'2-digit',timeZone:'UTC'})+' UTC';
}
export default function TopNav() {
  const [time, setTime]  = useState(clock());
  const currentView      = useStore(s => s.currentView);
  const setView          = useStore(s => s.setView);
  const fetchAll         = useStore(s => s.fetchAll);
  const triggerDemo      = useStore(s => s.triggerDemo);
  const demoStatus       = useStore(s => s.demoStatus);
  const accounts         = useStore(s => s.accounts);
  const region = import.meta.env.VITE_API_URL?.match(/execute-api\.([\w-]+)\.amazonaws/)?.[1] || 'us-west-2';
  useEffect(() => { const t = setInterval(() => setTime(clock()), 1000); return () => clearInterval(t); }, []);
  const TABS = [
    {id:'Dashboard',label:'Dashboard'},
    {id:'Accounts', label:'Accounts', dropdown:true},
    {id:'Incidents',label:'Incidents',dropdown:true},
    {id:'Runbooks', label:'Runbooks'},
  ];
  return (
    <nav className="top-nav">
      <div className="nav-brand" onClick={() => setView('Dashboard')}>
        <svg width="28" height="28" viewBox="0 0 28 28">
          <path d="M7 17 Q14 21 21 17" stroke="#FF9900" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
          <path d="M4 10 L14 6 L24 10" stroke="var(--logo-mark)" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M4 10 L14 14 L24 10" stroke="var(--logo-mark)" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" opacity=".55"/>
        </svg>
        <span className="nav-product">Ops<span style={{color:'#FF9900'}}>IQ</span></span>
      </div>
      {TABS.map(tab => (
        <div key={tab.id} className={`nav-item${currentView===tab.id?' active':''}`} onClick={() => setView(tab.id)}>
          {tab.label}
          {tab.dropdown && <svg viewBox="0 0 12 8" width="10" height="10" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M1 1l5 5 5-5"/></svg>}
        </div>
      ))}
      <div className="nav-sp"/>
      <span className="nav-clock">{time}</span>
      <div className="nav-region">
        <span className="nav-region-dot"/>
        {region}
        <svg viewBox="0 0 12 8" width="10" height="10" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M1 1l5 5 5-5"/></svg>
      </div>
      <div className="nav-right">
        <button className="nav-r-btn" onClick={fetchAll}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="14" height="14"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/></svg>
          Refresh
        </button>
        <button className="nav-r-btn">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="14" height="14"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0"/></svg>
          Alerts
        </button>
        <button className="nav-r-btn">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="14" height="14"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
          Irshad M.
        </button>
      </div>
      <button className="btn btn-primary nav-demo-btn" disabled={demoStatus==='injecting'}
        onClick={() => triggerDemo('ecs-oom', accounts[0]?.accountId||'sim-app-a')}>
        {demoStatus==='injecting' ? '⟳ Injecting…' : demoStatus==='injected' ? '✓ Injected!' : '▶ Run Demo Scenario'}
      </button>
    </nav>
  );
}
