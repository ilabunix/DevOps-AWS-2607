import { useStore } from '../store.js';
function timeAgo(tsMs){if(!tsMs)return '';const d=Date.now()-Number(tsMs),m=Math.floor(d/60000);if(m<1)return 'just now';if(m<60)return `${m} min ago`;return `${Math.floor(m/60)}h ago`;}
function dotClass(sev){if(sev==='HIGH')return 'sd-red';if(sev==='MEDIUM')return 'sd-amber';return 'sd-blue';}
function anomalyTitle(a){
  const t=a.anomalyType||'';
  const sig=a.signature||a.description||a.message||'';
  const src=a.logGroup||a.resource||a.source?.replace('opsiq.','');

  if(t==='novel_log_pattern'){
    if(sig&&sig.toLowerCase()!=='unknown'){
      const clean=sig.replace(/\s+/g,' ').slice(0,90);
      return `Novel pattern: ${clean}${sig.length>90?'…':''}`;
    }
    return `Novel log pattern — ${src||'unknown source'}`;
  }
  if(t==='alb_5xx')return `ALB 5xx spike — ${a.value??a.currentCount??''}% error rate`;
  if(t==='ecs_high_memory')return `ECS memory critical — ${a.value??a.currentCount??''}% utilisation`;
  if(t==='ecs_high_cpu')return `ECS CPU elevated — ${a.value??a.currentCount??''}%`;
  if(t==='rds_connection_exhaustion')return `RDS connections — ${a.value??''}/100 (exhaustion imminent)`;
  if(t==='lambda_timeout')return `Lambda timeout — function took too long`;
  if(t==='log_volume_spike')return `Error volume spike — ${a.currentCount??''} in 5min (z-score ${a.zScore??''}) · ${a.level||'ERROR'}`;
  if(t==='log_pattern_spike')return `Known pattern spike: ${sig.slice(0,60)||'error pattern'} · ${a.currentCount??''}x above baseline`;
  if(t==='log_silence')return `Log silence — ${src||'log group'} went quiet (expected ${a.baselineMean?.toFixed(1)||'?'}/window)`;
  if(t==='infrastructure_drift')return `Drift — ${a.driftType||''}: ${a.resourceName||a.name||''}`;
  if(!t&&sig)return `Signal: ${sig.slice(0,80)}`;
  if(!t&&src)return `Anomaly detected — ${src}`;
  if(t)return t.replace(/_/g,' ').replace(/\b\w/g,c=>c.toUpperCase());
  return 'Anomaly detected';
}
function anomalyDetail(a){const p=[];if(a.resource)p.push(a.resource);if(a.logGroup&&!a.resource)p.push(a.logGroup);if(a.description&&!a.resource&&!a.logGroup)p.push(a.description);if(a.accountId)p.push(a.accountId);return p.join(' · ')||'—';}
function Sparkline({anomalies,accountId,color}){
  const now=Date.now(),wMs=30*60*1000,bMs=wMs/7,counts=Array(7).fill(0);
  anomalies.filter(a=>(!accountId||a.accountId===accountId)).forEach(a=>{const age=now-Number(a.timestamp||0);if(age<wMs){const idx=Math.min(6,Math.floor(age/bMs));counts[6-idx]++;}});
  const max=Math.max(...counts,1),w=120,h=24;
  const pts=counts.map((v,i)=>`${(i/6)*w},${h-(v/max)*(h-4)-2}`).join(' ');
  const uid=`sp${accountId||'x'}`.replace(/[^a-z0-9]/gi,'');
  return (
    <svg viewBox={`0 0 ${w} ${h}`} width={w} height={h}>
      <defs><linearGradient id={uid} x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={color} stopOpacity=".3"/><stop offset="100%" stopColor={color} stopOpacity="0"/></linearGradient></defs>
      <polygon points={`0,${h} ${pts} ${w},${h}`} fill={`url(#${uid})`}/>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.6"/>
    </svg>
  );
}
export function SignalFeed() {
  const anomalies=useStore(s=>s.anomalies);
  const accounts=useStore(s=>s.accounts);
  const accountRows=accounts.map(acc=>{const a=anomalies.filter(x=>x.accountId===acc.accountId);return{...acc,count:a.length,high:a.filter(x=>x.severity==='HIGH').length,novel:a.filter(x=>x.anomalyType==='novel_log_pattern').length};}).sort((a,b)=>b.count-a.count);
  const recent=anomalies.slice(0,8);
  return (
    <div className="panel fade-in">
      <div className="panel-hdr">
        <div><div className="panel-title">Signal Feed</div><div className="panel-sub">{anomalies.length} signals · {anomalies.filter(a=>a.severity==='HIGH').length} HIGH · {anomalies.filter(a=>a.anomalyType==='novel_log_pattern').length} novel patterns</div></div>
        <a className="panel-link">View all →</a>
      </div>
      <div className="panel-body" style={{paddingTop:8,paddingBottom:8}}>
        {accountRows.map(acc=>(
          <div key={acc.accountId} className="spark-row" style={{alignItems:'center'}}>
            <div className="spark-label" style={{fontWeight:600}}>{acc.accountId}</div>
            <Sparkline anomalies={anomalies} accountId={acc.accountId} color={acc.high>0?'#D13212':acc.count>2?'#946600':'#067940'}/>
            <div style={{display:'flex',flexDirection:'column',alignItems:'flex-end',gap:2,minWidth:80}}>
              <span style={{fontFamily:'monospace',fontSize:12,fontWeight:700,color:acc.high>0?'var(--red)':acc.count>2?'var(--amber)':'var(--green)'}}>{acc.count} signals</span>
              {acc.high>0&&<span style={{fontSize:10.5,color:'var(--red)'}}>{acc.high} HIGH</span>}
              {acc.novel>0&&<span style={{fontSize:10.5,color:'var(--purple)'}}>{acc.novel} novel</span>}
            </div>
          </div>
        ))}
        <div style={{borderTop:'1px solid var(--border-light)',margin:'10px 0'}}/>
        {recent.map((a,i)=>(
          <div className="signal-item" key={i}>
            <div className={`signal-dot ${dotClass(a.severity)}`}/>
            <div className="signal-body">
              <div className="signal-title">{anomalyTitle(a)}</div>
              <div className="signal-detail">{anomalyDetail(a)}</div>
              {a.anomalyType==='novel_log_pattern'&&<div className="signal-meta" style={{color:'var(--purple)',fontStyle:'italic'}}>Bloom filter — pattern never seen before</div>}
              {a.anomalyType==='log_volume_spike'&&<div className="signal-meta">Baseline: {a.baselineMean?.toFixed(1)||0}±{a.baselineStddev?.toFixed(1)||0} · z-score: {a.zScore}</div>}
            </div>
            <div className="signal-time">{timeAgo(a.timestamp)}</div>
          </div>
        ))}
        {anomalies.length===0&&<div className="empty-state" style={{padding:'20px 0'}}>No anomalies in the last 30 minutes. System appears healthy.</div>}
      </div>
    </div>
  );
}
export function IncidentTable() {
  const incidents=useStore(s=>s.incidents);
  const setView=useStore(s=>s.setView);
  const open=incidents.filter(i=>i.status==='OPEN');
  const deduped=[],seen=new Set();
  for(const inc of open){const k=`${inc.accountId}:${inc.incidentType}`;if(!seen.has(k)){seen.add(k);deduped.push(inc);}}
  const display=deduped.slice(0,8);
  function label(inc){
    if(inc.aiSummary?.headline)return inc.aiSummary.headline;
    const t=inc.incidentType||'';
    if(t==='ecs_high_memory')return `ECS memory OOM cascade in ${inc.accountId}`;
    if(t==='alb_5xx')return `ALB 5xx error spike in ${inc.accountId}`;
    if(t==='rds_connection_exhaustion')return `RDS connection exhaustion in ${inc.accountId}`;
    if(t==='lambda_timeout')return `Lambda timeout cascade in ${inc.accountId}`;
    if(t==='novel_log_pattern')return `Novel error pattern in ${inc.accountId}`;
    if(t==='log_volume_spike')return `Error volume spike in ${inc.accountId}`;
    if(t==='log_pattern_spike')return `Error pattern spike in ${inc.accountId}`;
    return t.replace(/_/g,' ').replace(/\b\w/g,c=>c.toUpperCase())+` — ${inc.accountId}`;
  }
  function ago(ts){if(!ts)return '—';const m=Math.floor((Date.now()-Number(ts))/60000);if(m<1)return 'just now';if(m<60)return `${m} min`;return `${Math.floor(m/60)}h`;}
  return (
    <div className="panel fade-in">
      <div className="panel-hdr">
        <div><div className="panel-title">Open Incidents</div><div className="panel-sub">{open.length} total · showing {display.length} unique · {open.filter(i=>i.severity==='HIGH').length} HIGH</div></div>
        <a className="panel-link" onClick={()=>setView('Incidents')}>View all</a>
      </div>
      <div style={{overflowX:'auto'}}>
        <table className="aws-table">
          <thead><tr><th>Sev</th><th>Summary</th><th>Account</th><th>Age</th></tr></thead>
          <tbody>
            {display.map(inc=>(
              <tr key={inc.incidentId} style={{cursor:'pointer'}} onClick={()=>setView('Incidents')}>
                <td><span className={`sev sev-${inc.severity?.[0]||'L'}`}>{inc.severity}</span></td>
                <td>
                  <div style={{fontWeight:500,fontSize:12.5,lineHeight:1.35}}>{label(inc)}</div>
                  <div style={{fontSize:11,color:'var(--text-3)',marginTop:2}}>{inc.signalCount} signals{inc.aiSummary?<span style={{color:'var(--purple)',marginLeft:6}}>✦ AI ready</span>:<span style={{color:'var(--text-3)',marginLeft:6}}>AI pending</span>}</div>
                </td>
                <td style={{fontSize:12.5,color:'var(--text-2)'}}>{inc.accountId}</td>
                <td style={{fontFamily:'monospace',fontSize:11.5,color:'var(--text-3)',whiteSpace:'nowrap'}}>{ago(inc.timestamp)}</td>
              </tr>
            ))}
            {display.length===0&&<tr><td colSpan={4} className="empty-state">No open incidents. All clear.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
export function DriftPanel({accountId}) {
  const drifts={'sim-app-a':[{type:'UNMANAGED',name:'temp-sg-debug',resourceType:'aws_security_group',detail:'Created manually during incident — not in Terraform state'},{type:'MISSING',name:'backup-lambda',resourceType:'aws_lambda_function',detail:'Present in tfstate but not found in account'}],'sim-app-b':[{type:'UNMANAGED',name:'test-dynamodb-table',resourceType:'aws_dynamodb_table',detail:'Created by developer for testing, never added to tfstate'}],'sim-app-c':[{type:'MISSING',name:'redis-replica',resourceType:'aws_elasticache_cluster',detail:'Removed from config but cluster not deleted from account'}]}[accountId]||[];
  return (
    <div className="panel fade-in">
      <div className="panel-hdr">
        <div><div className="panel-title">Drift Detection</div><div className="panel-sub">{accountId||'—'} · Checked 6h ago</div></div>
        {drifts.length>0?<span className="badge badge-amber">{drifts.length} drifts</span>:<span className="badge badge-green">No drift</span>}
      </div>
      <div className="panel-body" style={{paddingTop:4,paddingBottom:4}}>
        {drifts.map((d,i)=>(
          <div className="drift-row" key={i}>
            <span className={`drift-tag ${d.type==='UNMANAGED'?'dt-unmanaged':'dt-missing'}`}>{d.type}</span>
            <div><div className="drift-name">{d.name} <span className="drift-chip">{d.resourceType}</span></div><div className="drift-detail">{d.detail}</div></div>
          </div>
        ))}
        {drifts.length===0&&<div className="empty-state" style={{padding:'16px 0'}}>No infrastructure drift detected.</div>}
      </div>
    </div>
  );
}
export function AlertBanner() {
  const accounts=useStore(s=>s.accounts);
  const critical=accounts.filter(a=>Number(a.score||0)<60);
  if(critical.length===0)return null;
  return (
    <div className="alert alert-amber">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
      <div>
        <div className="alert-title">{critical.length} account{critical.length>1?'s':''} in critical state</div>
        <div className="alert-body">{critical.map(a=>a.accountId).join(', ')} — health score below 60. Infrastructure drift also detected. <a className="alert-link" href="#">Review now →</a></div>
      </div>
    </div>
  );
}
