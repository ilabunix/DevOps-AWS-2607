/**
 * PredictiveHealth.jsx — Phase 3
 *
 * ZERO Bedrock calls. Pure client-side math.
 * Reads last N health score readings from the WebSocket event history
 * held in Zustand store, calculates linear trend, shows:
 *   - Trend arrow on account cards (↑ ↓ →)
 *   - "Trending critical in ~Xm" badge when slope is negative
 *
 * This component is used INSIDE the existing account card.
 * It does not replace any existing component.
 */

// ── Linear regression on last N scores ────────────────────────────────────
// Returns { slope, projected15m, label, color, arrow }
export function calcTrend(scoreHistory) {
  if (!scoreHistory || scoreHistory.length < 3) {
    return { slope: 0, projected: null, label: 'Stable', color: 'var(--text-4)', arrow: '→' };
  }

  const n = scoreHistory.length;
  const xs = scoreHistory.map((_, i) => i);
  const ys = scoreHistory.map(s => Number(s));

  // Least squares linear regression
  const sumX  = xs.reduce((a, b) => a + b, 0);
  const sumY  = ys.reduce((a, b) => a + b, 0);
  const sumXY = xs.reduce((a, x, i) => a + x * ys[i], 0);
  const sumX2 = xs.reduce((a, x) => a + x * x, 0);
  const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);

  // Each reading is ~5 min apart (health-schedule), 15 min = ~3 steps
  const current   = ys[n - 1];
  const projected = Math.max(0, Math.min(100, current + slope * 3));

  // Time to critical (score < 60) if negative trend
  let label = 'Stable';
  let color = 'var(--text-4)';
  let arrow = '→';

  if (slope > 1.5) {
    label = 'Improving';
    color = 'var(--green)';
    arrow = '↑';
  } else if (slope < -1.5) {
    arrow = '↓';
    if (current > 60 && projected < 60) {
      // Estimate minutes to critical: (current - 60) / -slope * 5 min per step
      const stepsToC = Math.max(1, (current - 60) / Math.abs(slope));
      const minsToC  = Math.round(stepsToC * 5);
      label = `Critical in ~${minsToC}m`;
      color = 'var(--red)';
    } else if (projected < current - 5) {
      label = 'Degrading';
      color = 'var(--amber)';
    } else {
      label = 'Declining';
      color = 'var(--amber)';
    }
  }

  return { slope, projected: Math.round(projected), label, color, arrow };
}

// ── Trend badge component ─────────────────────────────────────────────────
export function TrendBadge({ trend }) {
  if (!trend || trend.slope === 0) return null;
  if (Math.abs(trend.slope) < 1) return null; // Not significant enough to show

  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      padding: '2px 7px', borderRadius: 3,
      background: `${trend.color}15`,
      border: `1px solid ${trend.color}40`,
      fontSize: 10, fontWeight: 700,
      color: trend.color,
      fontFamily: 'var(--font-mono)',
    }}>
      <span style={{ fontSize: 11 }}>{trend.arrow}</span>
      {trend.label}
    </div>
  );
}

// ── Mini trend line (SVG sparkline) ───────────────────────────────────────
export function TrendLine({ scoreHistory, width = 80, height = 24 }) {
  if (!scoreHistory || scoreHistory.length < 2) return null;

  const pts = scoreHistory.map(s => Number(s));
  const max = Math.max(...pts, 100);
  const min = Math.min(...pts, 0);
  const range = max - min || 1;

  const xs = pts.map((_, i) => (i / (pts.length - 1)) * width);
  const ys = pts.map(v => height - ((v - min) / range) * (height - 4) - 2);
  const d  = xs.map((x, i) => `${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${ys[i].toFixed(1)}`).join(' ');

  const trend = calcTrend(pts);
  const lineColor = trend.color === 'var(--text-4)' ? 'var(--border-3)' : trend.color;

  return (
    <svg width={width} height={height} style={{ overflow: 'visible', display: 'block' }}>
      <path d={d} fill="none" stroke={lineColor} strokeWidth="1.5"
        strokeLinecap="round" strokeLinejoin="round" opacity="0.8"/>
      <circle cx={xs[xs.length-1]} cy={ys[ys.length-1]} r="2.5" fill={lineColor}/>
    </svg>
  );
}
