import { useStore } from '../store.js';
import TopologyGraph from './TopologyGraph.jsx';
import AIPanel from './AIPanel.jsx';
import { SignalFeed, IncidentTable, DriftPanel, AlertBanner } from './SignalFeed.jsx';
import { calcTrend, TrendBadge, TrendLine } from './PredictiveHealth.jsx';

const STACK_MAP = {
  'sim-app-a': 'ECS · ALB · Aurora PostgreSQL',
  'sim-app-b': 'Lambda · APIGW · DynamoDB',
  'sim-app-c': 'ECS · ALB · ElastiCache Redis',
};

function statusClass(score) {
  if (score >= 80) return 'healthy';
  if (score >= 60) return 'warning';
  return 'critical';
}

function Sparkline({ points, color, w = 80, h = 20 }) {
  if (!points?.length) return null;
  const max = Math.max(...points, 1), min = Math.min(...points, 0), range = max - min || 1;
  const coords = points.map((v, i) => `${(i / (points.length - 1)) * w},${h - ((v - min) / range) * (h - 4) - 2}`).join(' ');
  const uid = `sp${color.replace(/[^a-z0-9]/gi, '')}${Math.random().toString(36).slice(2, 6)}`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} width={w} height={h}>
      <defs>
        <linearGradient id={uid} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity=".25" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polygon points={`0,${h} ${coords} ${w},${h}`} fill={`url(#${uid})`} />
      <polyline points={coords} fill="none" stroke={color} strokeWidth="1.5" />
    </svg>
  );
}

function AccountCards() {
  const accounts      = useStore(s => s.accounts);
  const scoreHistory   = useStore(s => s.scoreHistory);
  const incidents = useStore(s => s.incidents);
  const anomalies = useStore(s => s.anomalies);
  const selectedAccountId = useStore(s => s.selectedAccountId);
  const setSelectedAccount = useStore(s => s.setSelectedAccount);
  const setView = useStore(s => s.setView);
  const loading = useStore(s => s.loading.accounts);

  if (loading) return (
    <div className="account-cards-grid">
      {[1,2,3].map(i => (
        <div key={i} className="panel" style={{ height: 160, opacity: 0.4 }}>
          <div className="loading-row"><span className="spinner" /></div>
        </div>
      ))}
    </div>
  );

  if (!accounts.length) return null;

  return (
    <div className="account-cards-grid">
      {accounts.sort((a, b) => Number(a.score || 0) - Number(b.score || 0)).map(acc => {
        const score = Number(acc.score || 0);
        const sc = statusClass(score);
        const accInc = incidents.filter(i => i.accountId === acc.accountId && i.status === 'OPEN').length;
        const accAnom = anomalies.filter(a => a.accountId === acc.accountId).length;
        const isSelected = acc.accountId === selectedAccountId;
        const barColor = sc === 'healthy' ? 'var(--green)' : sc === 'warning' ? 'var(--amber)' : 'var(--red)';
        const history = scoreHistory[acc.accountId] || [];
        const trend   = calcTrend(history);

        return (
          <div
            key={acc.accountId}
            className={`account-card status-${sc}${isSelected ? ' selected' : ''} fade-in`}
            onClick={() => setSelectedAccount(acc.accountId)}
          >
            <div className="ac-header">
              <div>
                <div className="ac-name">{acc.accountId}</div>
                <div className="ac-arn">arn:aws::{acc.accountId}</div>
              </div>
              <span className={`ac-status-pill ${sc}`}>
                {sc === 'healthy' ? '● Healthy' : sc === 'warning' ? '● Warning' : '● Critical'}
              </span>
            </div>

            <div className="ac-score-row">
              <div className={`ac-score ${sc}`}>{score}</div>
              <div style={{flex:1}}>
                <div className="ac-score-label">/ 100<br/>health</div>
                {history.length >= 3 && <TrendLine scoreHistory={history} width={55} height={18}/>}
              </div>
              {history.length >= 3 && <TrendBadge trend={trend}/>}
            </div>

            <div className="ac-bar-bg">
              <div className="ac-bar-fill" style={{ width: `${score}%`, background: barColor }} />
            </div>

            <div className="ac-stats">
              <div>
                <div className="ac-stat-label">Incidents</div>
                <div className={`ac-stat-value ${accInc > 0 ? 'danger has-value' : ''}`}>{accInc}</div>
              </div>
              <div>
                <div className="ac-stat-label">Anomalies</div>
                <div className={`ac-stat-value ${accAnom > 5 ? 'warn has-value' : accAnom > 0 ? 'has-value' : ''}`}>{accAnom}</div>
              </div>
              <div>
                <div className="ac-stat-label">Stack</div>
                <div style={{ fontSize: 10, color: 'var(--text-3)', marginTop: 3, lineHeight: 1.4 }}>
                  {STACK_MAP[acc.accountId]?.split(' · ').join('\n') || 'AWS'}
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 10 }}>
              <button
                className="btn-link"
                style={{ fontSize: 11 }}
                onClick={e => { e.stopPropagation(); setSelectedAccount(acc.accountId); setView('Topology'); }}
              >
                View topology →
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function KpiStrip() {
  const accounts      = useStore(s => s.accounts);
  const scoreHistory   = useStore(s => s.scoreHistory);
  const incidents = useStore(s => s.incidents);
  const anomalies = useStore(s => s.anomalies);
  const openInc = incidents.filter(i => i.status === 'OPEN').length;
  const avgScore = accounts.length
    ? Math.round(accounts.reduce((s, a) => s + Number(a.score || 0), 0) / accounts.length)
    : 0;
  const sc = !accounts.length ? 'var(--text-2)' : avgScore >= 80 ? 'var(--green)' : avgScore >= 60 ? 'var(--amber)' : 'var(--red)';

  const tiles = [
    { label: 'Accounts Monitored', value: accounts.length, sub: accounts.length ? 'AWS us-west-2' : 'No accounts connected', color: 'var(--blue)', spark: [accounts.length,accounts.length,accounts.length,accounts.length,accounts.length,accounts.length,accounts.length], sc: '#7AA2FF' },
    { label: 'Active Incidents', value: openInc, sub: openInc > 0 ? `${openInc} open · action needed` : 'All clear', color: openInc > 0 ? 'var(--red)' : 'var(--green)', spark: [0,0,1,2,3,Math.max(openInc-2,0),openInc], sc: openInc > 0 ? '#E06C75' : '#6FCF97' },
    { label: 'Anomalies (30 min)', value: anomalies.length, sub: anomalies.length > 5 ? `↑ ${anomalies.length - 3} above baseline` : 'Within normal range', color: anomalies.length > 5 ? 'var(--amber)' : 'var(--text-2)', spark: [2,3,5,8,12,18,anomalies.length], sc: '#DDBA63' },
    { label: 'Avg Health Score', value: accounts.length ? avgScore : '—', sub: accounts.length ? (avgScore < 60 ? 'Critical — action needed' : avgScore < 80 ? 'Degraded' : 'All systems nominal') : 'No health data', color: sc, spark: accounts.length ? [100,95,85,75,65,55,avgScore] : [0,0,0,0,0,0,0], sc: accounts.length ? (avgScore >= 80 ? '#6FCF97' : avgScore >= 60 ? '#DDBA63' : '#E06C75') : '#566176' },
  ];

  return (
    <div className="kpi-strip">
      {tiles.map(t => (
        <div className="kpi-tile" key={t.label}>
          <div className="kpi-label">{t.label}</div>
          <div className="kpi-value" style={{ color: t.color }}>{t.value}</div>
          <div className="kpi-sub">{t.sub}</div>
          <div className="kpi-spark">
            <Sparkline points={t.spark} color={t.sc} w={100} h={22} />
          </div>
        </div>
      ))}
    </div>
  );
}

function CommandOverview() {
  const accounts      = useStore(s => s.accounts);
  const scoreHistory   = useStore(s => s.scoreHistory);
  const incidents = useStore(s => s.incidents);
  const anomalies = useStore(s => s.anomalies);
  const openInc = incidents.filter(i => i.status === 'OPEN');
  const highInc = openInc.filter(i => i.severity === 'HIGH').length;
  const criticalAccounts = accounts.filter(a => Number(a.score || 0) < 60).length;
  const posture = highInc || criticalAccounts ? 'Action required' : accounts.length ? 'Guarded normal' : 'Awaiting telemetry';
  const recommendation = openInc[0]
    ? 'Prioritize the highest severity incident, confirm customer impact, then execute the linked runbook.'
    : accounts.length
      ? 'No active incidents. Continue monitoring anomaly velocity and drift for early warning signals.'
      : 'Run the demo scenario or connect AWS telemetry to activate AI incident analysis.';
  const evidence = anomalies.length
    ? `${anomalies.length} correlated signal${anomalies.length === 1 ? '' : 's'} available`
    : 'No correlated signals yet';

  return (
    <div className="command-overview fade-in">
      <div className="command-primary">
        <span className="eyebrow">AI SRE command center</span>
        <h1>{posture}</h1>
        <p>{recommendation}</p>
      </div>
      <div className="ai-summary-grid">
        <div className="ai-summary-card">
          <span>Recommended action</span>
          <strong>{openInc.length ? 'Triage incident queue' : accounts.length ? 'Maintain watch' : 'Connect telemetry'}</strong>
        </div>
        <div className="ai-summary-card">
          <span>Evidence status</span>
          <strong>{evidence}</strong>
        </div>
        <div className="ai-summary-card">
          <span>Analysis state</span>
          <strong>{accounts.length || anomalies.length || incidents.length ? 'Ready' : 'Waiting for data'}</strong>
        </div>
      </div>
    </div>
  );
}

function AICommander() {
  const accounts      = useStore(s => s.accounts);
  const scoreHistory   = useStore(s => s.scoreHistory);
  const incidents = useStore(s => s.incidents);
  const anomalies = useStore(s => s.anomalies);
  const selectedAccountId = useStore(s => s.selectedAccountId);
  const account = accounts.find(a => a.accountId === selectedAccountId) || accounts[0];
  const open = incidents.filter(i => i.status === 'OPEN');
  const priority = open.find(i => i.severity === 'HIGH') || open[0];
  const signalCount = account ? anomalies.filter(a => a.accountId === account.accountId).length : anomalies.length;

  const recommendation = priority
    ? priority.aiSummary?.headline || `${priority.incidentType || 'Incident'} requires triage in ${priority.accountId}.`
    : account
      ? `No active incident for ${account.accountId}. Continue watching error budget and drift signals.`
      : 'Connect telemetry or run the demo to generate a full AI investigation path.';

  return (
    <div className="commander-panel fade-in">
      <div className="commander-header">
        <span className="panel-title">AI Incident Commander</span>
        <strong>{priority ? 'Triage active' : 'Standing by'}</strong>
      </div>
      <div className="commander-reco">{recommendation}</div>
      <div className="commander-facts">
        <div><span>Scope</span><strong>{priority?.accountId || account?.accountId || 'No account'}</strong></div>
        <div><span>Blast radius</span><strong>{priority ? 'Service-level' : 'None detected'}</strong></div>
        <div><span>Evidence</span><strong>{signalCount} signals</strong></div>
        <div><span>Next action</span><strong>{priority ? 'Open runbook' : 'Run demo'}</strong></div>
      </div>
    </div>
  );
}

function DashboardScopeControls() {
  const accounts      = useStore(s => s.accounts);
  const scoreHistory   = useStore(s => s.scoreHistory);
  const selectedAccountId = useStore(s => s.selectedAccountId);
  const setSelectedAccount = useStore(s => s.setSelectedAccount);

  return (
    <div className="dashboard-scope-controls">
      <label className="toolbar-select">
        <span>Account</span>
        <select
          value={selectedAccountId || 'all'}
          onChange={e => setSelectedAccount(e.target.value === 'all' ? null : e.target.value)}
        >
          <option value="all">All accounts</option>
          {accounts.map(a => <option key={a.accountId} value={a.accountId}>{a.accountId}</option>)}
        </select>
      </label>
      <label className="toolbar-select compact">
        <span>Time</span>
        <select defaultValue="30m">
          <option value="15m">Last 15m</option>
          <option value="30m">Last 30m</option>
          <option value="1h">Last 1h</option>
          <option value="6h">Last 6h</option>
          <option value="24h">Last 24h</option>
        </select>
      </label>
    </div>
  );
}

function ReliabilityMatrix() {
  const accounts      = useStore(s => s.accounts);
  const scoreHistory   = useStore(s => s.scoreHistory);
  const incidents = useStore(s => s.incidents);
  const anomalies = useStore(s => s.anomalies);
  const setSelectedAccount = useStore(s => s.setSelectedAccount);
  const setView = useStore(s => s.setView);

  const rows = accounts.map(acc => {
    const score = Number(acc.score || 0);
    const open = incidents.filter(i => i.accountId === acc.accountId && i.status === 'OPEN').length;
    const signals = anomalies.filter(a => a.accountId === acc.accountId).length;
    return {
      ...acc,
      score,
      open,
      signals,
      state: score < 60 || open ? 'Degraded' : score < 80 || signals > 4 ? 'Watch' : 'Normal',
      stack: STACK_MAP[acc.accountId] || 'AWS workload',
    };
  }).sort((a, b) => a.score - b.score);

  return (
    <div className="panel enterprise-panel fade-in">
      <div className="panel-hdr">
        <div>
          <div className="panel-title">Reliability Matrix</div>
          <div className="panel-sub">Service posture ranked by health, incidents, and correlated signals</div>
        </div>
        <a className="panel-link" onClick={() => setView('Accounts')}>Accounts view</a>
      </div>
      <div className="matrix-wrap">
        <table className="reliability-table">
          <thead>
            <tr><th>Service</th><th>State</th><th>Health</th><th>Open</th><th>Signals</th><th>Stack</th></tr>
          </thead>
          <tbody>
            {rows.map(row => (
              <tr key={row.accountId} onClick={() => setSelectedAccount(row.accountId)}>
                <td><strong>{row.accountId}</strong><span>arn:aws::{row.accountId}</span></td>
                <td><span className={`state-pill state-${row.state.toLowerCase()}`}>{row.state}</span></td>
                <td>
                  <div className="matrix-score">
                    <span>{row.score}</span>
                    <div><i style={{ width: `${row.score}%` }} /></div>
                  </div>
                </td>
                <td>{row.open}</td>
                <td>{row.signals}</td>
                <td>{row.stack}</td>
              </tr>
            ))}
            {!rows.length && (
              <tr><td colSpan={6} className="matrix-empty">No service telemetry available. Run the demo scenario to populate this view.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function LiveIncidents() {
  const incidents = useStore(s => s.incidents);
  const setView = useStore(s => s.setView);
  const open = incidents.filter(i => i.status === 'OPEN');

  const deduped = [];
  const seen = new Set();
  for (const inc of open) {
    const k = `${inc.accountId}:${inc.incidentType}`;
    if (!seen.has(k)) { seen.add(k); deduped.push(inc); }
  }

  function label(inc) {
    if (inc.aiSummary?.headline) return inc.aiSummary.headline;
    const t = inc.incidentType || '';
    const m = {
      'ecs_high_memory': 'ECS OutOfMemory cascade',
      'alb_5xx': 'ALB 5xx error spike',
      'rds_connection_exhaustion': 'RDS connection exhaustion',
      'lambda_timeout': 'Lambda execution timeout',
      'novel_log_pattern': 'Novel error pattern detected',
      'log_volume_spike': 'Error log volume spike',
      'log_pattern_spike': 'Known pattern rate spike',
    };
    return (m[t] || t.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())) + ' — ' + inc.accountId;
  }

  function ago(ts) {
    if (!ts) return '—';
    const m = Math.floor((Date.now() - Number(ts)) / 60000);
    if (m < 1) return 'just now';
    if (m < 60) return `${m}m ago`;
    return `${Math.floor(m / 60)}h ago`;
  }

  return (
    <div className="panel fade-in">
      <div className="panel-hdr">
        <div>
          <div className="panel-title">Open Incidents</div>
          <div className="panel-sub">{open.length} total · {deduped.length} unique · {open.filter(i => i.severity === 'HIGH').length} HIGH</div>
        </div>
        <a className="panel-link" onClick={() => setView('Incidents')}>View all →</a>
      </div>
      <div style={{ padding: '8px 0' }}>
        {deduped.slice(0, 6).map(inc => (
          <div key={inc.incidentId}
            className={`incident-row sev-${inc.severity?.toLowerCase()?.[0] || 'l'}`}
            style={{ margin: '0 0 1px' }}
            onClick={() => setView('Incidents')}>
            <div className="ir-top">
              <span className={`sev sev-${inc.severity?.[0] || 'L'}`}>{inc.severity}</span>
              <div className="ir-title">{label(inc)}</div>
              <div className="ir-age">{ago(inc.timestamp)}</div>
            </div>
            <div className="ir-meta">
              <span className="ir-account">{inc.accountId}</span>
              <span className="ir-signals">{inc.signalCount} signals</span>
              {inc.aiSummary
                ? <span className="ir-ai-badge">✦ AI ready</span>
                : <span style={{ fontSize: 10, color: 'var(--text-4)' }}>AI pending</span>}
            </div>
          </div>
        ))}
        {deduped.length === 0 && (
          <div className="empty-state" style={{ padding: '20px 0' }}>
            <div style={{ fontSize: 24, marginBottom: 6 }}>✓</div>
            No open incidents. All clear.
          </div>
        )}
      </div>
    </div>
  );
}

export default function Dashboard() {
  const fetchAll = useStore(s => s.fetchAll);
  const accounts      = useStore(s => s.accounts);
  const scoreHistory   = useStore(s => s.scoreHistory);
  const selectedAccountId = useStore(s => s.selectedAccountId);
  const lastRefreshed = useStore(s => s.lastRefreshed);
  const region = import.meta.env.VITE_API_URL?.match(/execute-api\.([\w-]+)\.amazonaws/)?.[1] || 'us-west-2';
  const lastStr = lastRefreshed
    ? lastRefreshed.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    : 'Not synced';

  return (
    <div className="content">
      {/* Breadcrumb */}
      <div className="breadcrumb">
        <span>OpsIQ</span>
        <svg viewBox="0 0 6 10" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" width="6" height="10"><path d="M1 1l4 4-4 4"/></svg>
        Dashboard
      </div>

      {/* Page Header */}
      <div className="page-hdr">
        <div>
          <h1 className="page-title">AI SRE Dashboard</h1>
          <div className="page-desc">
            AWS Commercial · {region} · Auto-refreshes every 30s · Last updated: {lastStr}
          </div>
        </div>
        <div className="page-actions">
          <DashboardScopeControls />
          <button className="btn btn-secondary" onClick={fetchAll}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="13" height="13">
              <polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/>
            </svg>
            Refresh
          </button>
        </div>
      </div>

      {/* Alert Banner */}
      <AlertBanner />

      {/* ── ROW 1: KPI Strip ────────────────────────────── */}
      <KpiStrip />

      <CommandOverview />

      {/* ── ROW 2: Account Health Cards ─────────────────── */}
      <AccountCards />

      <ReliabilityMatrix />

      {/* ── ROW 3: Incidents + AI | Signal Feed ──────────── */}
      <div className="command-grid" style={{ marginBottom: 12, marginTop: 12 }}>
        {/* Left: Incidents + AI Panel */}
        <div className="command-main-stack">
          <LiveIncidents />
          <AIPanel />
        </div>

        {/* Right: Signal Feed */}
        <div className="command-side-stack">
          <AICommander />
          <SignalFeed />
        </div>
      </div>

      {/* ── ROW 4: Topology + Drift ──────────────────────── */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: 12 }}>
        {/* Topology */}
        <div className="panel fade-in">
          <div className="panel-hdr">
            <div>
              <div className="panel-title">Infrastructure Topology — {selectedAccountId || 'Select an account above'}</div>
              <div className="panel-sub">Scroll to zoom · Drag to pan · Click account card to switch</div>
            </div>
            <a className="panel-link" onClick={() => useStore.getState().setView('Topology')}>Full view →</a>
          </div>
          <div style={{ background: 'var(--surface-2)', padding: 8 }}>
            <TopologyGraph compact={true} />
          </div>
        </div>

        {/* Drift */}
        <DriftPanel accountId={selectedAccountId} />
      </div>
    </div>
  );
}
