/**
 * TopologyGraph.jsx — Enhanced AWS Resource Topology
 *
 * Uses D3 for layout, SVG icons per resource type, curved bezier edges,
 * horizontal tier swim lanes showing ingress → compute → data → storage flow.
 *
 * Zero Bedrock calls. Pure D3 + React.
 */
import { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { useStore } from '../store.js';

// ── Tier config ──────────────────────────────────────────────────────────
const TIERS = [
  { id: 'ingress',  label: 'Ingress',  color: '#0972D3', bg: '#0972D308' },
  { id: 'compute',  label: 'Compute',  color: '#C7522A', bg: '#C7522A08' },
  { id: 'data',     label: 'Data',     color: '#946600', bg: '#94660008' },
  { id: 'storage',  label: 'Storage',  color: '#067940', bg: '#06794008' },
  { id: 'other',    label: 'Other',    color: '#6B6B6B', bg: '#6B6B6B08' },
];
const TIER_MAP = Object.fromEntries(TIERS.map(t => [t.id, t]));

// ── AWS Resource Icons (SVG paths, 24x24 viewBox) ─────────────────────────
// Each returns a path string or array of paths for complex icons
const ICONS = {
  // Ingress
  aws_alb: {
    color: '#0972D3',
    paths: ['M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5'],
  },
  aws_apigatewayv2_api: {
    color: '#0972D3',
    paths: ['M4 6h16M4 12h16M4 18h16', 'M9 6l3-4 3 4', 'M9 18l3 4 3-4'],
  },
  aws_cloudfront_distribution: {
    color: '#0972D3',
    paths: ['M12 2a10 10 0 100 20A10 10 0 0012 2z', 'M12 2a14.5 14.5 0 010 20M12 2a14.5 14.5 0 000 20', 'M2 12h20'],
  },
  aws_wafv2_web_acl: {
    color: '#0972D3',
    paths: ['M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z'],
  },
  aws_acm_certificate: {
    color: '#0972D3',
    paths: ['M12 2l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1 3-6z'],
  },
  // Compute
  aws_ecs_cluster: {
    color: '#C7522A',
    paths: ['M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z', 'M3.27 6.96L12 12.01l8.73-5.05M12 22.08V12'],
  },
  aws_ecs_service: {
    color: '#C7522A',
    paths: ['M20 7H4a2 2 0 00-2 2v6a2 2 0 002 2h16a2 2 0 002-2V9a2 2 0 00-2-2z', 'M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16'],
  },
  aws_lambda_function: {
    color: '#C7522A',
    paths: ['M13 2L3 14h9l-1 8 10-12h-9l1-8z'],
  },
  aws_instance: {
    color: '#C7522A',
    paths: ['M20 7H4a2 2 0 00-2 2v10a2 2 0 002 2h16a2 2 0 002-2V9a2 2 0 00-2-2z', 'M16 3H8a1 1 0 00-1 1v3h10V4a1 1 0 00-1-1z', 'M8 14h.01M12 14h.01M16 14h.01'],
  },
  aws_autoscaling_group: {
    color: '#C7522A',
    paths: ['M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83'],
  },
  // Data
  aws_rds_cluster: {
    color: '#946600',
    paths: ['M12 2C6.5 2 2 4 2 6.5v11C2 20 6.5 22 12 22s10-2 10-4.5v-11C22 4 17.5 2 12 2z', 'M2 6.5C2 9 6.5 11 12 11s10-2 10-4.5', 'M2 12c0 2.5 4.5 4.5 10 4.5S22 14.5 22 12'],
  },
  aws_rds_cluster_instance: {
    color: '#946600',
    paths: ['M12 2C6.5 2 2 4 2 6v12c0 2 4.5 4 10 4s10-2 10-4V6c0-2-4.5-4-10-4z', 'M2 10c0 2 4.5 4 10 4s10-2 10-4'],
  },
  aws_db_instance: {
    color: '#946600',
    paths: ['M12 2C6.5 2 2 4 2 6v12c0 2 4.5 4 10 4s10-2 10-4V6c0-2-4.5-4-10-4z', 'M2 10c0 2 4.5 4 10 4s10-2 10-4', 'M2 14c0 2 4.5 4 10 4s10-2 10-4'],
  },
  aws_dynamodb_table: {
    color: '#946600',
    paths: ['M12 2L2 8l10 6 10-6-10-6z', 'M2 16l10 6 10-6', 'M2 12l10 6 10-6'],
  },
  aws_elasticache_cluster: {
    color: '#946600',
    paths: ['M5 12H3a9 9 0 0018 0h-2', 'M12 3v4M12 17v4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M3 12h4M17 12h4M5.6 18.4l2.8-2.8M15.6 8.4l2.8-2.8'],
  },
  aws_opensearch_domain: {
    color: '#946600',
    paths: ['M11 19a8 8 0 100-16 8 8 0 000 16z', 'M21 21l-4.35-4.35', 'M8 11h6M11 8v6'],
  },
  // Storage
  aws_s3_bucket: {
    color: '#067940',
    paths: ['M21 8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z'],
  },
  aws_s3_bucket_lifecycle_configuration: {
    color: '#067940',
    paths: ['M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4'],
  },
  aws_efs_file_system: {
    color: '#067940',
    paths: ['M13 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V9z', 'M13 2v7h7'],
  },
  aws_secretsmanager_secret: {
    color: '#067940',
    paths: ['M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.778 7.778 5.5 5.5 0 017.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4'],
  },
  aws_kms_key: {
    color: '#067940',
    paths: ['M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.778 7.778 5.5 5.5 0 017.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4'],
  },
  // Other
  aws_sqs_queue: {
    color: '#6B6B6B',
    paths: ['M3 6h18M3 12h18M3 18h18'],
  },
  aws_sns_platform_application: {
    color: '#6B6B6B',
    paths: ['M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.17 9.8a19.79 19.79 0 01-3.07-8.63A2 2 0 012.08 0h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.91 7.91a16 16 0 006 9.9'],
  },
  aws_cloudwatch_event_bus: {
    color: '#6B6B6B',
    paths: ['M18 20V10M12 20V4M6 20v-6'],
  },
  aws_ses_email_identity: {
    color: '#6B6B6B',
    paths: ['M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z', 'M22 6l-10 7L2 6'],
  },
};

function getIcon(type) {
  return ICONS[type] || {
    color: '#6B6B6B',
    paths: ['M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z'],
  };
}

// ── Main component ─────────────────────────────────────────────────────────
export default function TopologyGraph({ compact = false }) {
  const containerRef  = useRef(null);
  const svgRef        = useRef(null);
  const [dims, setDims] = useState({ w: 600, h: compact ? 240 : 480 });
  const [tooltip, setTooltip] = useState(null);
  const selectedAccountId = useStore(s => s.selectedAccountId);
  const topology          = useStore(s => s.topology);
  const graph             = topology[selectedAccountId];

  // Responsive width
  useEffect(() => {
    if (!containerRef.current) return;
    const ro = new ResizeObserver(entries => {
      const w = entries[0].contentRect.width;
      if (w > 0) setDims({ w, h: compact ? 240 : Math.max(480, w * 0.55) });
    });
    ro.observe(containerRef.current);
    return () => ro.disconnect();
  }, [compact]);

  useEffect(() => {
    if (!svgRef.current) return;
    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();
    const { w, h } = dims;

    // ── Empty state ────────────────────────────────────────────────────
    if (!graph?.nodes?.length) {
      svg.append('text')
        .attr('x', w / 2).attr('y', h / 2)
        .attr('text-anchor', 'middle').attr('dominant-baseline', 'middle')
        .attr('fill', 'var(--text-4)').attr('font-size', 13)
        .text(selectedAccountId ? 'Loading topology…' : 'Select an account to view topology');
      return;
    }

    const nodes = graph.nodes.map(n => ({ ...n }));
    const idSet = new Set(nodes.map(n => n.id));
    const edges = graph.edges
      .filter(e => idSet.has(e.source) && idSet.has(e.target))
      .map(e => ({ ...e }));

    // ── Tier layout — horizontal swim lanes ────────────────────────────
    const tierOrder = ['ingress', 'compute', 'data', 'storage', 'other'];
    const nodeW = compact ? 76 : 88;
    const nodeH = compact ? 72 : 86;
    const vGap  = compact ? 24 : 32;
    const hGap  = compact ? 18 : 24;

    // Group nodes by tier
    const byTier = {};
    tierOrder.forEach(t => { byTier[t] = []; });
    nodes.forEach(n => {
      const t = n.tier && byTier[n.tier] ? n.tier : 'other';
      byTier[t].push(n);
    });

    // Calculate total height needed
    const usedTiers = tierOrder.filter(t => byTier[t].length > 0);
    const tierH = h / usedTiers.length;
    const PAD_LEFT = 80; // space for tier labels

    usedTiers.forEach((tier, ti) => {
      const tierNodes = byTier[tier];
      const rowW = tierNodes.length * (nodeW + hGap) - hGap;
      const startX = PAD_LEFT + Math.max(0, (w - PAD_LEFT - rowW) / 2) + nodeW / 2;
      const cy = tierH * ti + tierH / 2;
      tierNodes.forEach((n, ni) => {
        n.x = startX + ni * (nodeW + hGap);
        n.y = cy;
      });
    });

    // ── SVG setup ──────────────────────────────────────────────────────
    const g = svg.append('g');
    svg.call(
      d3.zoom().scaleExtent([0.3, 3]).on('zoom', e => g.attr('transform', e.transform))
    );

    // Defs
    const defs = svg.append('defs');

    // Arrow marker
    defs.append('marker')
      .attr('id', 'arr')
      .attr('viewBox', '0 0 10 10')
      .attr('refX', 10).attr('refY', 5)
      .attr('markerWidth', 5).attr('markerHeight', 5)
      .attr('orient', 'auto')
      .append('path').attr('d', 'M0,0 L10,5 L0,10 z')
      .attr('fill', '#3A4A68');

    // Node drop shadow
    const f = defs.append('filter').attr('id', 'nshadow').attr('x', '-20%').attr('y', '-20%').attr('width', '140%').attr('height', '140%');
    f.append('feDropShadow').attr('dx', 0).attr('dy', 2).attr('stdDeviation', 3).attr('flood-color', '#000').attr('flood-opacity', 0.18);

    // Glow filter for highlighted nodes
    const fg = defs.append('filter').attr('id', 'glow');
    fg.append('feGaussianBlur').attr('stdDeviation', 3).attr('result', 'blur');
    const fgm = fg.append('feMerge');
    fgm.append('feMergeNode').attr('in', 'blur');
    fgm.append('feMergeNode').attr('in', 'SourceGraphic');

    // ── Tier swim lane backgrounds ─────────────────────────────────────
    usedTiers.forEach((tier, ti) => {
      const t = TIER_MAP[tier] || TIERS[4];
      const cy = tierH * ti;
      g.append('rect')
        .attr('x', 0).attr('y', cy).attr('width', w).attr('height', tierH)
        .attr('fill', t.bg);
      g.append('line')
        .attr('x1', 0).attr('y1', cy).attr('x2', w).attr('y2', cy)
        .attr('stroke', t.color).attr('stroke-width', 0.5).attr('opacity', 0.3);
      // Tier label
      g.append('text')
        .attr('x', 10).attr('y', cy + tierH / 2)
        .attr('dominant-baseline', 'middle')
        .attr('font-size', compact ? 9 : 10)
        .attr('font-weight', '700')
        .attr('fill', t.color)
        .attr('font-family', 'var(--font-mono, monospace)')
        .attr('letter-spacing', '0.5')
        .attr('opacity', 0.8)
        .text(t.label.toUpperCase());
    });

    // ── Edges (curved bezier) ──────────────────────────────────────────
    function edgePath(d) {
      const src = nodes.find(n => n.id === d.source || n.id === d.source?.id);
      const tgt = nodes.find(n => n.id === d.target || n.id === d.target?.id);
      if (!src || !tgt) return '';
      const dx = tgt.x - src.x;
      const dy = tgt.y - src.y;
      const cp1x = src.x + dx * 0.3;
      const cp1y = src.y + dy * 0.7;
      const cp2x = tgt.x - dx * 0.3;
      const cp2y = tgt.y - dy * 0.3;
      // Offset endpoint to node edge
      const angle = Math.atan2(tgt.y - cp2y, tgt.x - cp2x);
      const ex = tgt.x - Math.cos(angle) * (nodeW / 2 + 4);
      const ey = tgt.y - Math.sin(angle) * (nodeH / 2 + 4);
      return `M${src.x},${src.y} C${cp1x},${cp1y} ${cp2x},${cp2y} ${ex},${ey}`;
    }

    // Shadow edges
    g.selectAll('.edge-bg').data(edges).enter().append('path')
      .attr('class', 'edge-bg')
      .attr('d', edgePath)
      .attr('fill', 'none')
      .attr('stroke', '#000')
      .attr('stroke-width', 4)
      .attr('opacity', 0.06);

    // Main edges
    g.selectAll('.edge').data(edges).enter().append('path')
      .attr('class', 'edge')
      .attr('d', edgePath)
      .attr('fill', 'none')
      .attr('stroke', '#3A4A68')
      .attr('stroke-width', 1.5)
      .attr('opacity', 0.6)
      .attr('marker-end', 'url(#arr)');

    // ── Nodes ──────────────────────────────────────────────────────────
    const nW2 = nodeW / 2;
    const nH2 = nodeH / 2;
    const iconSize = compact ? 22 : 26;
    const RADIUS = 8;

    const ng = g.selectAll('.node').data(nodes).enter()
      .append('g').attr('class', 'node')
      .attr('transform', d => `translate(${d.x},${d.y})`)
      .style('cursor', 'pointer');

    // Card background
    ng.append('rect')
      .attr('x', -nW2).attr('y', -nH2)
      .attr('width', nodeW).attr('height', nodeH)
      .attr('rx', RADIUS)
      .attr('fill', '#0D1B2E')
      .attr('stroke', d => getIcon(d.type).color || TIER_MAP[d.tier]?.color || '#3A4A68')
      .attr('stroke-width', 1.5)
      .attr('filter', 'url(#nshadow)');

    // Top accent bar
    ng.append('rect')
      .attr('x', -nW2).attr('y', -nH2)
      .attr('width', nodeW).attr('height', 3)
      .attr('rx', RADIUS)
      .attr('fill', d => getIcon(d.type).color || TIER_MAP[d.tier]?.color || '#3A4A68');

    // Icon background circle
    ng.append('circle')
      .attr('cx', 0).attr('cy', compact ? -8 : -10)
      .attr('r', compact ? 14 : 16)
      .attr('fill', d => `${getIcon(d.type).color || '#3A4A68'}22`)
      .attr('stroke', d => `${getIcon(d.type).color || '#3A4A68'}44`)
      .attr('stroke-width', 1);

    // Icon (SVG paths scaled to fit)
    const scale = iconSize / 24;
    ng.each(function(d) {
      const icon = getIcon(d.type);
      const cy = compact ? -8 : -10;
      const grp = d3.select(this).append('g')
        .attr('transform', `translate(${-iconSize/2},${cy - iconSize/2}) scale(${scale})`);
      icon.paths.forEach(p => {
        grp.append('path')
          .attr('d', p)
          .attr('fill', 'none')
          .attr('stroke', icon.color || '#3A4A68')
          .attr('stroke-width', 2 / scale)
          .attr('stroke-linecap', 'round')
          .attr('stroke-linejoin', 'round');
      });
    });

    // Label
    const labelY = compact ? 12 : 14;
    ng.append('text')
      .attr('text-anchor', 'middle')
      .attr('y', labelY)
      .attr('font-size', compact ? 8.5 : 9.5)
      .attr('font-weight', '600')
      .attr('fill', '#E0E8F8')
      .attr('font-family', 'var(--font, sans-serif)')
      .text(d => {
        const name = d.label || d.name || d.id;
        const max  = compact ? 10 : 12;
        return name.length > max ? name.slice(0, max) + '…' : name;
      });

    // Resource type sub-label
    if (!compact) {
      ng.append('text')
        .attr('text-anchor', 'middle')
        .attr('y', 27)
        .attr('font-size', 7.5)
        .attr('fill', d => getIcon(d.type).color || '#6B7A94')
        .attr('font-family', 'var(--font-mono, monospace)')
        .attr('opacity', 0.8)
        .text(d => {
          const t = d.type || '';
          // Short label: aws_lambda_function → Lambda
          const map = {
            aws_alb: 'ALB', aws_apigatewayv2_api: 'API GW', aws_cloudfront_distribution: 'CloudFront',
            aws_wafv2_web_acl: 'WAF', aws_acm_certificate: 'ACM',
            aws_ecs_cluster: 'ECS Cluster', aws_ecs_service: 'ECS Service',
            aws_lambda_function: 'Lambda', aws_instance: 'EC2', aws_autoscaling_group: 'Auto Scaling',
            aws_rds_cluster: 'Aurora', aws_rds_cluster_instance: 'RDS Instance',
            aws_db_instance: 'RDS', aws_dynamodb_table: 'DynamoDB',
            aws_elasticache_cluster: 'ElastiCache', aws_opensearch_domain: 'OpenSearch',
            aws_s3_bucket: 'S3', aws_efs_file_system: 'EFS',
            aws_secretsmanager_secret: 'Secrets Mgr', aws_kms_key: 'KMS',
            aws_sqs_queue: 'SQS', aws_sns_platform_application: 'SNS',
            aws_cloudwatch_event_bus: 'EventBridge', aws_ses_email_identity: 'SES',
          };
          return map[t] || t.replace('aws_', '').replace(/_/g, ' ').slice(0, 14);
        });
    }

    // ── Hover interactions ─────────────────────────────────────────────
    ng.on('mouseenter', function(event, d) {
        d3.select(this).select('rect')
          .attr('stroke-width', 2.5)
          .attr('filter', 'url(#nshadow) url(#glow)');
        // Show tooltip via React state (positioned relative to container)
        const rect = containerRef.current.getBoundingClientRect();
        setTooltip({
          x: event.clientX - rect.left,
          y: event.clientY - rect.top,
          node: d,
        });
      })
      .on('mousemove', function(event) {
        const rect = containerRef.current.getBoundingClientRect();
        setTooltip(prev => prev ? { ...prev, x: event.clientX - rect.left, y: event.clientY - rect.top } : null);
      })
      .on('mouseleave', function() {
        d3.select(this).select('rect')
          .attr('stroke-width', 1.5)
          .attr('filter', 'url(#nshadow)');
        setTooltip(null);
      });

    // ── Legend ─────────────────────────────────────────────────────────
    const legendY = h - 18;
    const legendData = usedTiers.map(t => TIER_MAP[t] || TIERS[4]);
    const legendW    = legendData.length * 90;
    const lx         = (w - legendW) / 2;
    legendData.forEach((t, i) => {
      const lgrp = g.append('g').attr('transform', `translate(${lx + i * 90},${legendY})`);
      lgrp.append('rect').attr('width', 10).attr('height', 3).attr('rx', 1).attr('fill', t.color);
      lgrp.append('text').attr('x', 14).attr('y', 3).attr('font-size', 9)
        .attr('fill', '#6B7A94').attr('font-family', 'var(--font, sans-serif)').text(t.label);
    });

    // Hint text
    g.append('text')
      .attr('x', w - 8).attr('y', legendY + 2)
      .attr('text-anchor', 'end').attr('font-size', 8.5)
      .attr('fill', '#3A4A68').attr('font-family', 'var(--font, sans-serif)')
      .text('Scroll to zoom · Drag to pan');

  }, [graph, dims, selectedAccountId, compact]);

  return (
    <div ref={containerRef} style={{ width: '100%', position: 'relative' }}>
      <svg
        ref={svgRef}
        width="100%"
        height={dims.h}
        style={{ background: 'var(--surface-2)', borderRadius: 6, display: 'block' }}
      />

      {/* React tooltip */}
      {tooltip && (
        <div style={{
          position: 'absolute',
          left: tooltip.x + 12,
          top: tooltip.y - 10,
          background: '#0D1B2E',
          border: `1px solid ${getIcon(tooltip.node.type).color || '#3A4A68'}`,
          borderRadius: 6,
          padding: '8px 12px',
          pointerEvents: 'none',
          zIndex: 100,
          maxWidth: 220,
          boxShadow: '0 4px 16px rgba(0,0,0,0.4)',
        }}>
          <div style={{ fontWeight: 700, fontSize: 12.5, color: '#E0E8F8', marginBottom: 3 }}>
            {tooltip.node.label || tooltip.node.name || tooltip.node.id}
          </div>
          <div style={{ fontSize: 10.5, color: getIcon(tooltip.node.type).color || '#6B7A94',
            fontFamily: 'monospace', marginBottom: 4 }}>
            {tooltip.node.type || ''}
          </div>
          <div style={{ fontSize: 10, color: '#4A5A78' }}>
            Tier: {tooltip.node.tier || 'other'}
          </div>
        </div>
      )}
    </div>
  );
}
