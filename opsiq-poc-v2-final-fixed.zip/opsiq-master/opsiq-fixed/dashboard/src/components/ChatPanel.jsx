import { useEffect, useRef, useState } from 'react';
import { useStore } from '../store.js';

const API_URL = import.meta.env.VITE_API_URL || '';
const SUGGESTED = [
  "What's wrong with sim-app-a right now?",
  'Which account is in the worst shape?',
  'What should I investigate first?',
  'What caused the current incident?',
];

function SourceBadge({ source }) {
  const labels = {
    health_scores: 'Health Scores',
    incidents: 'Incidents',
    anomalies: 'Anomalies',
    ai_summary: 'AI Analysis',
    topology: 'Topology',
    runbook: 'Runbook',
  };
  return <span className="chat-source-badge">{labels[source] || source}</span>;
}

function Message({ msg }) {
  const isUser = msg.role === 'user';
  return (
    <div className={`chat-message ${isUser ? 'user' : 'assistant'}`}>
      <div className={`chat-avatar ${isUser ? 'user' : 'assistant'}`}>{isUser ? 'IM' : 'AI'}</div>
      <div className="chat-message-body">
        <div className={`chat-bubble ${isUser ? 'user' : 'assistant'}`}>{msg.content}</div>
        {msg.sources?.length > 0 && (
          <div className="chat-sources">
            <span>Grounded in:</span>
            {msg.sources.map(s => <SourceBadge key={s} source={s} />)}
          </div>
        )}
        <div className="chat-time">{msg.time}</div>
      </div>
    </div>
  );
}

export default function ChatPanel() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([{
    role: 'assistant',
    content: "Hi - I'm your AI SRE Agent. I have access to real-time data across all monitored accounts. Ask me what's broken, what changed, what to do next, or anything about your infrastructure.",
    time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
    sources: [],
  }]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);
  const inputRef = useRef(null);
  const selectedAccountId = useStore(s => s.selectedAccountId);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages, open]);
  useEffect(() => { if (open) setTimeout(() => inputRef.current?.focus(), 100); }, [open]);

  async function send(text) {
    const q = (text || input).trim();
    if (!q || loading) return;

    const ts = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    setMessages(prev => [...prev, { role: 'user', content: q, time: ts, sources: [] }]);
    setInput('');
    setLoading(true);

    try {
      const resp = await fetch(`${API_URL}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: q, accountId: selectedAccountId || undefined }),
      });
      const data = await resp.json();
      const ts2 = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: data.answer || data.error || 'No response received - check Bedrock model access is enabled.',
        time: ts2,
        sources: data.sources || [],
      }]);
    } catch (e) {
      console.error('Chat error:', e);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: 'Unable to reach AI SRE Agent. Check that Bedrock model access is enabled and the /chat route is deployed.',
        time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
        sources: [],
      }]);
    } finally {
      setLoading(false);
    }
  }

  function handleKey(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  }

  return (
    <>
      <button
        className={`chat-launcher ${open ? 'open' : ''}`}
        onClick={() => setOpen(o => !o)}
        title="Ask AI SRE Agent"
      >
        {open ? (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round">
            <line x1="18" y1="6" x2="6" y2="18" />
            <line x1="6" y1="6" x2="18" y2="18" />
          </svg>
        ) : (
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z" />
            <line x1="9" y1="10" x2="15" y2="10" strokeWidth="1.5" />
            <line x1="9" y1="13" x2="13" y2="13" strokeWidth="1.5" />
          </svg>
        )}
      </button>

      {open && (
        <div className="chat-panel">
          <div className="chat-header">
            <div className="chat-header-icon">AI</div>
            <div>
              <div className="chat-header-title">AI SRE Agent</div>
              <div className="chat-header-sub"><span /> Online · Real-time operations context</div>
            </div>
            {selectedAccountId && <div className="chat-account-chip">{selectedAccountId}</div>}
          </div>

          <div className="chat-thread">
            {messages.map((msg, i) => <Message key={i} msg={msg} />)}
            {loading && (
              <div className="chat-message assistant">
                <div className="chat-avatar assistant">AI</div>
                <div className="chat-typing">{[0, 1, 2].map(i => <div key={i} style={{ animationDelay: `${i * 0.2}s` }} />)}</div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {messages.length === 1 && !loading && (
            <div className="chat-suggestions">
              <div>Try asking</div>
              <div>{SUGGESTED.map(q => <button key={q} onClick={() => send(q)}>{q}</button>)}</div>
            </div>
          )}

          <div className="chat-composer">
            <textarea
              ref={inputRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKey}
              placeholder="Ask about incidents, anomalies, topology..."
              disabled={loading}
              rows={1}
              onInput={e => {
                e.target.style.height = 'auto';
                e.target.style.height = `${Math.min(e.target.scrollHeight, 88)}px`;
              }}
            />
            <button onClick={() => send()} disabled={!input.trim() || loading}>
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <line x1="22" y1="2" x2="11" y2="13" />
                <polygon points="22 2 15 22 11 13 2 9 22 2" />
              </svg>
            </button>
          </div>
        </div>
      )}
    </>
  );
}
