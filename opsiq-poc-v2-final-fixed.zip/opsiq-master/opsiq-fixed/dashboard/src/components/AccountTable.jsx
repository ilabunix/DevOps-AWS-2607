import { useStore } from '../store.js';
const STACK_MAP = {'sim-app-a':'ECS · ALB · Aurora PostgreSQL','sim-app-b':'Lambda · APIGW · DynamoDB','sim-app-c':'ECS · ALB · ElastiCache Redis'};
function ScoreBar({score}) {
  const c=score>=80?'var(--green)':score>=60?'var(--amber)':'var(--red)';
  return <div className="score-bar-wrap"><div className="score-bar-bg"><div className="score-bar-fill" style={{width:`${score}%`,background:c}}/></div><span className="score-num" style={{color:c}}>{score}</span></div>;
}
function StatusBadge({score}) {
  if(score>=80) return <span className="badge badge-green">Healthy</span>;
  if(score>=60) return <span className="badge badge-amber">Warning</span>;
  return <span className="badge badge-red">Critical</span>;
}
export default function AccountTable() {
  const accounts=useStore(s=>s.accounts);
  const anomalies=useStore(s=>s.anomalies);
  const incidents=useStore(s=>s.incidents);
  const selectedAccountId=useStore(s=>s.selectedAccountId);
  const setSelectedAccount=useStore(s=>s.setSelectedAccount);
  const setView=useStore(s=>s.setView);
  const loading=useStore(s=>s.loading.accounts);
  const sorted=[...accounts].sort((a,b)=>Number(a.score||0)-Number(b.score||0));
  return (
    <div className="panel fade-in">
      <div className="panel-hdr">
        <div><div className="panel-title">Account Health</div><div className="panel-sub">{accounts.length} accounts · Click row to select · Click View details for topology</div></div>
        <button className="btn btn-secondary" style={{fontSize:12,padding:'5px 12px'}} onClick={()=>setView('Accounts')}>Manage Accounts</button>
      </div>
      {loading?<div className="loading-row">Loading accounts…</div>:(
        <div style={{overflowX:'auto'}}>
          <table className="aws-table">
            <thead><tr><th>Account</th><th>Stack</th><th style={{minWidth:160}}>Health Score</th><th>Incidents</th><th>Anomalies</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              {sorted.map(acc=>{
                const score=Number(acc.score||0);
                const accInc=incidents.filter(i=>i.accountId===acc.accountId&&i.status==='OPEN').length;
                const accAnom=anomalies.filter(a=>a.accountId===acc.accountId).length;
                return (
                  <tr key={acc.accountId} className={acc.accountId===selectedAccountId?'row-selected':''} style={{cursor:'pointer'}} onClick={()=>setSelectedAccount(acc.accountId)}>
                    <td><div style={{fontWeight:600}}>{acc.accountId}</div><div style={{fontSize:11,color:'var(--text-3)',fontFamily:'monospace'}}>arn:aws:{acc.accountId}</div></td>
                    <td><span style={{fontSize:12.5,color:'var(--text-2)'}}>{STACK_MAP[acc.accountId]||'AWS Managed'}</span></td>
                    <td><ScoreBar score={score}/></td>
                    <td><span style={{fontWeight:700,color:accInc>0?'var(--red)':'var(--text-3)'}}>{accInc}</span></td>
                    <td><span style={{fontWeight:700,color:accAnom>3?'var(--amber)':'var(--text-3)'}}>{accAnom}</span></td>
                    <td><StatusBadge score={score}/></td>
                    <td><button className="btn-link" style={{fontSize:12.5,color:'var(--blue)',background:'none',border:'none',cursor:'pointer',textDecoration:'underline'}}
                      onClick={e=>{e.stopPropagation();setSelectedAccount(acc.accountId);setView('Topology');}}>View details</button></td>
                  </tr>
                );
              })}
              {sorted.length===0&&<tr><td colSpan={7} className="empty-state">No accounts found. Run deploy-simulation.sh to seed data.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
