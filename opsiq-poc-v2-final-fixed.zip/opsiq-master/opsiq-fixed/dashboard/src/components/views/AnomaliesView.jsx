import { useStore } from '../../store.js';
function timeAgo(ts){if(!ts)return '—';const m=Math.floor((Date.now()-Number(ts))/60000);if(m<1)return 'just now';if(m<60)return `${m} min ago`;return `${Math.floor(m/60)}h ago`;}
const SEV={HIGH:'var(--red)',MEDIUM:'var(--amber)',LOW:'var(--blue)'};
export default function AnomaliesView() {
  const anomalies=useStore(s=>s.anomalies);
  const setView=useStore(s=>s.setView);
  const byAccount=anomalies.reduce((acc,a)=>{(acc[a.accountId]=acc[a.accountId]||[]).push(a);return acc;},{});
  function title(a){
  const t=a.anomalyType||'';
  const sig=(a.signature||a.description||a.message||'').replace(/\s+/g,' ');
  const src=a.logGroup||a.resource||'';
  if(t==='novel_log_pattern'){
    if(sig&&sig.toLowerCase()!=='unknown')return 'Novel: '+sig.slice(0,70)+(sig.length>70?'…':'');
    return 'Novel log pattern — '+(src||'unknown source');
  }
  if(t==='log_volume_spike')return `Volume spike: ${a.currentCount||''} ${a.level||'ERROR'} events in 5min (z=${a.zScore||''})`;
  if(t==='log_pattern_spike')return `Pattern spike: ${sig.slice(0,50)||'known error'} · ${a.currentCount||''}x above baseline`;
  if(t==='log_silence')return `Log silence — ${src||a.logGroup||'log group'} went quiet`;
  if(t==='alb_5xx')return `ALB 5xx spike — ${a.value||a.currentCount||''}% error rate`;
  if(t==='ecs_high_memory')return `ECS memory critical — ${a.value||''}%`;
  if(t==='rds_connection_exhaustion')return 'RDS connection exhaustion';
  if(!t&&sig)return 'Signal: '+sig.slice(0,70);
  if(t)return t.replace(/_/g,' ').replace(/\b\w/g,c=>c.toUpperCase());
  return 'Anomaly — '+(src||'unknown');
}
  return (
    <div className="content">
      <div className="breadcrumb"><a onClick={()=>setView('Dashboard')} style={{cursor:'pointer'}}>OpsIQ</a><svg viewBox="0 0 6 10" fill="none" stroke="currentColor" strokeWidth="1.5" width="6" height="10" strokeLinecap="round"><path d="M1 1l4 4-4 4"/></svg>Anomalies</div>
      <div className="page-hdr"><div><h1 className="page-title">Anomaly Feed</h1><div className="page-desc">{anomalies.length} detections · {anomalies.filter(a=>a.anomalyType==='novel_log_pattern').length} novel patterns · {anomalies.filter(a=>a.anomalyType?.includes('volume')||a.anomalyType?.includes('pattern_spike')).length} rate anomalies</div></div></div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16}}>
        {Object.entries(byAccount).map(([accountId,items])=>(
          <div className="panel" key={accountId}>
            <div className="panel-hdr"><div><div className="panel-title">{accountId}</div><div className="panel-sub">{items.length} anomalies</div></div><span className={`badge ${items.some(i=>i.severity==='HIGH')?'badge-red':'badge-amber'}`}>{items.filter(i=>i.severity==='HIGH').length} HIGH</span></div>
            <div className="panel-body" style={{paddingTop:4,paddingBottom:4}}>
              {items.slice(0,10).map((a,i)=>(
                <div key={i} style={{display:'flex',gap:10,alignItems:'flex-start',padding:'8px 0',borderBottom:'1px solid var(--border-light)'}}>
                  <div style={{width:8,height:8,borderRadius:'50%',background:SEV[a.severity]||'var(--blue)',flexShrink:0,marginTop:5}}/>
                  <div style={{flex:1,minWidth:0}}><div style={{fontWeight:500,fontSize:12.5}}>{title(a)}</div><div style={{fontSize:11.5,color:'var(--text-3)'}}>{a.logGroup||a.resource||a.description||'—'}</div></div>
                  <div style={{fontSize:11,color:'var(--text-3)',fontFamily:'monospace',flexShrink:0}}>{timeAgo(a.timestamp)}</div>
                </div>
              ))}
              {items.length===0&&<div className="empty-state">No anomalies.</div>}
            </div>
          </div>
        ))}
        {Object.keys(byAccount).length===0&&<div className="panel" style={{gridColumn:'1/-1'}}><div className="panel-body empty-state">No anomalies detected. System healthy.</div></div>}
      </div>
    </div>
  );
}
