/**
 * ChatView.jsx - Dedicated AI SRE Agent Tab
 *
 * BEDROCK COST GUARANTEE:
 *   - Exactly 1 Bedrock call per user message
 *   - max_tokens: 600 enforced server-side
 *   - Zero automatic calls
 *   - Cancel button aborts in-flight request
 */
import { useState, useRef, useEffect, useCallback } from 'react';
import { useStore } from '../../store.js';

const API_URL = import.meta.env.VITE_API_URL || '';

const PROMPT_GROUPS = [
  {
    label: 'Triage',
    prompts: [
      'Which account needs urgent attention right now?',
      'Rank the current incidents by customer impact.',
      'What changed in the last 30 minutes?',
    ],
  },
  {
    label: 'Explain',
    prompts: [
      'Explain the likely root cause for the worst incident.',
      'What are the common patterns across current incidents?',
      'Summarise the current fleet health status.',
    ],
  },
  {
    label: 'Runbook',
    prompts: [
      'Walk me through investigation steps for the worst incident.',
      'Give me CLI checks for the affected account.',
      'What should I verify before escalating?',
    ],
  },
];

const CHAT_STARTERS = [
  {
    label: 'Triage live risk',
    prompt: 'Which account needs urgent attention right now, and why?',
  },
  {
    label: 'Explain the incident',
    prompt: 'Explain the likely root cause for the worst active incident.',
  },
  {
    label: 'Build a runbook',
    prompt: 'Give me step-by-step checks and CLI commands for the highest-risk account.',
  },
  {
    label: 'Find recent change',
    prompt: 'What changed in the last 30 minutes across incidents and anomalies?',
  },
];

function ts() {
  return new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
}

function timeAgo(value) {
  const n = Number(value || 0);
  if (!n) return 'unknown';
  const mins = Math.max(0, Math.floor((Date.now() - n) / 60000));
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  return `${Math.floor(mins / 60)}h ${mins % 60}m ago`;
}

function statusForScore(score) {
  const s = Number(score || 0);
  if (s >= 80) return { label: 'Healthy', color: 'var(--green)' };
  if (s >= 60) return { label: 'Watch', color: 'var(--amber)' };
  return { label: 'Critical', color: 'var(--red)' };
}

function CopyButton({ text }) {
  const [done, setDone] = useState(false);
  return (
    <button
      className="ai-copy-btn"
      onClick={() => {
        navigator.clipboard.writeText(text);
        setDone(true);
        setTimeout(() => setDone(false), 1800);
      }}
    >
      {done ? 'Copied' : 'Copy'}
    </button>
  );
}

function MsgBody({ text }) {
  const parts = [];
  let buf = [];
  for (const line of text.split('\n')) {
    const t = line.trim();
    if (/^(aws |kubectl |docker |curl |\$ aws )/.test(t)) {
      if (buf.length) {
        parts.push({ type: 'text', value: buf.join('\n') });
        buf = [];
      }
      parts.push({ type: 'cmd', value: t.replace(/^\$ /, '') });
    } else {
      buf.push(line);
    }
  }
  if (buf.length) parts.push({ type: 'text', value: buf.join('\n') });

  return (
    <div className="ai-msg-body">
      {parts.map((part, i) => part.type === 'cmd' ? (
        <div className="ai-command" key={i}>
          <code>{part.value}</code>
          <CopyButton text={part.value} />
        </div>
      ) : (
        <p key={i}>{part.value}</p>
      ))}
    </div>
  );
}

function SourceChip({ s }) {
  const map = {
    health_scores: { label: 'Health', className: 'green' },
    incidents: { label: 'Incidents', className: 'red' },
    anomalies: { label: 'Anomalies', className: 'amber' },
    ai_summary: { label: 'AI Analysis', className: 'purple' },
    topology: { label: 'Topology', className: 'blue' },
    runbook: { label: 'Runbook', className: 'neutral' },
  };
  const item = map[s] || { label: s, className: 'neutral' };
  return <span className={`ai-source ${item.className}`}>{item.label}</span>;
}

function Bubble({ msg }) {
  const isUser = msg.role === 'user';
  return (
    <div className={`ai-msg ${isUser ? 'user' : 'assistant'}`}>
      <div className="ai-avatar">{isUser ? 'IM' : 'AI'}</div>
      <div className="ai-msg-stack">
        <div className="ai-bubble">
          <MsgBody text={msg.content} />
        </div>
        <div className="ai-msg-meta">
          {(msg.sources || []).length > 0 && (
            <>
              <span>Grounded in</span>
              {msg.sources.map(s => <SourceChip key={s} s={s} />)}
            </>
          )}
          <time>{msg.time}</time>
        </div>
      </div>
    </div>
  );
}

function Typing({ onCancel }) {
  return (
    <div className="ai-msg assistant">
      <div className="ai-avatar">AI</div>
      <div className="ai-typing">
        <span />
        <span />
        <span />
        <b>Analysing</b>
        <button onClick={onCancel}>Cancel</button>
      </div>
    </div>
  );
}

function MetricCard({ label, value, tone, sub }) {
  return (
    <div className={`ai-metric ${tone || ''}`}>
      <strong>{value}</strong>
      <span>{label}</span>
      {sub && <em>{sub}</em>}
    </div>
  );
}

function PromptGroups({ onSuggest }) {
  return (
    <div className="ai-prompt-groups">
      {PROMPT_GROUPS.map(group => (
        <section key={group.label}>
          <h3>{group.label}</h3>
          {group.prompts.map(prompt => (
            <button key={prompt} onClick={() => onSuggest(prompt)}>
              {prompt}
            </button>
          ))}
        </section>
      ))}
    </div>
  );
}

function ChatWelcome({ onSuggest }) {
  return (
    <div className="ai-welcome">
      <div className="ai-welcome-mark" aria-hidden="true">
        <svg viewBox="0 0 64 44">
          <path className="trace" d="M8 29 C16 16 24 34 32 21 S48 16 56 8" />
          <path className="trace muted" d="M11 34 H24 L31 28 L43 33 H55" />
          <circle className="node blue" cx="9" cy="29" r="4" />
          <circle className="node purple" cx="32" cy="21" r="5" />
          <circle className="node amber" cx="56" cy="8" r="4" />
          <circle className="node green" cx="43" cy="33" r="4" />
          <path className="lens" d="M36 25l9 9" />
          <circle className="lens" cx="30" cy="20" r="10" />
        </svg>
      </div>
      <h2>Start an investigation</h2>
      <p>Ask a direct question, choose a mode, or start from one of these guided prompts.</p>
      <div className="ai-starter-grid">
        {CHAT_STARTERS.map(item => (
          <button key={item.label} onClick={() => onSuggest(item.prompt)}>
            <strong>{item.label}</strong>
            <span>{item.prompt}</span>
          </button>
        ))}
      </div>
      <div className="ai-capability-row">
        <span>Grounded in incidents</span>
        <span>Reads anomaly context</span>
        <span>Drafts CLI checks</span>
      </div>
    </div>
  );
}

function EvidenceRail({ onSuggest }) {
  const accounts = useStore(s => s.accounts);
  const incidents = useStore(s => s.incidents);
  const anomalies = useStore(s => s.anomalies);
  const selectedAccountId = useStore(s => s.selectedAccountId);

  const open = incidents.filter(i => i.status === 'OPEN');
  const worstAccount = [...accounts].sort((a, b) => Number(a.score || 0) - Number(b.score || 0))[0];
  const activeIncident = open[0] || incidents[0];
  const latestAnomaly = anomalies[0];

  return (
    <aside className="ai-evidence-rail">
      <section className="ai-evidence-card">
        <div className="ai-section-label">Active Case</div>
        <div className="ai-case-title">
          {activeIncident ? (activeIncident.incidentType || 'Incident').replace(/_/g, ' ') : 'No active incident'}
        </div>
        <div className="ai-case-grid">
          <span>Account</span>
          <b>{activeIncident?.accountId || selectedAccountId || worstAccount?.accountId || 'All accounts'}</b>
          <span>Severity</span>
          <b className={activeIncident?.severity === 'HIGH' ? 'danger' : 'warn'}>
            {activeIncident?.severity || 'Normal'}
          </b>
          <span>Age</span>
          <b>{activeIncident ? timeAgo(activeIncident.timestamp) : 'n/a'}</b>
          <span>Signals</span>
          <b>{activeIncident?.signalCount || 0}</b>
        </div>
      </section>

      <section className="ai-evidence-card">
        <div className="ai-section-label">Evidence</div>
        <div className="ai-evidence-list">
          <div>
            <span className="red" />
            <p>
              <b>{open.length}</b>
              <small>open incidents</small>
            </p>
          </div>
          <div>
            <span className="amber" />
            <p>
              <b>{anomalies.length}</b>
              <small>recent anomalies</small>
            </p>
          </div>
          <div>
            <span className="blue" />
            <p>
              <b>{latestAnomaly ? timeAgo(latestAnomaly.timestamp) : 'none'}</b>
              <small>latest signal age</small>
            </p>
          </div>
        </div>
      </section>

      <section className="ai-evidence-card">
        <div className="ai-section-label">Suggested Questions</div>
        <PromptGroups onSuggest={onSuggest} />
      </section>

      <div className="ai-cost-note">
        Advisor mode only. Recommendations stay explainable, auditable, and operator-approved.
      </div>
    </aside>
  );
}

export default function ChatView() {
  const [msgs, setMsgs] = useState([]);
  const [input, setInput] = useState('');
  const [mode, setMode] = useState('Investigate');
  const [busy, setBusy] = useState(false);
  const ctrlRef = useRef(null);
  const bottomRef = useRef(null);
  const inputRef = useRef(null);

  const accounts = useStore(s => s.accounts);
  const incidents = useStore(s => s.incidents);
  const anomalies = useStore(s => s.anomalies);
  const selectedAccountId = useStore(s => s.selectedAccountId);
  const lastRefreshed = useStore(s => s.lastRefreshed);

  const open = incidents.filter(i => i.status === 'OPEN');
  const criticalAccounts = accounts.filter(a => Number(a.score || 0) < 60);
  const avgScore = accounts.length
    ? Math.round(accounts.reduce((sum, a) => sum + Number(a.score || 0), 0) / accounts.length)
    : 0;
  const worstAccount = [...accounts].sort((a, b) => Number(a.score || 0) - Number(b.score || 0))[0];
  const worstStatus = statusForScore(worstAccount?.score);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [msgs, busy]);
  useEffect(() => { inputRef.current?.focus(); }, []);

  function handleSuggest(q) {
    setInput(q);
    inputRef.current?.focus();
  }

  const send = useCallback(async (override) => {
    const raw = (override || input).trim();
    if (!raw || busy) return;
    const text = `[${mode}] ${raw}`;
    setInput('');
    setMsgs(prev => [...prev, { role: 'user', content: raw, time: ts(), sources: [] }]);
    setBusy(true);
    ctrlRef.current = new AbortController();

    try {
      const res = await fetch(`${API_URL}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text, accountId: selectedAccountId }),
        signal: ctrlRef.current.signal,
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setMsgs(prev => [...prev, {
        role: 'assistant',
        content: data.answer || data.error || 'No response.',
        time: ts(),
        sources: data.sources || [],
      }]);
    } catch (e) {
      if (e.name !== 'AbortError') {
        setMsgs(prev => [...prev, {
          role: 'assistant',
          content: 'Could not reach AI SRE. Verify /chat API route is deployed and Bedrock model access is enabled.',
          time: ts(),
          sources: [],
        }]);
      }
    } finally {
      setBusy(false);
      ctrlRef.current = null;
    }
  }, [input, busy, mode, selectedAccountId]);

  function cancel() {
    ctrlRef.current?.abort();
    setBusy(false);
  }

  return (
    <div className="ai-investigation-shell">
      <main className="ai-investigation-main">
        <header className="ai-investigation-header">
          <div>
            <div className="ai-eyebrow">Intelligence Workspace</div>
            <h1>AI SRE Agent</h1>
            <p>Grounded triage across incidents, anomalies, account health, topology, logs, and runbooks.</p>
          </div>
          <button className="ai-clear-btn" onClick={() => setMsgs([])}>Clear</button>
        </header>

        <section className="ai-status-strip">
          <MetricCard label="Accounts" value={accounts.length} sub="monitored" />
          <MetricCard label="Open" value={open.length} tone={open.length ? 'danger' : 'ok'} sub="incidents" />
          <MetricCard label="Critical" value={criticalAccounts.length} tone={criticalAccounts.length ? 'warn' : 'ok'} sub="accounts" />
          <MetricCard label="Avg Health" value={avgScore || 0} tone={avgScore >= 80 ? 'ok' : avgScore >= 60 ? 'warn' : 'danger'} sub="score" />
          <div className="ai-focus-card">
            <span>Focus</span>
            <b style={{ color: worstStatus.color }}>{worstAccount?.accountId || 'No account data'}</b>
            <small>{worstAccount ? `${worstStatus.label} - score ${worstAccount.score}` : 'Waiting for telemetry'}</small>
          </div>
          <div className="ai-focus-card">
            <span>Freshness</span>
            <b>{lastRefreshed ? timeAgo(lastRefreshed.getTime()) : 'pending'}</b>
            <small>{anomalies.length} signals available</small>
          </div>
        </section>

        <section className="ai-workspace">
          <div className="ai-thread-panel">
            <div className="ai-thread-top">
              <div>
                <strong>Investigation Thread</strong>
                <span>Grounded responses from live telemetry, incidents, anomalies, and runbooks</span>
              </div>
              <div className="ai-mode-tabs" role="radiogroup" aria-label="AI mode">
                {['Investigate', 'Summarize', 'Runbook', 'Query Logs'].map(item => (
                  <button
                    key={item}
                    type="button"
                    role="radio"
                    aria-checked={mode === item}
                    className={mode === item ? 'active' : ''}
                    onClick={() => setMode(item)}
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>

            <div className="ai-thread">
              {msgs.length === 0 && !busy && <ChatWelcome onSuggest={handleSuggest} />}
              {msgs.map((m, i) => <Bubble key={i} msg={m} />)}
              {busy && <Typing onCancel={cancel} />}
              <div ref={bottomRef} />
            </div>

            <div className="ai-composer">
              <div className="ai-composer-box">
                <div className="ai-composer-tools">
                  <span>{mode}</span>
                  <span>{selectedAccountId || 'All accounts'}</span>
                  <span>{open.length} open incidents</span>
                </div>
                <textarea
                  ref={inputRef}
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      send();
                    }
                  }}
                  onInput={e => {
                    e.target.style.height = 'auto';
                    e.target.style.height = `${Math.min(e.target.scrollHeight, 118)}px`;
                  }}
                  placeholder={`Ask in ${mode.toLowerCase()} mode...`}
                  disabled={busy}
                  rows={1}
                />
                <div className="ai-composer-hint">Enter to send. Shift+Enter for a new line.</div>
              </div>
              <button onClick={() => send()} disabled={!input.trim() || busy} aria-label="Send message">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="22" y1="2" x2="11" y2="13" />
                  <polygon points="22 2 15 22 11 13 2 9 22 2" />
                </svg>
              </button>
            </div>
          </div>
        </section>
      </main>

      <EvidenceRail onSuggest={handleSuggest} />

      <style>{`
        @keyframes aiBounce {
          0%,60%,100% { transform: translateY(0); }
          30% { transform: translateY(-5px); }
        }
      `}</style>
    </div>
  );
}
