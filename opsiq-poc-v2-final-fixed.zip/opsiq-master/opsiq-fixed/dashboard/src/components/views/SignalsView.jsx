import { useStore } from '../../store.js';
export default function SignalsView() {
  const anomalies=useStore(s=>s.anomalies);
  const setView=useStore(s=>s.setView);
  return (
    <div className="content">
      <div className="breadcrumb"><a onClick={()=>setView('Dashboard')} style={{cursor:'pointer'}}>OpsIQ</a><svg viewBox="0 0 6 10" fill="none" stroke="currentColor" strokeWidth="1.5" width="6" height="10" strokeLinecap="round"><path d="M1 1l4 4-4 4"/></svg>Signal Feed</div>
      <div className="page-hdr"><div><h1 className="page-title">Signal Feed</h1><div className="page-desc">All inbound anomaly signals · Last {anomalies.length} events</div></div></div>
      <div className="panel"><div style={{overflowX:'auto'}}>
        <table className="aws-table">
          <thead><tr><th>Severity</th><th>Type</th><th>Account</th><th>Detail</th><th>Source</th><th>Time</th></tr></thead>
          <tbody>
            {anomalies.map((a,i)=>(
              <tr key={i}>
                <td><span className={`sev sev-${a.severity?.[0]||'L'}`}>{a.severity}</span></td>
                <td style={{fontFamily:'monospace',fontSize:11}}>{a.anomalyType}</td>
                <td style={{fontSize:12.5}}>{a.accountId}</td>
                <td style={{fontSize:12.5,color:'var(--text-2)',maxWidth:280}}>{a.description||a.logGroup||a.resource||'—'}</td>
                <td style={{fontSize:11,color:'var(--text-3)'}}>{a.source?.replace('opsiq.','')}</td>
                <td style={{fontFamily:'monospace',fontSize:11,color:'var(--text-3)'}}>{a.timestamp?new Date(Number(a.timestamp)).toLocaleTimeString():'—'}</td>
              </tr>
            ))}
            {anomalies.length===0&&<tr><td colSpan={6} className="empty-state">No signals in window.</td></tr>}
          </tbody>
        </table>
      </div></div>
    </div>
  );
}
