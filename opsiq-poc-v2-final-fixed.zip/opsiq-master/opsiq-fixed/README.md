# OpsIQ — AI-Powered Operational Intelligence Platform

A real-time AWS CloudOps dashboard with Bedrock AI incident analysis,
Bloom-filter anomaly detection, and WebSocket live updates.
Built for enterprise SRE teams to detect, correlate, and respond to
infrastructure incidents across multiple AWS accounts.

---

## Architecture Overview

```
13 Monitored Accounts (3 sim + 10 prod)
        │
        ▼
Kinesis log-stream → log-processor → Bloom filter (novel pattern detection)
                                   → log-volume-monitor (z-score spike detection)
                                   → log-pattern-tracker (known pattern rates)
                                           │
                                           ▼
                              SQS anomaly-events → correlator
                                           │
                              ┌────────────┴────────────┐
                              ▼                         ▼
                        HealthScores              IncidentRegistry
                        (DynamoDB)                (DynamoDB)
                              │                         │
                              ▼                         ▼
                       ws-broadcaster          ON-DEMAND only:
                              │              User clicks "Generate AI Summary"
                              ▼                         │
                        WebSocket                       ▼
                              │                  api-handler → Bedrock
                              ▼                  (cached in DynamoDB forever)
                      React Dashboard
                    (CloudFront + S3)
```

**Key design principle:** Bedrock is called ONLY when a human requests it.
No automatic AI calls on any schedule. Zero surprise Bedrock charges.

---

## Stack Layout

### Central (9 stacks — permanent)

| Stack | Name | Resources |
|---|---|---|
| 01 | `opsiq-central-storage` | S3 ×6, DynamoDB ×10 (all TTL-enabled), CloudFront |
| 02 | `opsiq-central-ingestion` | Kinesis, SQS ×3, EventBridge |
| 03 | `opsiq-central-iam` | IAM role + Bedrock wildcard policy |
| 04 | `opsiq-central-lambdas` | Lambda ×12, SQS event source mappings |
| 05 | `opsiq-central-api` | REST API Gateway + WebSocket API |
| 06 | `opsiq-central-dashboard` | WS endpoint injection, schedule activation, runbook index |
| 07 | `opsiq-central-log-anomaly` | log-volume-monitor + log-pattern-tracker Lambdas |
| 08 | `opsiq-central-fixes` | chat-handler + manual-seeder Lambdas |
| 09 | `opsiq-central-summariser` | incident-summariser Lambda (schedule DISABLED) |

### Simulation (3 stacks — POC only)

| Stack | Name | Resources |
|---|---|---|
| 01 | `opsiq-sim-data` | Seeder Lambda — seeds sim-app-a/b/c topology |
| 02 | `opsiq-sim-generators` | log-generator, metric-generator, anomaly-injector |
| 03 | `opsiq-sim-extended-accounts` | extended-seeder — seeds 10 prod accounts |

---

## Prerequisites

- **AWS CLI** configured for `us-west-2` commercial
- **Amazon Bedrock** model access enabled (see below)
- **Node.js 18+** (for dashboard build)
- **Git Bash** or bash-compatible shell on Windows

### Enable Bedrock Model Access

```
AWS Console → Amazon Bedrock → Model Access
→ Find "Claude Sonnet 4.6"
→ Deployment type: Serverless (Cross-region inference)
→ No request needed — available immediately
```

The model ID used: `us.anthropic.claude-haiku-4-5`

---

## Fresh Deployment — Step by Step

### Step 1 — Configure AWS CLI

```bash
aws configure
# AWS Access Key ID: <your key>
# AWS Secret Access Key: <your secret>
# Default region: us-west-2
# Default output format: json

# Verify
aws sts get-caller-identity
```

### Step 2 — Set environment variables

```bash
export REGION=us-west-2
export PROJECT=opsiq
# Optional: override Bedrock model
# export BEDROCK_MODEL=us.anthropic.claude-haiku-4-5  # cheaper
```

### Step 3 — Deploy everything (automated)

```bash
./scripts/deploy-all.sh
```

This runs all phases automatically (15-20 min):
- Deploys 9 central stacks
- Builds and uploads the dashboard
- Deploys 3 simulation stacks
- Seeds all 13 accounts with health scores and topology
- Prints the dashboard URL at the end

### Step 4 — Open the dashboard

Use the CloudFront URL printed at the end of deploy-all.sh.
The dashboard loads immediately with 13 accounts showing health scores.

---

## Manual Deployment (step by step)

If you prefer to deploy in stages:

### Phase 1 — Central stacks

```bash
export REGION=us-west-2
cd central/scripts
./deploy-central.sh
```

This deploys stacks 1-9, packages all Lambdas, uploads runbooks,
and wires the /chat API Gateway route automatically.

### Phase 2 — Dashboard

```bash
cd dashboard
./rebuild.sh
# Auto-reads API IDs from CloudFormation
# Builds React app with correct endpoints
# Uploads to S3 and prints CloudFront URL
```

Invalidate CloudFront after upload:
```bash
CF_ID=$(aws cloudformation describe-stacks \
  --stack-name opsiq-central-storage --region us-west-2 \
  --query "Stacks[0].Outputs[?OutputKey=='DashboardDistributionId'].OutputValue" \
  --output text)

aws cloudfront create-invalidation \
  --distribution-id $CF_ID \
  --paths "/*"
```

### Phase 3 — Simulation

```bash
cd simulation/scripts
./deploy-simulation.sh
```

Deploys 3 stacks and seeds all 13 accounts immediately.

---

## Demo Runbook

### Start a demo session

```bash
./scripts/demo-on.sh
```

Enables all signal generators. Wait 2 minutes for signals to flow.

### Trigger a specific incident scenario

```bash
aws lambda invoke \
  --function-name opsiq-sim-anomaly-injector \
  --payload '{"scenario": "ecs-oom", "accountId": "sim-app-a"}' \
  --region us-west-2 \
  response.json && cat response.json
```

**Available scenarios:**

| Scenario | Account | What happens |
|---|---|---|
| `ecs-oom` | sim-app-a | ECS OOM → ALB 5xx → connection leak |
| `api-latency` | sim-app-b | Lambda timeout → DynamoDB throttle |
| `rds-exhaustion` | sim-app-a | RDS connections exhausted → cascade |
| `novel-pattern` | sim-app-c | Redis failure → novel log patterns |

### Generate AI summary (on-demand)

1. Open dashboard → click Incidents in sidebar
2. Click any HIGH incident row
3. Click **"✦ Generate AI Summary"** button
4. Bedrock called once → result cached permanently

### End demo session

```bash
./scripts/demo-off.sh
```

Disables signal generation and purges SQS queues.
Health scores remain visible. Zero ongoing Bedrock cost.

---

## Cost Control

### Bedrock charges

| Action | Cost |
|---|---|
| "Generate AI Summary" button click | ~$0.002 |
| Chat panel message | ~$0.001 |
| Automatic calls | $0 (none configured) |
| 30-min demo session | ~$0.05 |

### Monthly estimates

| Mode | Cost |
|---|---|
| Dashboard only (no signals) | ~$5-10/month |
| Signals enabled, no Bedrock | ~$25-40/month |
| Active demo days (2-3/week) | ~$50-80/month |

### Budget alert (set this now)

```
AWS Console → Billing → Budgets → Create Budget
→ Service: Amazon Bedrock
→ Monthly: $20
→ Alert at 80% → your email
```

---

## Account Fleet

### Simulation accounts (always critical — demo traffic)

| Account | Score | Stack |
|---|---|---|
| sim-app-a | ~34 | ECS · ALB · Aurora PostgreSQL |
| sim-app-b | ~61 | Lambda · APIGW · DynamoDB |
| sim-app-c | ~28 | ECS · ALB · ElastiCache Redis |

### Extended production accounts

| Account | Score | Stack |
|---|---|---|
| prod-payments | 92 | ECS · ALB · Aurora · ACM |
| prod-storage | 95 | S3 · CloudFront · Lambda |
| prod-identity | 88 | Lambda · API GW · DDB · WAF |
| prod-reporting | 85 | EC2 ASG · ALB · RDS PostgreSQL |
| prod-search | 83 | ALB · EC2 · OpenSearch |
| prod-notifications | 81 | SQS · Lambda · SES · SNS |
| prod-api-gw | 78 | API GW · Lambda · DDB · CloudFront |
| prod-checkout | 58 | ECS · ALB · Aurora (high latency) |
| prod-cms | 52 | ALB · EC2 · RDS MySQL (disk space) |
| prod-integrations | 31 | API GW · Lambda · DDB (throttling) |

---

## Updating Individual Lambdas

When you change a Lambda function:

```bash
ACCOUNT_ID=615299738349
REGION=us-west-2
BUCKET=opsiq-lambda-pkgs-${ACCOUNT_ID}
LAMBDA=api_handler   # change this

aws s3 cp central/lambdas/${LAMBDA}.zip \
  s3://${BUCKET}/central/${LAMBDA}.zip --region $REGION

aws lambda update-function-code \
  --function-name opsiq-${LAMBDA//_/-} \
  --s3-bucket ${BUCKET} \
  --s3-key central/${LAMBDA}.zip \
  --region $REGION \
  --query 'LastModified' --output text
```

---

## Switching Bedrock Models

Update the environment variable on 3 Lambdas:

```bash
# Cheaper option (~7x less than Sonnet)
MODEL=us.anthropic.claude-haiku-4-5

# Or back to Sonnet
MODEL=us.anthropic.claude-haiku-4-5

for FUNC in opsiq-chat-handler opsiq-api-handler opsiq-incident-summariser; do
  aws lambda update-function-configuration \
    --function-name $FUNC \
    --environment "Variables={BEDROCK_MODEL_ID=${MODEL},PROJECT_NAME=opsiq,REGION=us-west-2,INCIDENT_TABLE=opsiq-IncidentRegistry,ANOMALY_TABLE=opsiq-AnomalyHistory,HEALTH_TABLE=opsiq-HealthScores,TOPOLOGY_BUCKET=opsiq-topology-${ACCOUNT_ID},RUNBOOKS_BUCKET=opsiq-runbooks-${ACCOUNT_ID},RUNBOOK_INDEX_TABLE=opsiq-RunbookIndex}" \
    --region us-west-2 \
    --query 'LastModified' --output text
  echo "Updated: $FUNC"
done
```

---

## Teardown

### Remove simulation only (keep dashboard + central)

```bash
cd simulation/scripts
./teardown-simulation.sh
```

### Remove everything

```bash
./scripts/teardown-all.sh
# Type 'delete-everything' to confirm
```

---

## Troubleshooting

### Dashboard shows ERR_NAME_NOT_RESOLVED
API IDs changed after a stack redeploy. Rebuild the dashboard:
```bash
cd dashboard && ./rebuild.sh
```
Then invalidate CloudFront `/*`.

### Health scores showing 0
Re-seed the accounts:
```bash
aws lambda invoke --function-name opsiq-extended-seeder --region us-west-2 out.json
aws lambda invoke --function-name opsiq-manual-seeder --region us-west-2 out.json
```

### Chat returns 500
Check Lambda logs:
```bash
aws logs tail /aws/lambda/opsiq-chat-handler --region us-west-2 --since 10m
```
Most likely cause: Bedrock IAM permission missing. Run:
```bash
aws iam put-role-policy \
  --role-name opsiq-lambda-execution-role \
  --policy-name opsiq-bedrock-inline \
  --policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":["bedrock:InvokeModel","bedrock:InvokeModelWithResponseStream"],"Resource":"*"}]}'
```

### Topology not showing
Click an account card on the dashboard first — topology loads on demand.
If still empty, check S3:
```bash
aws s3 ls s3://opsiq-topology-615299738349/ --region us-west-2
```

### WebSocket not connecting
Re-deploy stack 6 to re-inject the WS endpoint:
```bash
aws cloudformation deploy \
  --template-file central/cloudformation/06-dashboard.yaml \
  --stack-name opsiq-central-dashboard \
  --capabilities CAPABILITY_IAM --region us-west-2
```

### Bedrock AccessDeniedException
Add the inline IAM policy shown in the Chat 500 fix above.
Also verify the model ID uses the `us.` prefix:
```bash
aws lambda get-function-configuration \
  --function-name opsiq-chat-handler --region us-west-2 \
  --query 'Environment.Variables.BEDROCK_MODEL_ID' --output text
# Should print: us.anthropic.claude-haiku-4-5
```
