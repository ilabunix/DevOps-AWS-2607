#!/bin/bash
REGION=us-west-2
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)

aws cloudformation delete-stack \
  --stack-name opsiq-sim-extended-accounts --region $REGION

echo "Removing account data from DynamoDB and S3..."
for ACC in prod-payments prod-identity prod-reporting prod-api-gw prod-storage \
           prod-notifications prod-search prod-checkout prod-cms prod-integrations; do
  aws dynamodb delete-item \
    --table-name opsiq-HealthScores \
    --key "{\"accountId\":{\"S\":\"${ACC}\"}}" \
    --region $REGION 2>/dev/null && echo "  Removed: $ACC" || true
  aws s3 rm s3://opsiq-topology-${ACCOUNT_ID}/${ACC}/ \
    --recursive --quiet --region $REGION 2>/dev/null || true
done
echo "Done."
