#!/bin/bash
# Deploy the 10 extended simulation accounts
# Run AFTER all main stacks (01-08) are deployed

set -e

REGION=us-west-2
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
BUCKET=opsiq-lambda-pkgs-${ACCOUNT_ID}

echo "Uploading extended seeder Lambda..."
aws s3 cp simulation/lambdas/extended_seeder.zip \
  s3://${BUCKET}/simulation/extended_seeder.zip --region $REGION

echo "Deploying extended accounts stack..."
aws cloudformation deploy \
  --template-file simulation/cloudformation/03-extended-accounts.yaml \
  --stack-name opsiq-sim-extended-accounts \
  --parameter-overrides ProjectName=opsiq LambdaCodeBucket=${BUCKET} \
  --capabilities CAPABILITY_IAM \
  --region $REGION

echo ""
echo "Invoking seeder to populate accounts immediately..."
aws lambda invoke \
  --function-name opsiq-extended-seeder \
  --region $REGION \
  out.json && cat out.json

echo ""
echo "Done! Refresh the dashboard — 10 new accounts should appear."
