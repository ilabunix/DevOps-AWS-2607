#!/usr/bin/env bash
# opsiq-poc/simulation/scripts/deploy-simulation.sh
# Deploys all 3 simulation stacks. Central must be fully deployed first.
#
# Usage:
#   export REGION=us-west-2
#   ./deploy-simulation.sh

set -euo pipefail

PROJECT="${PROJECT:-opsiq}"
REGION="${REGION:-us-west-2}"
CFN_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../cloudformation" && pwd)"
LAMBDA_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../lambdas" && pwd)"
DEPLOY_FLAGS="--region $REGION --no-fail-on-empty-changeset"

echo "╔══════════════════════════════════════════════════╗"
echo "║  OpsIQ Simulation — Deploy (3 stacks)           ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""

# Verify central storage stack is deployed
echo "Verifying central stacks are deployed..."
aws cloudformation describe-stacks \
  --stack-name "${PROJECT}-central-storage" --region "$REGION" \
  --query 'Stacks[0].StackStatus' --output text | grep -q "COMPLETE" \
  || { echo "ERROR: Central stacks not found. Run deploy-central.sh first."; exit 1; }
echo "  ✓ Central stacks confirmed"
echo ""

ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
LAMBDA_CODE_BUCKET="${LAMBDA_CODE_BUCKET:-${PROJECT}-lambda-pkgs-${ACCOUNT_ID}}"

# Package simulation Lambdas
echo "Step 0/3 — Package and upload simulation Lambda functions"
bash "$LAMBDA_DIR/package.sh" "$LAMBDA_CODE_BUCKET"
echo ""

# Stack 1 — Seed data (sim-app-a/b/c topology)
echo "Step 1/3 — Seed sim-app-a/b/c topology data"
aws cloudformation deploy \
  --template-file "$CFN_DIR/01-sim-data.yaml" \
  --stack-name "${PROJECT}-sim-data" \
  --parameter-overrides \
    ProjectName="$PROJECT" \
    LambdaCodeBucket="$LAMBDA_CODE_BUCKET" \
  --capabilities CAPABILITY_IAM \
  $DEPLOY_FLAGS
echo "  ✓ Sim data seeded (sim-app-a, sim-app-b, sim-app-c)"
echo ""

# Stack 2 — Signal generators
echo "Step 2/3 — Deploy log/metric generators and anomaly injector"
aws cloudformation deploy \
  --template-file "$CFN_DIR/02-sim-generators.yaml" \
  --stack-name "${PROJECT}-sim-generators" \
  --parameter-overrides \
    ProjectName="$PROJECT" \
    LambdaCodeBucket="$LAMBDA_CODE_BUCKET" \
  --capabilities CAPABILITY_NAMED_IAM \
  $DEPLOY_FLAGS
echo "  ✓ Simulation generators deployed"
echo ""

# Stack 3 — Extended enterprise accounts (10 prod accounts)
echo "Step 3/3 — Deploy extended enterprise accounts (10 accounts)"
aws cloudformation deploy \
  --template-file "$CFN_DIR/03-extended-accounts.yaml" \
  --stack-name "${PROJECT}-sim-extended-accounts" \
  --parameter-overrides \
    ProjectName="$PROJECT" \
    LambdaCodeBucket="$LAMBDA_CODE_BUCKET" \
  --capabilities CAPABILITY_IAM \
  $DEPLOY_FLAGS
echo "  ✓ Extended accounts stack deployed"
echo ""

# Invoke seeders immediately
echo "Seeding accounts..."
aws lambda invoke \
  --function-name "${PROJECT}-manual-seeder" \
  --region "$REGION" /tmp/seed1.json > /dev/null 2>&1 \
  && echo "  ✓ sim-app-a/b/c seeded" || echo "  - manual-seeder not found (run after stack 8)"

aws lambda invoke \
  --function-name "${PROJECT}-extended-seeder" \
  --region "$REGION" /tmp/seed2.json > /dev/null 2>&1 \
  && echo "  ✓ Extended accounts seeded" || echo "  - extended-seeder not found"

# Enable safe schedules
echo ""
echo "Enabling schedules..."
for RULE in \
  "${PROJECT}-health-schedule" \
  "${PROJECT}-extended-seeder-schedule"; do
  aws events enable-rule --name "$RULE" --region "$REGION" 2>/dev/null \
    && echo "  ✓ Enabled: $RULE" || echo "  - Not found: $RULE"
done

INJECTOR_NAME="${PROJECT}-sim-anomaly-injector"

echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║  Simulation Deployed                             ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║  3 sim accounts  : sim-app-a, sim-app-b, sim-app-c"
echo "║  10 prod accounts: prod-payments, prod-identity,"
echo "║                    prod-reporting, prod-api-gw,"
echo "║                    prod-storage, prod-notifications,"
echo "║                    prod-search, prod-checkout,"
echo "║                    prod-cms, prod-integrations"
echo "║"
echo "║  For live signals, run demo-on.sh"
echo "║  Then trigger a scenario:"
echo "╚══════════════════════════════════════════════════╝"
echo ""
echo "  aws lambda invoke \\"
echo "    --function-name $INJECTOR_NAME \\"
echo "    --payload '{\"scenario\": \"ecs-oom\", \"accountId\": \"sim-app-a\"}' \\"
echo "    --region $REGION response.json && cat response.json"
echo ""
echo "Available scenarios: ecs-oom | api-latency | rds-exhaustion | novel-pattern"
