"""
OpsIQ Simulation — log_generator.py v2
Rich realistic logs per account personality.
Normal mode: healthy baseline with real-looking access logs and metrics.
Anomaly mode: escalating cascade matching the injected scenario.
"""
import json, os, random, time, uuid
import boto3
from botocore.exceptions import ClientError

LOG_STREAM_NAME = os.environ['LOG_STREAM_NAME']
MODE_TABLE      = os.environ['MODE_TABLE']
PROJECT         = os.environ['PROJECT_NAME']

kinesis = boto3.client('kinesis')
ddb     = boto3.resource('dynamodb')
m_tbl   = ddb.Table(MODE_TABLE)

# sim-app-a: Payment Processing Service (ECS + ALB + Aurora PostgreSQL)
SIM_APP_A_NORMAL = [
    ('INFO', '/aws/ecs/sim-app-a-api',
        'POST /api/v1/payments 200 {dur}ms txn_id={txn} amount=${amt} gateway=VISA auth={auth}'),
    ('INFO', '/aws/ecs/sim-app-a-api',
        'POST /api/v1/payments 200 {dur}ms txn_id={txn} amount=${amt} gateway=MASTERCARD auth={auth}'),
    ('INFO', '/aws/ecs/sim-app-a-api',
        'GET /api/v1/payments/{txn}/status 200 {fast}ms'),
    ('INFO', '/aws/ecs/sim-app-a-api',
        'HikariCP pool stats: active={pool_active} idle={pool_idle} waiting=0 max=100 created={pool_total}'),
    ('INFO', '/aws/ecs/sim-app-a-api',
        'GET /health 200 {fast}ms db=OK pool=OK'),
    ('INFO', '/aws/lambda/sim-app-a-payment-processor',
        'REPORT RequestId:{req} Duration:{dur}ms Billed:{billed}ms MemorySize:512MB MaxMemoryUsed:{mem}MB'),
    ('INFO', '/aws/lambda/sim-app-a-payment-processor',
        'Payment gateway response: APPROVED auth_code={auth} network=VISA response_ms={dur}'),
    ('INFO', '/aws/lambda/sim-app-a-payment-processor',
        'Fraud score: {score}/100 (PASS) customer_id={cust} amount=${amt}'),
    ('WARN', '/aws/ecs/sim-app-a-api',
        'Slow query: SELECT * FROM transactions WHERE customer_id=? AND status=? duration={slow}ms plan=FULL_SCAN rows_examined=48291'),
    ('WARN', '/aws/rds/sim-app-a-postgres',
        'checkpoint warning: checkpoints occurring too frequently ({n} in 300s). Consider increasing checkpoint_completion_target.'),
]

SIM_APP_A_ANOMALY = [
    ('ERROR', '/aws/ecs/sim-app-a-api',
        'java.lang.OutOfMemoryError: Java heap space\n\tat com.payments.TransactionProcessor.processPayment(TransactionProcessor.java:287)\n\tat com.payments.TransactionProcessor.handleBatch(TransactionProcessor.java:156)\nCaused by: java.lang.OutOfMemoryError: GC overhead limit exceeded'),
    ('ERROR', '/aws/ecs/sim-app-a-api',
        'FATAL: ECS task memory limit exceeded. Limit:2048MB Used:2049MB. Container will be terminated and replaced.'),
    ('ERROR', '/aws/ecs/sim-app-a-api',
        'HikariCP connection leak detected: connection held {held}s without return to pool (leakDetectionThreshold=30000ms)'),
    ('ERROR', '/aws/ecs/sim-app-a-api',
        'POST /api/v1/payments 502 Bad Gateway upstream=sim-app-a-api-ecs:8080 reason=target_unhealthy'),
    ('ERROR', '/aws/ecs/sim-app-a-api',
        'ECS health check failed attempt 3/3: GET /health returned HTTP 503 after {dur}ms. Marking task UNHEALTHY.'),
    ('ERROR', '/aws/rds/sim-app-a-postgres',
        'FATAL: remaining connection slots reserved for superuser (max_connections=100 active={active})'),
    ('ERROR', '/aws/rds/sim-app-a-postgres',
        'ERROR: connection limit exceeded for database "payments" — current={active}/100 from {ip}'),
    ('ERROR', '/aws/lambda/sim-app-a-payment-processor',
        'Runtime.ExitError RequestId:{req} Process exited before completing request (signal:SIGKILL oom-killer)'),
    ('WARN',  '/aws/ecs/sim-app-a-api',
        'GC overhead limit exceeded — application spent >98pct time in GC. Heap: used=1998MB max=2048MB'),
]

# sim-app-b: User API Service (Lambda + API Gateway + DynamoDB)
SIM_APP_B_NORMAL = [
    ('INFO', '/aws/lambda/sim-app-b-handler',
        'START RequestId:{req} Version:$LATEST'),
    ('INFO', '/aws/lambda/sim-app-b-handler',
        'GET /users/{uid} 200 {dur}ms cache=MISS rcus=1.5 table=sim-app-b-users'),
    ('INFO', '/aws/lambda/sim-app-b-handler',
        'GET /users/{uid} 200 {fast}ms cache=HIT'),
    ('INFO', '/aws/lambda/sim-app-b-handler',
        'POST /users/{uid}/preferences 201 {dur}ms wcus=2.0 item_size=847B'),
    ('INFO', '/aws/lambda/sim-app-b-handler',
        'REPORT RequestId:{req} Duration:{dur}ms Billed:{billed}ms Memory:256MB Used:{mem}MB'),
    ('INFO', '/aws/lambda/sim-app-b-handler',
        'DynamoDB BatchGetItem: {n} items {dur}ms rcus=12.5 table=sim-app-b-users'),
    ('INFO', '/aws/apigateway/sim-app-b',
        'method=GET resource=/users/{uid} status=200 latency={dur}ms requestId={req} ip={ip}'),
    ('WARN', '/aws/lambda/sim-app-b-handler',
        'DynamoDB read throttled table=sim-app-b-sessions — retrying backoff attempt=1/3 delay=50ms'),
    ('WARN', '/aws/lambda/sim-app-b-handler',
        'Cold start detected: init={cold}ms runtime=nodejs18.x. Consider provisioned concurrency.'),
]

SIM_APP_B_ANOMALY = [
    ('ERROR', '/aws/lambda/sim-app-b-handler',
        'Task timed out after 15.00 seconds RequestId:{req}'),
    ('ERROR', '/aws/lambda/sim-app-b-handler',
        'Task timed out after 15.00 seconds RequestId:{req}'),
    ('ERROR', '/aws/lambda/sim-app-b-handler',
        'ProvisionedThroughputExceededException: table=sim-app-b-users consumed={rcus} provisioned=100 throttled_requests_last_60s={n}'),
    ('ERROR', '/aws/lambda/sim-app-b-handler',
        'GET /users/{uid} 504 — Lambda execution exceeded API Gateway 29s integration timeout'),
    ('ERROR', '/aws/apigateway/sim-app-b',
        'method=GET resource=/users/{uid} status=504 error=IntegrationTimeout latency=29000ms requestId={req}'),
    ('ERROR', '/aws/lambda/sim-app-b-handler',
        'Unhandled Promise rejection: ReadTimeout — DynamoDB did not respond within 15000ms'),
    ('WARN',  '/aws/lambda/sim-app-b-handler',
        'DynamoDB throttled max retries exceeded table=sim-app-b-sessions. Returning HTTP 503 to client.'),
]

# sim-app-c: Customer Web Application (ECS + ALB + ElastiCache Redis)
SIM_APP_C_NORMAL = [
    ('INFO', '/aws/ecs/sim-app-c-web',
        'GET /dashboard 200 {fast}ms cache=HIT session={sess}'),
    ('INFO', '/aws/ecs/sim-app-c-web',
        'GET /dashboard 200 {dur}ms cache=MISS session={sess} db_query={slow}ms'),
    ('INFO', '/aws/ecs/sim-app-c-web',
        'POST /auth/login 200 {dur}ms user_id={uid} mfa=TOTP session_created={sess}'),
    ('INFO', '/aws/ecs/sim-app-c-web',
        'Redis INFO: connected_clients=42 used_memory=128mb hit_rate={pct}pct evicted_keys=0'),
    ('INFO', '/aws/ecs/sim-app-c-web',
        'Redis INFO: connected_clients=38 used_memory=131mb hit_rate={pct}pct evicted_keys=0'),
    ('INFO', '/aws/ecs/sim-app-c-web',
        'GET /health 200 {fast}ms redis=OK upstream=OK'),
    ('INFO', '/aws/ecs/sim-app-c-web',
        'GET /reports/{rid} 200 {dur}ms cache=HIT user_id={uid}'),
    ('WARN', '/aws/ecs/sim-app-c-web',
        'Redis latency spike: {slow}ms p99 (threshold=50ms) — single keyspace hotspot suspected key=/session/*'),
    ('WARN', '/aws/ecs/sim-app-c-web',
        'Session store write degraded: {slow}ms for sess={sess} — Redis memory pressure (used=131MB/maxmemory=256MB)'),
]

SIM_APP_C_ANOMALY = [
    ('ERROR', '/aws/ecs/sim-app-c-web',
        'ECONNREFUSED connect to 127.0.0.1:6379 (Redis) — cache unavailable. Falling back to database queries.'),
    ('ERROR', '/aws/ecs/sim-app-c-web',
        'ECONNREFUSED connect to 127.0.0.1:6379 (Redis) — cache unavailable. Falling back to database queries.'),
    ('ERROR', '/aws/ecs/sim-app-c-web',
        'Redis CLUSTERDOWN: Not enough reachable nodes to form cluster (found 0/1 required). All cache reads failing.'),
    ('ERROR', '/aws/ecs/sim-app-c-web',
        'GET /dashboard 500 — session lookup failed: Redis connection refused after 3 retries'),
    ('ERROR', '/aws/ecs/sim-app-c-web',
        'GET /dashboard 500 — session lookup failed: Redis connection refused after 3 retries'),
    ('ERROR', '/aws/ecs/sim-app-c-web',
        'Cache stampede: {n} concurrent requests hitting database (Redis down). DB query rate +847pct above baseline.'),
    ('ERROR', '/aws/ecs/sim-app-c-web',
        'ECS health check failed: GET /health returned 500 redis=FAIL (attempt 3/3). Task marked UNHEALTHY.'),
    ('WARN',  '/aws/ecs/sim-app-c-web',
        'Session store unavailable — ~{n} active sessions will be invalidated on next request.'),
    ('WARN',  '/aws/ecs/sim-app-c-web',
        'Database read load +{pct}pct above baseline — Redis miss fallthrough causing read spike on Aurora reader'),
]

NORMAL_LOGS  = {'sim-app-a': SIM_APP_A_NORMAL,  'sim-app-b': SIM_APP_B_NORMAL,  'sim-app-c': SIM_APP_C_NORMAL}
ANOMALY_LOGS = {'sim-app-a': SIM_APP_A_ANOMALY, 'sim-app-b': SIM_APP_B_ANOMALY, 'sim-app-c': SIM_APP_C_ANOMALY}

def _vals():
    return dict(
        dur=random.randint(45, 280),
        fast=random.randint(8, 35),
        slow=random.randint(300, 1800),
        billed=random.randint(50, 300),
        cold=random.randint(180, 620),
        mem=random.randint(80, 220),
        txn=str(uuid.uuid4())[:8].upper(),
        req=str(uuid.uuid4()),
        sess=str(uuid.uuid4())[:12],
        uid=random.randint(10000, 99999),
        cust=f'cust_{random.randint(1000,9999)}',
        amt=f'{random.randint(5,2500)}.{random.randint(0,99):02d}',
        auth=str(random.randint(100000, 999999)),
        score=random.randint(2, 28),
        ip=f'10.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}',
        n=random.randint(1, 50),
        pct=random.randint(78, 94),
        hits=random.randint(800, 2000),
        misses=random.randint(50, 200),
        rid=str(uuid.uuid4())[:8],
        held=random.randint(35, 90),
        active=random.randint(92, 99),
        rcus=random.randint(120, 350),
        pool_active=random.randint(12, 28),
        pool_idle=random.randint(5, 15),
        pool_total=random.randint(20, 40),
    )

def _render(template):
    try:
        return template.format(**_vals())
    except Exception:
        return template

def _get_mode(account_id):
    try:
        resp = m_tbl.get_item(Key={'accountId': account_id})
        return resp.get('Item', {}).get('mode', 'normal')
    except ClientError:
        return 'normal'

def handler(event, _context):
    accounts = ['sim-app-a', 'sim-app-b', 'sim-app-c']
    total    = 0

    for account_id in accounts:
        mode      = _get_mode(account_id)
        templates = ANOMALY_LOGS.get(account_id, []) if mode == 'anomaly' \
                    else NORMAL_LOGS.get(account_id, [])
        if not templates:
            continue

        count  = random.randint(4, 8) if mode == 'normal' else random.randint(8, 14)
        events = []
        for _ in range(count):
            level, log_group, tmpl = random.choice(templates)
            events.append({
                'logGroup':  log_group,
                'timestamp': int(time.time() * 1000),
                'level':     level,
                'message':   _render(tmpl),
            })

        # Group by log group — one Kinesis record per group
        by_group = {}
        for e in events:
            by_group.setdefault(e['logGroup'], []).append(e)

        for log_group, group_events in by_group.items():
            kinesis.put_record(
                StreamName=LOG_STREAM_NAME,
                Data=json.dumps({
                    'accountId':  account_id,
                    'logGroup':   log_group,
                    'logEvents':  group_events,
                    'eventCount': len(group_events),
                    'source':     'opsiq.simulation.logs',
                    'mode':       mode,
                }).encode(),
                PartitionKey=account_id,
            )
            total += len(group_events)

    print(f'log_generator | events={total}')
    return {'totalEvents': total}
