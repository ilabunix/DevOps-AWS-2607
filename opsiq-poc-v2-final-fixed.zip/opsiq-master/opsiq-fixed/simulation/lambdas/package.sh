#!/usr/bin/env bash
# opsiq-poc/simulation/lambdas/package.sh
# Packages all simulation Lambda functions into ZIPs and uploads to S3.
# Works on Git Bash (Windows), macOS, and Linux.
#
# Usage: ./package.sh <lambda-code-bucket>
# Example: ./package.sh opsiq-lambda-pkgs-615299738349

set -euo pipefail

BUCKET="${1:?Usage: ./package.sh <lambda-code-bucket>}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REGION="${REGION:-us-west-2}"
BUILD_DIR="$SCRIPT_DIR/_build"

mkdir -p "$BUILD_DIR"

echo "╔══════════════════════════════════════════════════╗"
echo "║  OpsIQ — Packaging Simulation Lambda Functions  ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║  Source : $SCRIPT_DIR"
echo "║  Bucket : s3://$BUCKET/simulation/"
echo "╚══════════════════════════════════════════════════╝"
echo ""

FUNCTIONS=(
  "seeder"
  "extended_seeder"
  "manual_seeder"
  "metric_generator"
  "log_generator"
  "anomaly_injector"
)

for FN in "${FUNCTIONS[@]}"; do
  echo "  Packaging: $FN"

  PYSCRIPT="$BUILD_DIR/pack.py"
  cat > "$PYSCRIPT" << PYEOF
import zipfile, sys
src  = sys.argv[1]
dst  = sys.argv[2]
name = sys.argv[3]
with zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED) as z:
    z.write(src, name)
PYEOF

  python "$PYSCRIPT" \
    "$SCRIPT_DIR/${FN}.py" \
    "$BUILD_DIR/${FN}.zip" \
    "${FN}.py"

  aws s3 cp "$BUILD_DIR/${FN}.zip" "s3://$BUCKET/simulation/${FN}.zip" --quiet
  echo "  Uploaded: s3://$BUCKET/simulation/${FN}.zip"
done

rm -rf "$BUILD_DIR"

echo ""
echo "==> Simulation Lambda packaging complete (${#FUNCTIONS[@]} functions)"
