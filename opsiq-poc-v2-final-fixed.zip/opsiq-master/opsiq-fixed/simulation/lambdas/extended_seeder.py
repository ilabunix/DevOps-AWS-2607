"""
OpsIQ — Extended Simulation Accounts Seeder
Adds 10 new realistic accounts to the dashboard without touching existing stacks.
Run directly with: python3 opsiq-sim-accounts.py
Or deploy as Lambda and invoke.

Accounts added:
  Healthy (7): prod-payments, prod-identity, prod-reporting, prod-api-gw,
               prod-storage, prod-notifications, prod-search
  Warning (2): prod-checkout, prod-cms  
  Critical(1): prod-integrations
"""
import json
import random
import time
import boto3

REGION     = 'us-west-2'
PROJECT    = 'opsiq'
ACCOUNT_ID = boto3.client('sts', region_name=REGION).get_caller_identity()['Account']

ddb     = boto3.resource('dynamodb', region_name=REGION)
s3      = boto3.client('s3', region_name=REGION)
kinesis = boto3.client('kinesis', region_name=REGION)
sqs     = boto3.client('sqs', region_name=REGION)

HEALTH_TABLE    = f'{PROJECT}-HealthScores'
TOPOLOGY_BUCKET = f'{PROJECT}-topology-{ACCOUNT_ID}'

# ── Account definitions ───────────────────────────────────────────────────────

ACCOUNTS = [
  # ── HEALTHY ──────────────────────────────────────────────────────────────────
  {
    'accountId': 'prod-payments',
    'score': 92,
    'stack': 'ECS · ALB · Aurora · ACM',
    'topology': {
      'nodes': [
        {'id': 'acm-cert',        'label': 'payments.acme.com', 'type': 'aws_acm_certificate',    'tier': 'ingress'},
        {'id': 'alb-payments',    'label': 'payments-alb',      'type': 'aws_alb',                'tier': 'ingress'},
        {'id': 'ecs-cluster',     'label': 'payments-cluster',  'type': 'aws_ecs_cluster',        'tier': 'compute'},
        {'id': 'ecs-api',         'label': 'payments-api',      'type': 'aws_ecs_service',        'tier': 'compute'},
        {'id': 'aurora-cluster',  'label': 'payments-aurora',   'type': 'aws_rds_cluster',        'tier': 'data'},
        {'id': 'aurora-writer',   'label': 'aurora-writer',     'type': 'aws_rds_cluster_instance','tier': 'data'},
        {'id': 'aurora-reader',   'label': 'aurora-reader',     'type': 'aws_rds_cluster_instance','tier': 'data'},
        {'id': 'secrets',         'label': 'db-credentials',    'type': 'aws_secretsmanager_secret','tier': 'storage'},
      ],
      'edges': [
        {'source': 'acm-cert',       'target': 'alb-payments'},
        {'source': 'alb-payments',   'target': 'ecs-api'},
        {'source': 'ecs-api',        'target': 'aurora-cluster'},
        {'source': 'aurora-cluster', 'target': 'aurora-writer'},
        {'source': 'aurora-cluster', 'target': 'aurora-reader'},
        {'source': 'ecs-api',        'target': 'secrets'},
      ]
    },
    'logs': [
      ('INFO',  '/aws/ecs/payments-api', 'POST /api/v2/payments 200 {dur}ms txn_id={txn} amount=${amt} gateway=STRIPE auth={auth}'),
      ('INFO',  '/aws/ecs/payments-api', 'GET /api/v2/payments/{txn}/status 200 {fast}ms'),
      ('INFO',  '/aws/ecs/payments-api', 'GET /health 200 {fast}ms aurora=OK secrets=OK cert_days=87'),
      ('INFO',  '/aws/ecs/payments-api', 'Aurora connection pool: active={pool_active}/50 idle={pool_idle} writer_lag=0ms'),
      ('INFO',  '/aws/ecs/payments-api', 'POST /api/v2/refunds 200 {dur}ms refund_id={txn} original_txn={auth}'),
      ('WARN',  '/aws/ecs/payments-api', 'Slow Aurora query: SELECT * FROM payment_intents WHERE customer_id=? duration={slow}ms plan=INDEX_SCAN'),
    ]
  },
  {
    'accountId': 'prod-identity',
    'score': 88,
    'stack': 'Lambda · API GW · DynamoDB · WAF',
    'topology': {
      'nodes': [
        {'id': 'waf',         'label': 'identity-waf',    'type': 'aws_wafv2_web_acl',       'tier': 'ingress'},
        {'id': 'apigw',       'label': 'identity-api',    'type': 'aws_apigatewayv2_api',    'tier': 'ingress'},
        {'id': 'auth-fn',     'label': 'auth-handler',    'type': 'aws_lambda_function',     'tier': 'compute'},
        {'id': 'token-fn',    'label': 'token-handler',   'type': 'aws_lambda_function',     'tier': 'compute'},
        {'id': 'users-table', 'label': 'identity-users',  'type': 'aws_dynamodb_table',      'tier': 'data'},
        {'id': 'sessions-table','label':'identity-sessions','type':'aws_dynamodb_table',     'tier': 'data'},
        {'id': 'kms-key',     'label': 'token-signing-key','type': 'aws_kms_key',            'tier': 'storage'},
      ],
      'edges': [
        {'source': 'waf',          'target': 'apigw'},
        {'source': 'apigw',        'target': 'auth-fn'},
        {'source': 'apigw',        'target': 'token-fn'},
        {'source': 'auth-fn',      'target': 'users-table'},
        {'source': 'token-fn',     'target': 'sessions-table'},
        {'source': 'token-fn',     'target': 'kms-key'},
      ]
    },
    'logs': [
      ('INFO',  '/aws/lambda/auth-handler',  'POST /auth/login 200 {dur}ms user_id={uid} mfa=TOTP ip={ip}'),
      ('INFO',  '/aws/lambda/auth-handler',  'POST /auth/login 200 {dur}ms user_id={uid} mfa=WEBAUTHN ip={ip}'),
      ('INFO',  '/aws/lambda/token-handler', 'POST /auth/token 200 {dur}ms grant=refresh_token scope=openid,profile'),
      ('INFO',  '/aws/lambda/token-handler', 'REPORT RequestId:{req} Duration:{dur}ms Billed:{billed}ms Memory:256MB Used:{mem}MB'),
      ('INFO',  '/aws/lambda/auth-handler',  'WAF rule evaluated: rate_limit_auth PASS ip={ip} request_count=12/300s'),
      ('WARN',  '/aws/lambda/auth-handler',  'Failed login attempt: user_id={uid} ip={ip} attempt=3/5 — account not locked'),
    ]
  },
  {
    'accountId': 'prod-reporting',
    'score': 85,
    'stack': 'EC2 ASG · ALB · RDS PostgreSQL',
    'topology': {
      'nodes': [
        {'id': 'alb-rpt',    'label': 'reporting-alb',   'type': 'aws_alb',             'tier': 'ingress'},
        {'id': 'asg',        'label': 'reporting-asg',   'type': 'aws_autoscaling_group','tier': 'compute'},
        {'id': 'ec2-1',      'label': 'rpt-server-1',    'type': 'aws_instance',        'tier': 'compute'},
        {'id': 'ec2-2',      'label': 'rpt-server-2',    'type': 'aws_instance',        'tier': 'compute'},
        {'id': 'rds-primary','label': 'reports-primary', 'type': 'aws_db_instance',     'tier': 'data'},
        {'id': 'rds-replica','label': 'reports-replica', 'type': 'aws_db_instance',     'tier': 'data'},
        {'id': 'elasticache','label': 'reports-cache',   'type': 'aws_elasticache_cluster','tier': 'data'},
      ],
      'edges': [
        {'source': 'alb-rpt',    'target': 'asg'},
        {'source': 'asg',        'target': 'ec2-1'},
        {'source': 'asg',        'target': 'ec2-2'},
        {'source': 'ec2-1',      'target': 'rds-primary'},
        {'source': 'ec2-2',      'target': 'rds-replica'},
        {'source': 'ec2-1',      'target': 'elasticache'},
      ]
    },
    'logs': [
      ('INFO',  '/aws/ec2/reporting', 'GET /reports/quarterly 200 {dur}ms user={uid} rows=48291 cached=false'),
      ('INFO',  '/aws/ec2/reporting', 'GET /reports/dashboard 200 {fast}ms user={uid} cached=true ttl=300s'),
      ('INFO',  '/aws/ec2/reporting', 'Report generation completed: type=revenue_summary duration={dur}ms rows=12847'),
      ('INFO',  '/aws/rds/reports',   'Replica lag: 0.3ms primary_write_iops=342 replica_read_iops=1205'),
      ('WARN',  '/aws/ec2/reporting', 'Slow report query: revenue_by_region duration={slow}ms — consider materialized view'),
    ]
  },
  {
    'accountId': 'prod-api-gw',
    'score': 78,
    'stack': 'API GW · Lambda · DynamoDB · CloudFront',
    'topology': {
      'nodes': [
        {'id': 'cf-dist',    'label': 'api-cdn',         'type': 'aws_cloudfront_distribution','tier': 'ingress'},
        {'id': 'apigw',      'label': 'platform-api',    'type': 'aws_apigatewayv2_api',      'tier': 'ingress'},
        {'id': 'router-fn',  'label': 'api-router',      'type': 'aws_lambda_function',       'tier': 'compute'},
        {'id': 'product-fn', 'label': 'product-handler', 'type': 'aws_lambda_function',       'tier': 'compute'},
        {'id': 'order-fn',   'label': 'order-handler',   'type': 'aws_lambda_function',       'tier': 'compute'},
        {'id': 'products-tb','label': 'products-table',  'type': 'aws_dynamodb_table',        'tier': 'data'},
        {'id': 'orders-tb',  'label': 'orders-table',    'type': 'aws_dynamodb_table',        'tier': 'data'},
      ],
      'edges': [
        {'source': 'cf-dist',    'target': 'apigw'},
        {'source': 'apigw',      'target': 'router-fn'},
        {'source': 'router-fn',  'target': 'product-fn'},
        {'source': 'router-fn',  'target': 'order-fn'},
        {'source': 'product-fn', 'target': 'products-tb'},
        {'source': 'order-fn',   'target': 'orders-tb'},
      ]
    },
    'logs': [
      ('INFO',  '/aws/lambda/api-router',      'GET /v1/products 200 {dur}ms items=24 cache=HIT'),
      ('INFO',  '/aws/lambda/product-handler', 'GET /v1/products/{uid} 200 {fast}ms cache=HIT'),
      ('INFO',  '/aws/lambda/order-handler',   'POST /v1/orders 201 {dur}ms order_id={txn} items=3 total=${amt}'),
      ('INFO',  '/aws/lambda/order-handler',   'REPORT RequestId:{req} Duration:{dur}ms Billed:{billed}ms Memory:512MB Used:{mem}MB'),
      ('WARN',  '/aws/lambda/api-router',      'Cold start detected: init={cold}ms — provisioned concurrency recommended for /v1/orders'),
    ]
  },
  {
    'accountId': 'prod-storage',
    'score': 95,
    'stack': 'S3 · CloudFront · Lambda · ACM',
    'topology': {
      'nodes': [
        {'id': 'acm',        'label': 'cdn.acme.com',    'type': 'aws_acm_certificate',         'tier': 'ingress'},
        {'id': 'cloudfront', 'label': 'assets-cdn',      'type': 'aws_cloudfront_distribution', 'tier': 'ingress'},
        {'id': 's3-assets',  'label': 'assets-bucket',   'type': 'aws_s3_bucket',               'tier': 'storage'},
        {'id': 's3-backups', 'label': 'backups-bucket',  'type': 'aws_s3_bucket',               'tier': 'storage'},
        {'id': 'resize-fn',  'label': 'image-resizer',   'type': 'aws_lambda_function',         'tier': 'compute'},
        {'id': 'lifecycle',  'label': 'lifecycle-policy', 'type': 'aws_s3_bucket_lifecycle_configuration','tier': 'storage'},
      ],
      'edges': [
        {'source': 'acm',        'target': 'cloudfront'},
        {'source': 'cloudfront', 'target': 's3-assets'},
        {'source': 's3-assets',  'target': 'resize-fn'},
        {'source': 's3-assets',  'target': 'lifecycle'},
        {'source': 'resize-fn',  'target': 's3-assets'},
      ]
    },
    'logs': [
      ('INFO',  '/aws/lambda/image-resizer', 'Image processed: src=uploads/{txn}.jpg variants=[thumb,medium,large] duration={dur}ms'),
      ('INFO',  '/aws/cloudfront/assets-cdn','CACHE_HIT /assets/images/{txn}.webp edge=SEA1 ttl=86400'),
      ('INFO',  '/aws/cloudfront/assets-cdn','CACHE_HIT /assets/js/app.{auth}.js edge=LAX1 ttl=31536000'),
      ('INFO',  '/aws/lambda/image-resizer', 'REPORT RequestId:{req} Duration:{dur}ms Billed:{billed}ms Memory:1024MB Used:{mem}MB'),
      ('INFO',  '/aws/s3/assets-bucket',     'Lifecycle rule applied: {n} objects transitioned to INTELLIGENT_TIERING size=2.3GB'),
    ]
  },
  {
    'accountId': 'prod-notifications',
    'score': 81,
    'stack': 'SQS · Lambda · SES · SNS',
    'topology': {
      'nodes': [
        {'id': 'email-queue',  'label': 'email-queue',    'type': 'aws_sqs_queue',       'tier': 'ingress'},
        {'id': 'push-queue',   'label': 'push-queue',     'type': 'aws_sqs_queue',       'tier': 'ingress'},
        {'id': 'email-fn',     'label': 'email-sender',   'type': 'aws_lambda_function', 'tier': 'compute'},
        {'id': 'push-fn',      'label': 'push-sender',    'type': 'aws_lambda_function', 'tier': 'compute'},
        {'id': 'ses',          'label': 'SES',            'type': 'aws_ses_email_identity','tier': 'data'},
        {'id': 'sns-platform', 'label': 'push-platform',  'type': 'aws_sns_platform_application','tier': 'data'},
        {'id': 'dlq',          'label': 'notifications-dlq','type': 'aws_sqs_queue',    'tier': 'storage'},
      ],
      'edges': [
        {'source': 'email-queue',  'target': 'email-fn'},
        {'source': 'push-queue',   'target': 'push-fn'},
        {'source': 'email-fn',     'target': 'ses'},
        {'source': 'push-fn',      'target': 'sns-platform'},
        {'source': 'email-fn',     'target': 'dlq'},
        {'source': 'push-fn',      'target': 'dlq'},
      ]
    },
    'logs': [
      ('INFO',  '/aws/lambda/email-sender', 'Email sent: to={uid}@acme.com template=order_confirmation ses_message_id={txn} duration={dur}ms'),
      ('INFO',  '/aws/lambda/push-sender',  'Push notification delivered: platform=APNS device_tokens=1 duration={fast}ms'),
      ('INFO',  '/aws/lambda/email-sender', 'Batch processed: {n} emails queued={n} sent={n} failed=0 duration={dur}ms'),
      ('INFO',  '/aws/lambda/email-sender', 'REPORT RequestId:{req} Duration:{dur}ms Billed:{billed}ms Memory:256MB Used:{mem}MB'),
      ('WARN',  '/aws/lambda/email-sender', 'SES send rate: {pct}% of daily quota used ({n}/50000 emails)'),
    ]
  },
  {
    'accountId': 'prod-search',
    'score': 83,
    'stack': 'ALB · EC2 · OpenSearch · ElastiCache',
    'topology': {
      'nodes': [
        {'id': 'alb-search',  'label': 'search-alb',      'type': 'aws_alb',                    'tier': 'ingress'},
        {'id': 'ec2-search',  'label': 'search-server',   'type': 'aws_instance',               'tier': 'compute'},
        {'id': 'opensearch',  'label': 'search-domain',   'type': 'aws_opensearch_domain',      'tier': 'data'},
        {'id': 'redis-cache', 'label': 'search-cache',    'type': 'aws_elasticache_cluster',    'tier': 'data'},
        {'id': 'indexer-fn',  'label': 'content-indexer', 'type': 'aws_lambda_function',        'tier': 'compute'},
      ],
      'edges': [
        {'source': 'alb-search',  'target': 'ec2-search'},
        {'source': 'ec2-search',  'target': 'opensearch'},
        {'source': 'ec2-search',  'target': 'redis-cache'},
        {'source': 'indexer-fn',  'target': 'opensearch'},
      ]
    },
    'logs': [
      ('INFO',  '/aws/ec2/search', 'GET /search?q={txn}&filters=category:electronics 200 {dur}ms hits=142 took=45ms'),
      ('INFO',  '/aws/ec2/search', 'GET /search?q={txn} 200 {fast}ms cache=HIT hits=89'),
      ('INFO',  '/aws/lambda/content-indexer', 'Indexed {n} documents in {dur}ms index=products shard=0'),
      ('INFO',  '/aws/ec2/search', 'OpenSearch cluster health: GREEN shards=10 nodes=3 index_size=4.2GB'),
      ('WARN',  '/aws/ec2/search', 'Search query slow: q={txn} took={slow}ms threshold=500ms — missing field index'),
    ]
  },

  # ── WARNING ───────────────────────────────────────────────────────────────────
  {
    'accountId': 'prod-checkout',
    'score': 58,
    'stack': 'ECS · ALB · Aurora · ElastiCache',
    'topology': {
      'nodes': [
        {'id': 'alb-co',       'label': 'checkout-alb',    'type': 'aws_alb',           'tier': 'ingress'},
        {'id': 'ecs-checkout', 'label': 'checkout-svc',    'type': 'aws_ecs_service',   'tier': 'compute'},
        {'id': 'aurora-co',    'label': 'checkout-aurora', 'type': 'aws_rds_cluster',   'tier': 'data'},
        {'id': 'redis-cart',   'label': 'cart-cache',      'type': 'aws_elasticache_cluster','tier': 'data'},
        {'id': 'sqs-orders',   'label': 'order-queue',     'type': 'aws_sqs_queue',     'tier': 'data'},
      ],
      'edges': [
        {'source': 'alb-co',       'target': 'ecs-checkout'},
        {'source': 'ecs-checkout', 'target': 'aurora-co'},
        {'source': 'ecs-checkout', 'target': 'redis-cart'},
        {'source': 'ecs-checkout', 'target': 'sqs-orders'},
      ]
    },
    'logs': [
      ('WARN',  '/aws/ecs/checkout-svc', 'POST /checkout/complete 200 {slow}ms — p99 latency elevated above 2000ms threshold'),
      ('WARN',  '/aws/ecs/checkout-svc', 'Aurora read latency elevated: avg={slow}ms p99={slow}ms (baseline 45ms) — investigate long-running transactions'),
      ('WARN',  '/aws/ecs/checkout-svc', 'Cart cache miss rate: {pct}% (threshold 20%) — Redis eviction pressure detected'),
      ('INFO',  '/aws/ecs/checkout-svc', 'POST /checkout/complete 200 {slow}ms txn_id={txn} items=3 total=${amt}'),
      ('WARN',  '/aws/ecs/checkout-svc', 'ECS CPU utilisation: {pct}% — approaching scale-out threshold of 80%'),
      ('ERROR', '/aws/ecs/checkout-svc', 'POST /checkout/complete 504 Gateway Timeout — Aurora connection wait exceeded 5000ms'),
    ]
  },
  {
    'accountId': 'prod-cms',
    'score': 52,
    'stack': 'ALB · EC2 ASG · RDS MySQL · EFS',
    'topology': {
      'nodes': [
        {'id': 'alb-cms',  'label': 'cms-alb',     'type': 'aws_alb',                    'tier': 'ingress'},
        {'id': 'asg-cms',  'label': 'cms-asg',     'type': 'aws_autoscaling_group',      'tier': 'compute'},
        {'id': 'ec2-cms',  'label': 'cms-server',  'type': 'aws_instance',               'tier': 'compute'},
        {'id': 'rds-cms',  'label': 'cms-mysql',   'type': 'aws_db_instance',            'tier': 'data'},
        {'id': 'efs',      'label': 'cms-media',   'type': 'aws_efs_file_system',        'tier': 'storage'},
        {'id': 'acm-cms',  'label': 'cms.acme.com','type': 'aws_acm_certificate',        'tier': 'ingress'},
      ],
      'edges': [
        {'source': 'acm-cms', 'target': 'alb-cms'},
        {'source': 'alb-cms', 'target': 'asg-cms'},
        {'source': 'asg-cms', 'target': 'ec2-cms'},
        {'source': 'ec2-cms', 'target': 'rds-cms'},
        {'source': 'ec2-cms', 'target': 'efs'},
      ]
    },
    'logs': [
      ('WARN',  '/aws/ec2/cms', 'Disk usage: / partition {pct}% full (threshold 80%) — media uploads growing 2GB/day'),
      ('WARN',  '/aws/ec2/cms', 'EFS burst credit balance: {n} credits remaining — sustained throughput may degrade'),
      ('WARN',  '/aws/rds/cms-mysql', 'Slow query log: SELECT * FROM wp_posts WHERE post_status=publish ORDER BY post_date DESC LIMIT 10 duration={slow}ms'),
      ('ERROR', '/aws/ec2/cms', 'Upload failed: disk quota exceeded on EFS mount /var/www/html/wp-content/uploads'),
      ('INFO',  '/aws/ec2/cms', 'GET /wp-admin/posts 200 {dur}ms user=admin'),
      ('WARN',  '/aws/rds/cms-mysql', 'InnoDB buffer pool usage: {pct}% — consider increasing innodb_buffer_pool_size'),
    ]
  },

  # ── CRITICAL ──────────────────────────────────────────────────────────────────
  {
    'accountId': 'prod-integrations',
    'score': 31,
    'stack': 'API GW · Lambda · DynamoDB · EventBridge',
    'topology': {
      'nodes': [
        {'id': 'apigw-int',  'label': 'integrations-api', 'type': 'aws_apigatewayv2_api', 'tier': 'ingress'},
        {'id': 'router-fn',  'label': 'webhook-router',   'type': 'aws_lambda_function',  'tier': 'compute'},
        {'id': 'stripe-fn',  'label': 'stripe-handler',   'type': 'aws_lambda_function',  'tier': 'compute'},
        {'id': 'slack-fn',   'label': 'slack-handler',    'type': 'aws_lambda_function',  'tier': 'compute'},
        {'id': 'events-bus', 'label': 'integrations-bus', 'type': 'aws_cloudwatch_event_bus','tier': 'compute'},
        {'id': 'events-table','label':'webhook-events',   'type': 'aws_dynamodb_table',   'tier': 'data'},
        {'id': 'dlq-int',    'label': 'integrations-dlq', 'type': 'aws_sqs_queue',        'tier': 'storage'},
      ],
      'edges': [
        {'source': 'apigw-int',  'target': 'router-fn'},
        {'source': 'router-fn',  'target': 'stripe-fn'},
        {'source': 'router-fn',  'target': 'slack-fn'},
        {'source': 'router-fn',  'target': 'events-bus'},
        {'source': 'stripe-fn',  'target': 'events-table'},
        {'source': 'slack-fn',   'target': 'events-table'},
        {'source': 'router-fn',  'target': 'dlq-int'},
      ]
    },
    'logs': [
      ('ERROR', '/aws/lambda/webhook-router',  'ProvisionedThroughputExceededException: table=webhook-events consumed={rcus} provisioned=25 — {n} requests throttled in last 60s'),
      ('ERROR', '/aws/lambda/webhook-router',  'ProvisionedThroughputExceededException: table=webhook-events consumed={rcus} provisioned=25 — {n} requests throttled in last 60s'),
      ('ERROR', '/aws/lambda/stripe-handler',  'POST /webhooks/stripe 500 — DynamoDB write failed after 3 retries: ProvisionedThroughputExceededException'),
      ('ERROR', '/aws/lambda/webhook-router',  'DLQ message count: {n} — failed webhook deliveries accumulating. Stripe retry window expires in 4h'),
      ('WARN',  '/aws/lambda/webhook-router',  'Webhook processing latency: p99={slow}ms (SLA=500ms) — DDB throttling causing cascade delays'),
      ('ERROR', '/aws/lambda/slack-handler',   'Slack event processing failed: message_id={txn} error=DynamoDBThrottled retry_count=3 moving_to_dlq=true'),
    ]
  },
]


def _vals():
    return dict(
        dur=random.randint(45, 350),
        fast=random.randint(8, 40),
        slow=random.randint(800, 3500),
        billed=random.randint(50, 400),
        cold=random.randint(200, 800),
        mem=random.randint(60, 300),
        txn=__import__('uuid').uuid4().hex[:8].upper(),
        req=str(__import__('uuid').uuid4()),
        uid=random.randint(10000, 99999),
        amt=f'{random.randint(5, 5000)}.{random.randint(0,99):02d}',
        auth=str(random.randint(100000, 999999)),
        ip=f'10.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}',
        n=random.randint(5, 200),
        pct=random.randint(65, 92),
        rcus=random.randint(30, 120),
        pool_active=random.randint(8, 35),
        pool_idle=random.randint(5, 20),
    )


def seed_health_scores():
    tbl = ddb.Table(f'{PROJECT}-HealthScores')
    now = int(time.time())
    seeded = []
    for acc in ACCOUNTS:
        tbl.put_item(Item={
            'accountId':    acc['accountId'],
            'score':        acc['score'],
            'baseScore':    acc['score'],   # floor — health_scorer will not go below this
            'calculatedAt': now,
            'ttl':          now + 15 * 60,  # 15 min TTL — seeder runs every 5 min
        })
        seeded.append(acc['accountId'])
        print(f'  ✓ HealthScore: {acc["accountId"]} = {acc["score"]}')
    return seeded


def seed_topology():
    seeded = []
    for acc in ACCOUNTS:
        topo = acc['topology']
        payload = {
            'accountId':  acc['accountId'],
            'nodes':      topo['nodes'],
            'edges':      topo['edges'],
            'nodeCount':  len(topo['nodes']),
            'edgeCount':  len(topo['edges']),
            'updatedAt':  int(time.time()),
        }
        key = f'{acc["accountId"]}/current.json'
        s3.put_object(
            Bucket=TOPOLOGY_BUCKET,
            Key=key,
            Body=json.dumps(payload),
            ContentType='application/json',
        )
        seeded.append(acc['accountId'])
        print(f'  ✓ Topology: {acc["accountId"]} ({len(topo["nodes"])} nodes, {len(topo["edges"])} edges)')
    return seeded


def seed_signals():
    """Send a burst of realistic log events into Kinesis for each account."""
    try:
        stream = kinesis.describe_stream(StreamName=f'{PROJECT}-log-stream')
        stream_name = f'{PROJECT}-log-stream'
    except Exception:
        print('  Kinesis stream not found — skipping signal seeding')
        return

    total = 0
    for acc in ACCOUNTS:
        templates = acc.get('logs', [])
        if not templates:
            continue
        # Send 8-15 events per account
        count = random.randint(8, 15)
        events = []
        for _ in range(count):
            level, log_group, tmpl = random.choice(templates)
            v = _vals()
            try:
                message = tmpl.format(**v)
            except Exception:
                message = tmpl
            events.append({
                'logGroup':  log_group,
                'timestamp': int(time.time() * 1000),
                'level':     level,
                'message':   message,
            })

        # Group by log group
        by_group = {}
        for e in events:
            by_group.setdefault(e['logGroup'], []).append(e)

        for log_group, group_events in by_group.items():
            kinesis.put_record(
                StreamName=stream_name,
                Data=json.dumps({
                    'accountId':  acc['accountId'],
                    'logGroup':   log_group,
                    'logEvents':  group_events,
                    'eventCount': len(group_events),
                    'source':     'opsiq.extended.simulation',
                }),
                PartitionKey=acc['accountId'],
            )
            total += len(group_events)

    print(f'  ✓ Signals: {total} log events sent to Kinesis')


def main():
    print('═══════════════════════════════════════════════')
    print('  OpsIQ — Extended Simulation Account Seeder  ')
    print(f'  Account: {ACCOUNT_ID} · Region: {REGION}')
    print('═══════════════════════════════════════════════')
    print()

    print('Seeding health scores...')
    seed_health_scores()

    print()
    print('Seeding topology graphs...')
    seed_topology()

    print()
    print('Seeding initial signals...')
    seed_signals()

    print()
    print('═══════════════════════════════════════════════')
    print(f'  Done! {len(ACCOUNTS)} accounts seeded.')
    print()
    print('  Healthy  (7): prod-payments, prod-identity,')
    print('                prod-reporting, prod-api-gw,')
    print('                prod-storage, prod-notifications,')
    print('                prod-search')
    print('  Warning  (2): prod-checkout, prod-cms')
    print('  Critical (1): prod-integrations')
    print()
    print('  Refresh the dashboard — new accounts appear immediately.')
    print('  Health scores TTL: 7 min (health-schedule maintains them)')
    print('═══════════════════════════════════════════════')


if __name__ == '__main__':
    main()


def handler(event, context):
    """Lambda entry point — seeds all extended accounts."""
    try:
        seed_health_scores()
        seed_topology()
        seed_signals()
        print("Extended seeder complete")
        return {
            'statusCode': 200,
            'body': json.dumps({'status': 'ok', 'accounts_seeded': 10})
        }
    except Exception as e:
        print(f'Extended seeder error: {e}')
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
