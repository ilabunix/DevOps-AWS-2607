"""
OpsIQ Simulation — anomaly_injector.py
On-demand demo trigger. Sets DynamoDB mode flags for generators,
then emits 3 phased synthetic anomaly events to the central EventBridge bus.
This drives the full real processing pipeline — correlator, incident-assembler,
Bedrock, ws-broadcaster — producing a live demo with no mocked output.

Invoke payload:
{
    "scenario":  "ecs-oom" | "api-latency" | "rds-exhaustion" | "novel-pattern",
    "accountId": "sim-app-a" | "sim-app-b" | "sim-app-c",
    "severity":  "HIGH" | "MEDIUM"   (optional, default HIGH)
}
"""
import json
import os
import time
import uuid

import boto3
from botocore.exceptions import ClientError

SIGNAL_BUS  = os.environ['SIGNAL_BUS_NAME']
ANOMALY_QUEUE = os.environ['ANOMALY_QUEUE_URL']
MODE_TABLE  = os.environ['MODE_TABLE']
PROJECT     = os.environ['PROJECT_NAME']

eb    = boto3.client('events')
sqs   = boto3.client('sqs')
ddb   = boto3.resource('dynamodb')
m_tbl = ddb.Table(MODE_TABLE)

# ─── SCENARIO DEFINITIONS ─────────────────────────────────────────────────
SCENARIOS = {
    'ecs-oom': {
        'accountId_default': 'sim-app-a',
        'phases': [
            {
                'delay':       0,
                'anomalyType': 'alb_5xx',
                'severity':    'HIGH',
                'detailType':  'ALB5xxSpike',
                'detail': {
                    'metric':      'ALB_5xx_Rate',
                    'value':       28.5,
                    'threshold':   5.0,
                    'description': 'ALB 5xx error rate spiked to 28.5% (threshold: 5%). Upstream ECS targets returning 500.',
                    'resource':    'sim-app-a-alb',
                },
            },
            {
                'delay':       30,   # seconds after phase 0
                'anomalyType': 'ecs_high_memory',
                'severity':    'HIGH',
                'detailType':  'ECSMemoryAnomaly',
                'detail': {
                    'metric':      'ECS_MemoryUtilization',
                    'value':       98.7,
                    'threshold':   90.0,
                    'description': 'ECS task memory utilization at 98.7%. OutOfMemoryError detected in logs. Tasks restarting.',
                    'resource':    'sim-app-a-cluster/api-service',
                },
            },
            {
                'delay':       55,
                'anomalyType': 'novel_log_pattern',
                'severity':    'HIGH',
                'detailType':  'NovelLogPattern',
                'detail': {
                    'signature':   'JAVA.LANG.OUTOFMEMORYERROR JAVA HEAP SPACE',
                    'logGroup':    '/aws/ecs/sim-app-a-api',
                    'description': 'Novel OutOfMemoryError pattern detected for first time. Java heap space exhausted.',
                    'resource':    'sim-app-a-api',
                },
            },
        ],
    },
    'api-latency': {
        'accountId_default': 'sim-app-b',
        'phases': [
            {
                'delay':       0,
                'anomalyType': 'lambda_timeout',
                'severity':    'HIGH',
                'detailType':  'LambdaTimeout',
                'detail': {
                    'metric':      'Lambda_Duration',
                    'value':       14987.0,
                    'threshold':   15000.0,
                    'description': 'Lambda function approaching timeout threshold. Duration: 14,987ms of 15,000ms limit.',
                    'resource':    'sim-app-b-handler',
                },
            },
            {
                'delay':       25,
                'anomalyType': 'alb_5xx',
                'severity':    'MEDIUM',
                'detailType':  'APIGateway5xx',
                'detail': {
                    'metric':      'Lambda_Errors',
                    'value':       18.0,
                    'threshold':   5.0,
                    'description': 'Lambda error count elevated. 18 errors in last 5 minutes.',
                    'resource':    'sim-app-b-handler',
                },
            },
        ],
    },
    'rds-exhaustion': {
        'accountId_default': 'sim-app-a',
        'phases': [
            {
                'delay':       0,
                'anomalyType': 'rds_connection_exhaustion',
                'severity':    'HIGH',
                'detailType':  'RDSConnectionExhaustion',
                'detail': {
                    'metric':      'RDS_Connections',
                    'value':       98.0,
                    'threshold':   80.0,
                    'description': 'RDS Aurora connection count at 98/100. New connections being refused.',
                    'resource':    'sim-app-a-postgres',
                },
            },
            {
                'delay':       20,
                'anomalyType': 'ecs_high_cpu',
                'severity':    'MEDIUM',
                'detailType':  'ECSCPUAnomaly',
                'detail': {
                    'metric':      'ECS_CPUUtilization',
                    'value':       94.2,
                    'threshold':   80.0,
                    'description': 'ECS CPU utilization at 94.2%. Tasks experiencing slow responses due to DB wait.',
                    'resource':    'sim-app-a-cluster/api-service',
                },
            },
        ],
    },
    'novel-pattern': {
        'accountId_default': 'sim-app-c',
        'phases': [
            {
                'delay':       0,
                'anomalyType': 'novel_log_pattern',
                'severity':    'HIGH',
                'detailType':  'NovelLogPattern',
                'detail': {
                    'signature':   'ECONNREFUSED REDIS CONNECTION REFUSED',
                    'logGroup':    '/aws/ecs/sim-app-c-web',
                    'description': 'First-ever Redis ECONNREFUSED error. Redis cluster may be down or misconfigured.',
                    'resource':    'sim-app-c-web',
                },
            },
            {
                'delay':       15,
                'anomalyType': 'alb_5xx',
                'severity':    'MEDIUM',
                'detailType':  'ALB5xxSpike',
                'detail': {
                    'metric':      'ALB_5xx_Rate',
                    'value':       9.3,
                    'threshold':   5.0,
                    'description': 'ALB 5xx rate elevated at 9.3%. Cache miss causing downstream load.',
                    'resource':    'sim-app-c-alb',
                },
            },
        ],
    },
}


def _set_mode(account_id: str, mode: str) -> None:
    m_tbl.put_item(Item={
        'accountId': account_id,
        'mode':      mode,
        'setAt':     int(time.time()),
        'ttl':       int(time.time()) + 600,  # Auto-reset after 10 min
    })


def _emit_anomaly(account_id: str, phase: dict, severity_override: str) -> None:
    severity  = severity_override or phase.get('severity', 'HIGH')
    anomaly_id = str(uuid.uuid4())

    event_detail = {
        'accountId':   account_id,
        'anomalyId':   anomaly_id,
        'anomalyType': phase['anomalyType'],
        'severity':    severity,
        'timestamp':   int(time.time() * 1000),
        **phase.get('detail', {}),
    }

    # Send directly to anomaly SQS queue (bypasses EventBridge for reliability)
    sqs.send_message(
        QueueUrl=ANOMALY_QUEUE,
        MessageBody=json.dumps(event_detail),
    )
    print(f'Injected anomaly | type={phase["anomalyType"]} | account={account_id} | severity={severity}')


def handler(event, context):
    scenario_name   = event.get('scenario', 'ecs-oom')
    account_id      = event.get('accountId', '')
    severity        = event.get('severity', 'HIGH')

    scenario = SCENARIOS.get(scenario_name)
    if not scenario:
        return {'error': f'Unknown scenario: {scenario_name}', 'available': list(SCENARIOS.keys())}

    if not account_id:
        account_id = scenario['accountId_default']

    print(f'Starting anomaly injection | scenario={scenario_name} | account={account_id}')

    # Set generators to anomaly mode
    _set_mode(account_id, 'anomaly')

    # Emit first phase immediately
    phases = scenario['phases']
    _emit_anomaly(account_id, phases[0], severity)

    # For Lambda context — emit remaining phases with simulated delays
    # (In real use, these would be scheduled. For POC simplicity, we emit them
    # all now with timestamps spaced out so correlator sees them as temporally separate.)
    for phase in phases[1:]:
        # Adjust timestamp to appear delayed
        phase_copy = dict(phase)
        phase_copy['detail'] = dict(phase.get('detail', {}))
        phase_copy['detail']['simulatedDelaySeconds'] = phase['delay']
        time.sleep(min(phase['delay'], 3))  # Cap sleep to avoid Lambda timeout
        _emit_anomaly(account_id, phase_copy, severity)

    return {
        'status':        'injected',
        'scenario':      scenario_name,
        'accountId':     account_id,
        'phasesEmitted': len(phases),
        'estimatedDetectionTime': '2-5 minutes',
        'note': 'Watch dashboard — health score will drop, anomaly cards appear, then incident card with AI summary',
    }
