"""
OpsIQ — manual_seeder.py

Standalone seeder that can be invoked directly from CLI.
Does NOT use cfnresponse — works as a normal Lambda invocation.

Invoke:
  aws lambda invoke \
    --function-name opsiq-manual-seeder \
    --region us-west-2 \
    response.json && cat response.json

Or just run it as a script locally if you have AWS credentials:
  python3 manual_seeder.py
"""
import json
import os
import time
import boto3

# Read from environment (Lambda) or use defaults
STATE_BUCKET = os.environ.get('STATE_BUCKET', f'opsiq-tfstate-{boto3.client("sts").get_caller_identity()["Account"]}')
STATE_QUEUE  = os.environ.get('STATE_QUEUE',  '')
HEALTH_TABLE = os.environ.get('HEALTH_TABLE', 'opsiq-HealthScores')
PROJECT      = os.environ.get('PROJECT_NAME', 'opsiq')
REGION       = os.environ.get('AWS_REGION',   'us-west-2')

s3  = boto3.client('s3', region_name=REGION)
sqs = boto3.client('sqs', region_name=REGION)
ddb = boto3.resource('dynamodb', region_name=REGION)

SYNTHETIC_STATES = {
    'sim-app-a': {
        'version': 4, 'serial': 12,
        'resources': [
            {'mode':'managed','type':'aws_alb','name':'main','instances':[{'attributes':{'arn':'arn:aws:elasticloadbalancing:us-west-2:sim:loadbalancer/app/sim-app-a-alb/abc123','dns_name':'sim-app-a-alb.us-west-2.elb.amazonaws.com','name':'sim-app-a-alb','vpc_id':'vpc-simappavpc','tags':{'App':'sim-app-a','Tier':'ingress'}},'dependencies':[]}]},
            {'mode':'managed','type':'aws_ecs_cluster','name':'main','instances':[{'attributes':{'arn':'arn:aws:ecs:us-west-2:sim:cluster/sim-app-a-cluster','name':'sim-app-a-cluster','id':'sim-app-a-cluster','tags':{'App':'sim-app-a','Tier':'compute'}},'dependencies':['aws_alb.main']}]},
            {'mode':'managed','type':'aws_ecs_service','name':'api','instances':[{'attributes':{'id':'arn:aws:ecs:us-west-2:sim:service/sim-app-a-cluster/api-service','name':'api-service','cluster':'arn:aws:ecs:us-west-2:sim:cluster/sim-app-a-cluster','desired_count':3,'launch_type':'FARGATE','tags':{'App':'sim-app-a','Tier':'compute'}},'dependencies':['aws_ecs_cluster.main','aws_alb.main']}]},
            {'mode':'managed','type':'aws_rds_cluster','name':'postgres','instances':[{'attributes':{'arn':'arn:aws:rds:us-west-2:sim:cluster:sim-app-a-postgres','id':'sim-app-a-postgres','engine':'aurora-postgresql','engine_version':'14.6','tags':{'App':'sim-app-a','Tier':'data'}},'dependencies':['aws_ecs_service.api']}]},
            {'mode':'managed','type':'aws_lambda_function','name':'payment_processor','instances':[{'attributes':{'arn':'arn:aws:lambda:us-west-2:sim:function:sim-app-a-payment-processor','function_name':'sim-app-a-payment-processor','runtime':'python3.12','memory_size':512,'timeout':30,'tags':{'App':'sim-app-a','Tier':'compute'}},'dependencies':['aws_rds_cluster.postgres']}]},
        ],
    },
    'sim-app-b': {
        'version': 4, 'serial': 7,
        'resources': [
            {'mode':'managed','type':'aws_apigatewayv2_api','name':'main','instances':[{'attributes':{'id':'sim-app-b-apigw','name':'sim-app-b-api','protocol_type':'HTTP','tags':{'App':'sim-app-b','Tier':'ingress'}},'dependencies':[]}]},
            {'mode':'managed','type':'aws_lambda_function','name':'handler','instances':[{'attributes':{'arn':'arn:aws:lambda:us-west-2:sim:function:sim-app-b-handler','function_name':'sim-app-b-handler','runtime':'nodejs18.x','memory_size':256,'timeout':15,'tags':{'App':'sim-app-b','Tier':'compute'}},'dependencies':['aws_apigatewayv2_api.main']}]},
            {'mode':'managed','type':'aws_dynamodb_table','name':'data','instances':[{'attributes':{'arn':'arn:aws:dynamodb:us-west-2:sim:table/sim-app-b-data','id':'sim-app-b-data','name':'sim-app-b-data','billing_mode':'PAY_PER_REQUEST','tags':{'App':'sim-app-b','Tier':'data'}},'dependencies':['aws_lambda_function.handler']}]},
        ],
    },
    'sim-app-c': {
        'version': 4, 'serial': 5,
        'resources': [
            {'mode':'managed','type':'aws_alb','name':'web','instances':[{'attributes':{'arn':'arn:aws:elasticloadbalancing:us-west-2:sim:loadbalancer/app/sim-app-c-alb/xyz789','dns_name':'sim-app-c-alb.us-west-2.elb.amazonaws.com','name':'sim-app-c-alb','vpc_id':'vpc-simappcvpc','tags':{'App':'sim-app-c','Tier':'ingress'}},'dependencies':[]}]},
            {'mode':'managed','type':'aws_ecs_service','name':'web','instances':[{'attributes':{'id':'arn:aws:ecs:us-west-2:sim:service/sim-app-c-cluster/web-service','name':'web-service','cluster':'arn:aws:ecs:us-west-2:sim:cluster/sim-app-c-cluster','desired_count':2,'launch_type':'FARGATE','tags':{'App':'sim-app-c','Tier':'compute'}},'dependencies':['aws_alb.web']}]},
            {'mode':'managed','type':'aws_elasticache_cluster','name':'redis','instances':[{'attributes':{'id':'sim-app-c-redis','engine':'redis','node_type':'cache.t3.micro','num_cache_nodes':1,'tags':{'App':'sim-app-c','Tier':'data'}},'dependencies':['aws_ecs_service.web']}]},
        ],
    },
}


def handler(event=None, context=None):
    """Works as Lambda handler OR called directly as a script."""
    account_id = boto3.client('sts', region_name=REGION).get_caller_identity()['Account']
    state_bucket = STATE_BUCKET if STATE_BUCKET else f'opsiq-tfstate-{account_id}'

    # Get state queue URL if not set
    state_queue = STATE_QUEUE
    if not state_queue:
        try:
            resp = sqs.get_queue_url(QueueName=f'{PROJECT}-state-ingest')
            state_queue = resp['QueueUrl']
        except Exception as e:
            print(f'Could not find state queue: {e}')
            return {'statusCode': 500, 'error': str(e)}

    h_tbl = ddb.Table(HEALTH_TABLE)
    seeded = []

    for account_id_sim, state in SYNTHETIC_STATES.items():
        try:
            # Upload tfstate to S3
            s3.put_object(
                Bucket=state_bucket,
                Key=f'{account_id_sim}/terraform.tfstate',
                Body=json.dumps(state),
                ContentType='application/json',
            )
            print(f'Uploaded tfstate for {account_id_sim}')

            # Send to state-ingest SQS queue
            payload = {
                'accountId': account_id_sim,
                'source':    'opsiq.manual.seed',
                'resources': state['resources'],
            }
            sqs.send_message(
                QueueUrl=state_queue,
                MessageBody=json.dumps(payload),
            )
            print(f'Sent to state queue: {account_id_sim}')

            # Register in HealthScores with score=100
            h_tbl.put_item(Item={
                'accountId':    account_id_sim,
                'score':        100,
                'calculatedAt': int(time.time()),
                'ttl':          int(time.time()) + 6 * 60,
            })
            print(f'Seeded HealthScores: {account_id_sim}')
            seeded.append(account_id_sim)

        except Exception as e:
            print(f'Error seeding {account_id_sim}: {e}')

    result = {
        'statusCode':     200,
        'seededAccounts': seeded,
        'count':          len(seeded),
        'message':        f'Successfully seeded {len(seeded)} accounts',
    }
    print(json.dumps(result))
    return result


if __name__ == '__main__':
    # Allow running directly as a script
    handler()
