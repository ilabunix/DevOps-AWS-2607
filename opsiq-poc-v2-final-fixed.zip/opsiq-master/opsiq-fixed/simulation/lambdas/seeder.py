"""
OpsIQ Simulation — seeder.py
CloudFormation Custom Resource. Runs once on stack CREATE.
Uploads synthetic Terraform state for 3 simulated accounts to S3,
then sends each payload to the central state-ingest SQS queue
so the state_parser builds initial topology graphs.
Also registers each simulated account in HealthScores with score=100.
"""
import json
import os
import time

import boto3
import urllib.request

STATE_BUCKET   = os.environ['STATE_BUCKET']
STATE_QUEUE    = os.environ['STATE_QUEUE']
HEALTH_TABLE   = os.environ['HEALTH_TABLE']
PROJECT        = os.environ['PROJECT_NAME']

s3  = boto3.client('s3')
sqs = boto3.client('sqs')
ddb = boto3.resource('dynamodb')
h_tbl = ddb.Table(HEALTH_TABLE)

# ─── SYNTHETIC TERRAFORM STATES ───────────────────────────────────────────
# Each entry mirrors what a real tfstate looks like for that app profile.
# The state_parser will extract resources and build topology from this.

SYNTHETIC_STATES = {
    'sim-app-a': {
        'version': 4,
        'serial':  12,
        'resources': [
            {
                'mode': 'managed',
                'type': 'aws_alb',
                'name': 'main',
                'instances': [{
                    'attributes': {
                        'arn':      'arn:aws:elasticloadbalancing:us-west-2:sim:loadbalancer/app/sim-app-a-alb/abc123',
                        'dns_name': 'sim-app-a-alb.us-west-2.elb.amazonaws.com',
                        'name':     'sim-app-a-alb',
                        'vpc_id':   'vpc-simappavpc',
                        'tags':     {'App': 'sim-app-a', 'Tier': 'ingress'},
                    },
                    'dependencies': [],
                }],
            },
            {
                'mode': 'managed',
                'type': 'aws_ecs_cluster',
                'name': 'main',
                'instances': [{
                    'attributes': {
                        'arn':  'arn:aws:ecs:us-west-2:sim:cluster/sim-app-a-cluster',
                        'name': 'sim-app-a-cluster',
                        'id':   'sim-app-a-cluster',
                        'tags': {'App': 'sim-app-a', 'Tier': 'compute'},
                    },
                    'dependencies': ['aws_alb.main'],
                }],
            },
            {
                'mode': 'managed',
                'type': 'aws_ecs_service',
                'name': 'api',
                'instances': [{
                    'attributes': {
                        'id':            'arn:aws:ecs:us-west-2:sim:service/sim-app-a-cluster/api-service',
                        'name':          'api-service',
                        'cluster':       'arn:aws:ecs:us-west-2:sim:cluster/sim-app-a-cluster',
                        'desired_count': 3,
                        'launch_type':   'FARGATE',
                        'tags':          {'App': 'sim-app-a', 'Tier': 'compute'},
                    },
                    'dependencies': ['aws_ecs_cluster.main', 'aws_alb.main'],
                }],
            },
            {
                'mode': 'managed',
                'type': 'aws_rds_cluster',
                'name': 'postgres',
                'instances': [{
                    'attributes': {
                        'arn':            'arn:aws:rds:us-west-2:sim:cluster:sim-app-a-postgres',
                        'id':             'sim-app-a-postgres',
                        'engine':         'aurora-postgresql',
                        'engine_version': '14.6',
                        'tags':           {'App': 'sim-app-a', 'Tier': 'data'},
                    },
                    'dependencies': ['aws_ecs_service.api'],
                }],
            },
            {
                'mode': 'managed',
                'type': 'aws_lambda_function',
                'name': 'payment_processor',
                'instances': [{
                    'attributes': {
                        'arn':           'arn:aws:lambda:us-west-2:sim:function:sim-app-a-payment-processor',
                        'function_name': 'sim-app-a-payment-processor',
                        'runtime':       'python3.12',
                        'memory_size':   512,
                        'timeout':       30,
                        'tags':          {'App': 'sim-app-a', 'Tier': 'compute'},
                    },
                    'dependencies': ['aws_rds_cluster.postgres'],
                }],
            },
        ],
    },

    'sim-app-b': {
        'version': 4,
        'serial':  7,
        'resources': [
            {
                'mode': 'managed',
                'type': 'aws_apigatewayv2_api',
                'name': 'main',
                'instances': [{
                    'attributes': {
                        'id':            'sim-app-b-apigw',
                        'name':          'sim-app-b-api',
                        'protocol_type': 'HTTP',
                        'tags':          {'App': 'sim-app-b', 'Tier': 'ingress'},
                    },
                    'dependencies': [],
                }],
            },
            {
                'mode': 'managed',
                'type': 'aws_lambda_function',
                'name': 'handler',
                'instances': [{
                    'attributes': {
                        'arn':           'arn:aws:lambda:us-west-2:sim:function:sim-app-b-handler',
                        'function_name': 'sim-app-b-handler',
                        'runtime':       'nodejs18.x',
                        'memory_size':   256,
                        'timeout':       15,
                        'tags':          {'App': 'sim-app-b', 'Tier': 'compute'},
                    },
                    'dependencies': ['aws_apigatewayv2_api.main'],
                }],
            },
            {
                'mode': 'managed',
                'type': 'aws_dynamodb_table',
                'name': 'data',
                'instances': [{
                    'attributes': {
                        'arn':          'arn:aws:dynamodb:us-west-2:sim:table/sim-app-b-data',
                        'id':           'sim-app-b-data',
                        'name':         'sim-app-b-data',
                        'billing_mode': 'PAY_PER_REQUEST',
                        'tags':         {'App': 'sim-app-b', 'Tier': 'data'},
                    },
                    'dependencies': ['aws_lambda_function.handler'],
                }],
            },
        ],
    },

    'sim-app-c': {
        'version': 4,
        'serial':  5,
        'resources': [
            {
                'mode': 'managed',
                'type': 'aws_alb',
                'name': 'web',
                'instances': [{
                    'attributes': {
                        'arn':      'arn:aws:elasticloadbalancing:us-west-2:sim:loadbalancer/app/sim-app-c-alb/xyz789',
                        'dns_name': 'sim-app-c-alb.us-west-2.elb.amazonaws.com',
                        'name':     'sim-app-c-alb',
                        'vpc_id':   'vpc-simappcvpc',
                        'tags':     {'App': 'sim-app-c', 'Tier': 'ingress'},
                    },
                    'dependencies': [],
                }],
            },
            {
                'mode': 'managed',
                'type': 'aws_ecs_service',
                'name': 'web',
                'instances': [{
                    'attributes': {
                        'id':            'arn:aws:ecs:us-west-2:sim:service/sim-app-c-cluster/web-service',
                        'name':          'web-service',
                        'cluster':       'arn:aws:ecs:us-west-2:sim:cluster/sim-app-c-cluster',
                        'desired_count': 2,
                        'launch_type':   'FARGATE',
                        'tags':          {'App': 'sim-app-c', 'Tier': 'compute'},
                    },
                    'dependencies': ['aws_alb.web'],
                }],
            },
            {
                'mode': 'managed',
                'type': 'aws_elasticache_cluster',
                'name': 'redis',
                'instances': [{
                    'attributes': {
                        'id':              'sim-app-c-redis',
                        'engine':          'redis',
                        'node_type':       'cache.t3.micro',
                        'num_cache_nodes': 1,
                        'tags':            {'App': 'sim-app-c', 'Tier': 'data'},
                    },
                    'dependencies': ['aws_ecs_service.web'],
                }],
            },
        ],
    },
}


def send(event, context, status, data={}):
    body = json.dumps({
        'Status': status,
        'Reason': 'See CloudWatch',
        'PhysicalResourceId': context.log_stream_name,
        'StackId': event['StackId'],
        'RequestId': event['RequestId'],
        'LogicalResourceId': event['LogicalResourceId'],
        'Data': data,
    }).encode('utf-8')
    req = urllib.request.Request(
        url=event['ResponseURL'],
        data=body,
        method='PUT',
        headers={'Content-Type': ''}
    )
    urllib.request.urlopen(req)


def handler(event, context):
    try:
        request_type = event.get('RequestType', 'Create')

        if request_type == 'Delete':
            send(event, context, 'SUCCESS')
            return

        seeded = []
        for account_id, state in SYNTHETIC_STATES.items():
            # Upload tfstate to S3
            s3.put_object(
                Bucket=STATE_BUCKET,
                Key=f'{account_id}/terraform.tfstate',
                Body=json.dumps(state),
                ContentType='application/json',
            )

            # Build payload for state_parser
            payload = {
                'accountId': account_id,
                'source':    'opsiq.simulation.seed',
                'resources': state['resources'],
            }

            # Send to state-ingest queue (triggers state_parser Lambda)
            sqs.send_message(
                QueueUrl=STATE_QUEUE,
                MessageBody=json.dumps(payload),
            )

            # Register account in HealthScores table with clean baseline
            h_tbl.put_item(Item={
                'accountId':   account_id,
                'score':       100,
                'calculatedAt': int(time.time()),
                'ttl':         int(time.time()) + 6 * 60,
            })

            seeded.append(account_id)
            print(f'Seeded account: {account_id}')

        send(event, context, 'SUCCESS', {'seededAccounts': seeded, 'count': len(seeded)})

    except Exception as e:
        print(f'Seeder error: {e}')
        send(event, context, 'FAILED', {'Error': str(e)})
