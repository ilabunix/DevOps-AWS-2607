"""
Lambda handler wrapper for extended_seeder.py
Deploy to opsiq-extended-seeder Lambda and invoke to seed all 10 new accounts.
"""
import extended_seeder

def handler(event, context):
    extended_seeder.main()
    return {
        'statusCode': 200,
        'body': f'Seeded {len(extended_seeder.ACCOUNTS)} accounts successfully'
    }
