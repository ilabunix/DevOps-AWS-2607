# RDS Connection Exhaustion

**Severity:** HIGH  
**Affected Services:** RDS Aurora, all ECS/Lambda services connecting to it  
**Typical Detection Time:** 3–5 minutes after connections saturate  

---

## What This Looks Like

- `DatabaseConnections` metric near or at `max_connections` limit
- Application logs: `FATAL: remaining connection slots reserved for replication superuser connections`
- Application logs: `too many connections` or `connection pool exhausted`
- ECS tasks healthy but all API calls failing with 500 (DB unreachable)
- New ECS tasks spinning up but immediately failing health checks

---

## Immediate Actions

### 1. Check current connection count vs limit
```bash
DB_ID=<your-rds-cluster-id>

# Current connections
aws cloudwatch get-metric-statistics \
  --namespace AWS/RDS \
  --metric-name DatabaseConnections \
  --dimensions Name=DBClusterIdentifier,Value=$DB_ID \
  --start-time $(date -u -d '30 minutes ago' +%Y-%m-%dT%H:%M:%SZ) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%SZ) \
  --period 60 --statistics Maximum \
  --query 'sort_by(Datapoints, &Timestamp)[-10:].[Timestamp,Maximum]' \
  --output table
```

### 2. Find the max_connections limit for this instance class
```bash
# Get the parameter group
aws rds describe-db-clusters \
  --db-cluster-identifier $DB_ID \
  --query 'DBClusters[0].{engine:Engine,class:DBClusterMembers[0].DBInstanceClass}'
```

**Reference (Aurora PostgreSQL):**

| Instance Class | max_connections (approx) |
|----------------|--------------------------|
| db.t3.medium   | 420                      |
| db.r6g.large   | 1700                     |
| db.r6g.xlarge  | 3400                     |
| db.r6g.2xlarge | 6800                     |

---

## Root Cause Patterns

### Pattern A — Connection pool not configured (most common)
Application opens a new DB connection per request and never closes it.

**How to verify:** Connection count grows proportionally with ECS task count.  
**Fix:** Configure connection pooling in the application (PgBouncer, HikariCP, SQLAlchemy pool).

### Pattern B — Connection leak after ECS OOM restarts
ECS tasks killed mid-transaction leave connections in "idle in transaction" state.

**How to verify:**
```sql
-- Run against the DB if you have access
SELECT count(*), state, wait_event_type
FROM pg_stat_activity
WHERE datname = '<your-db>'
GROUP BY state, wait_event_type;
```
High `idle in transaction` count → leak from killed tasks.

### Pattern C — Sudden scale-out opened too many connections
Auto-scaling added many ECS tasks simultaneously, each opening a full pool.

**Fix:** Reduce `max_pool_size` per task, or deploy RDS Proxy.

---

## Containment

### Option A — Force ECS redeployment (drops leaked connections)
Gracefully replaces all ECS tasks, which closes their connections on shutdown.
```bash
aws ecs update-service \
  --cluster <cluster> \
  --service <service> \
  --force-new-deployment
```

### Option B — Scale down ECS tasks temporarily
Reduce task count to reduce connection pressure while the root cause is fixed.
```bash
aws ecs update-service \
  --cluster <cluster> \
  --service <service> \
  --desired-count <reduced-count>
```

### Option C — RDS Proxy (medium-term fix, not instant)
RDS Proxy multiplexes application connections, capping DB connections regardless of task count.
```bash
# Create RDS Proxy (takes ~5 min, connect app to proxy endpoint afterward)
aws rds create-db-proxy \
  --db-proxy-name <proxy-name> \
  --engine-family POSTGRESQL \
  --auth '[{"AuthScheme":"SECRETS","IAMAuth":"DISABLED","SecretArn":"<secret-arn>"}]' \
  --role-arn <iam-role-arn> \
  --vpc-subnet-ids <subnet-ids> \
  --vpc-security-group-ids <sg-ids>
```

---

## Prevention

| Action | Impact | Effort |
|--------|--------|--------|
| Configure connection pool max size (e.g. HikariCP `maximumPoolSize=5`) | Prevents per-task over-allocation | Low |
| Deploy RDS Proxy in front of Aurora | Caps total connections, enables IAM auth | Medium |
| CloudWatch alarm: DatabaseConnections > 80% of max | Early warning | Low |
| Set `idle_in_transaction_session_timeout = 30000` in parameter group | Auto-kills abandoned transactions | Low |
| Enable RDS enhanced monitoring | Per-process connection visibility | Low |
