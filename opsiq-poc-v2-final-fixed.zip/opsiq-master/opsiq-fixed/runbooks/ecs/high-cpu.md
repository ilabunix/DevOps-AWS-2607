# ECS Task High CPU Utilization

**Severity:** MEDIUM–HIGH  
**Affected Services:** ECS Fargate, ALB (latency increase)  
**Typical Detection Time:** 5–10 minutes after sustained spike  

---

## What This Looks Like

- ECS task `CPUUtilization` > 80% sustained for 5+ minutes
- ALB `TargetResponseTime` increasing (tasks throttled, slower responses)
- ECS service may be auto-scaling but not fast enough
- No task restarts (unlike OOM) — tasks are alive but degraded

---

## Immediate Actions

### 1. Confirm CPU utilization and affected tasks
```bash
CLUSTER=<cluster-name>
SERVICE=<service-name>

aws cloudwatch get-metric-statistics \
  --namespace AWS/ECS \
  --metric-name CPUUtilization \
  --dimensions Name=ClusterName,Value=$CLUSTER Name=ServiceName,Value=$SERVICE \
  --start-time $(date -u -d '15 minutes ago' +%Y-%m-%dT%H:%M:%SZ) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%SZ) \
  --period 60 \
  --statistics Maximum Average \
  --query 'sort_by(Datapoints, &Timestamp)[-5:]'
```

### 2. Check if this correlates with a traffic spike
```bash
# Check ALB request count over same period
aws cloudwatch get-metric-statistics \
  --namespace AWS/ApplicationELB \
  --metric-name RequestCount \
  --dimensions Name=LoadBalancer,Value=<alb-arn-suffix> \
  --start-time $(date -u -d '30 minutes ago' +%Y-%m-%dT%H:%M:%SZ) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%SZ) \
  --period 60 \
  --statistics Sum \
  --query 'sort_by(Datapoints, &Timestamp)[-10:]'
```

### 3. Check auto-scaling activity
```bash
aws application-autoscaling describe-scaling-activities \
  --service-namespace ecs \
  --resource-id service/$CLUSTER/$SERVICE \
  --query 'ScalingActivities[-5:].[StatusCode,Description,StartTime]' \
  --output table
```

---

## Root Cause Patterns

### Pattern A — Traffic spike (legitimate)
**Signal:** RequestCount up proportionally with CPU  
**Action:** Verify auto-scaling is configured and responding. If not, manually scale:
```bash
aws ecs update-service \
  --cluster $CLUSTER \
  --service $SERVICE \
  --desired-count <increased-count>
```

### Pattern B — Runaway process / infinite loop
**Signal:** CPU spike with no corresponding traffic increase  
**Logs to check:**
```bash
aws logs filter-log-events \
  --log-group-name /aws/ecs/<service-name> \
  --start-time $(date -u -d '20 minutes ago' +%s000) \
  --filter-pattern "?loop ?infinite ?spinning ?stuck" \
  --query 'events[-5:].[timestamp,message]' --output table
```
**Action:** Force new deployment to replace affected tasks.

### Pattern C — Downstream dependency slow (CPU waiting)
**Signal:** CPU high, but log throughput is low — tasks are waiting not computing  
**Check:** RDS query latency, Lambda invocation duration, downstream API response time  
**Action:** Identify the slow dependency and address it at the source.

---

## Containment

### Scale out immediately
```bash
aws ecs update-service \
  --cluster $CLUSTER \
  --service $SERVICE \
  --desired-count <2x current count>
```

### Force new deployment (if runaway process suspected)
```bash
aws ecs update-service \
  --cluster $CLUSTER \
  --service $SERVICE \
  --force-new-deployment
```

---

## Prevention

| Action | Impact | Effort |
|--------|--------|--------|
| Configure ECS auto-scaling on CPUUtilization > 70% | Automatic scale-out before threshold | Low |
| Set CloudWatch alarm on CPUUtilization > 80% | Early warning | Low |
| Profile application CPU usage in staging | Identify hot code paths | Medium |
| Set CPU shares appropriately in task definition | Prevent noisy-neighbor issues | Low |
