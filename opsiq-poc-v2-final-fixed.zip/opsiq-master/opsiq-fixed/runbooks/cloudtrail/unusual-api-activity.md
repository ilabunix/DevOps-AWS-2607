# CloudTrail Unusual API Activity

**Severity:** HIGH  
**Affected Services:** IAM, all AWS services in account  
**Typical Detection Time:** 15–60 minutes (trail delivery delay)  

---

## What This Looks Like

- Unexpected IAM role creation, policy attachment, or access key creation
- API calls from unusual source IPs or regions
- High volume of `AccessDenied` events (credential probing)
- Calls to services the account doesn't normally use (e.g. EC2 in an ECS-only account)
- `ConsoleLogin` from an unrecognised user or geography

---

## Immediate Actions

### 1. Identify the suspicious event
```bash
# Search recent CloudTrail for high-risk API calls
aws cloudtrail lookup-events \
  --lookup-attributes AttributeKey=EventName,AttributeValue=CreateAccessKey \
  --start-time $(date -u -d '2 hours ago' +%Y-%m-%dT%H:%M:%SZ) \
  --query 'Events[*].{time:EventTime,user:Username,source:CloudTrailEvent}' \
  --output table

# Check for IAM policy changes
aws cloudtrail lookup-events \
  --lookup-attributes AttributeKey=EventName,AttributeValue=AttachRolePolicy \
  --start-time $(date -u -d '2 hours ago' +%Y-%m-%dT%H:%M:%SZ)

# Check for new IAM users or roles
aws cloudtrail lookup-events \
  --lookup-attributes AttributeKey=EventName,AttributeValue=CreateUser \
  --start-time $(date -u -d '24 hours ago' +%Y-%m-%dT%H:%M:%SZ)
```

### 2. Check for AccessDenied spike (credential probing)
```bash
aws cloudwatch get-metric-statistics \
  --namespace CloudTrailMetrics \
  --metric-name ErrorCount \
  --start-time $(date -u -d '2 hours ago' +%Y-%m-%dT%H:%M:%SZ) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%SZ) \
  --period 300 --statistics Sum
```

### 3. Identify the source principal
```bash
# Look up a specific event by event ID to get full detail
aws cloudtrail get-trail-status --name <trail-name>

# Use S3 logs for deeper analysis (if available)
# Events are in: s3://<trail-bucket>/AWSLogs/<account-id>/CloudTrail/<region>/<year>/<month>/<day>/
```

---

## Containment Actions (Scale by Severity)

### Suspicious access key usage → revoke the key immediately
```bash
# List access keys for the suspected user
aws iam list-access-keys --user-name <username>

# Deactivate (reversible)
aws iam update-access-key \
  --user-name <username> \
  --access-key-id <key-id> \
  --status Inactive

# Delete (permanent — do this if confirmed malicious)
aws iam delete-access-key \
  --user-name <username> \
  --access-key-id <key-id>
```

### Compromised IAM role → attach a deny-all policy immediately
```bash
# Create a deny-all policy and attach to the role to block all access
aws iam put-role-policy \
  --role-name <role-name> \
  --policy-name EmergencyDenyAll \
  --policy-document '{
    "Version": "2012-10-17",
    "Statement": [{"Effect": "Deny", "Action": "*", "Resource": "*"}]
  }'
```

### Unrecognised IAM user or role created → delete it
```bash
# Delete any attached policies first, then delete the entity
aws iam detach-role-policy --role-name <role> --policy-arn <arn>
aws iam delete-role --role-name <role>
```

### Rotate all access keys for affected team members
Document which keys were active during the incident window and rotate them all.

---

## Investigation Checklist

- [ ] Identify the exact API call, time, source IP, and user agent
- [ ] Confirm whether the source IP is a known corporate range
- [ ] Check if the call came from a Lambda, EC2, or human identity
- [ ] Review IAM Access Analyzer findings for public or cross-account access
- [ ] Check if any new resources were created (EC2, S3 buckets, Lambda functions)
- [ ] Verify CloudTrail is still logging (has not been disabled)
- [ ] Notify Security team and begin incident response process

---

## Verify CloudTrail Is Still Active
```bash
aws cloudtrail get-trail-status --name <trail-name> \
  --query '{IsLogging:IsLogging,LastDeliveryTime:LatestDeliveryTime}'
```

If `IsLogging: false` — CloudTrail was disabled. This is an active attack indicator.  
Re-enable immediately:
```bash
aws cloudtrail start-logging --name <trail-name>
```

---

## Prevention

| Action | Impact | Effort |
|--------|--------|--------|
| Enable AWS GuardDuty | Automated threat detection | Low |
| CloudWatch alarm on `CreateAccessKey` or `ConsoleLogin` | Immediate alert | Low |
| Enforce MFA for all IAM users | Prevents credential-only compromise | Medium |
| Use IAM roles instead of access keys wherever possible | Reduces long-lived credential exposure | Medium |
| Enable AWS Config with managed rules for IAM | Continuous compliance monitoring | Medium |
| Restrict CloudTrail `StopLogging` to break-glass role only | Prevents trail disabling | Low |
